@echo off
color 0A

cd /d C:\Users\Mebra\Downloads\VLyn_VoronoiResetFix\VLyn_DLL_Output
cls

call "C:\Program Files\Microsoft Visual Studio\18\Insiders\VC\Auxiliary\Build\vcvars64.bat"

nvcc ^
-shared ^
-O3 ^
-std=c++17 ^
--use_fast_math ^
--extended-lambda ^
-DCCCL_IGNORE_DEPRECATED_CPP_DIALECT ^
-DVLYN_DLL_EXPORTS ^
-gencode arch=compute_86,code=sm_86 ^
-Xcompiler "/LD /EHsc /W3 /O2 /Oi /Gy /MD /std:c++17 /Zc:preprocessor /wd4996 /fp:fast /arch:AVX2 /Zi" ^
-Xlinker "/DEBUG" ^
-I"./include" ^
-I"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2\include" ^
-L"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.2\lib\x64" ^
-lcudart ^
-lcublas ^
-lcublasLt ^
src/VLyn_bvh.cu ^
src/VLyn_core.cu ^
src/VLyn_mesh.cu ^
src/VLyn_ml.cu ^
src/VLyn_ml_narrow.cu ^
src/VLyn_voronoi.cu ^
-o VLyn.dll

color 0A
pause