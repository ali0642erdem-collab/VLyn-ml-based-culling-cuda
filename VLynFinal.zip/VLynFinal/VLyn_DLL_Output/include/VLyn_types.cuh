// =============================================================================
// VLyn_types.cuh  —  Core Types, Math & Data Structures
// VLyn High-Performance Geometric Collision Detection Library
// Supports 1B+ triangles via GPU-parallel LBVH + ML + Voronoi pipeline
// =============================================================================
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <cooperative_groups.h>
#include <cstdint>
#include <cmath>
#include <cfloat>
#include <cassert>
#include <cuda_runtime.h>
#include <cublas_v2.h>

namespace cg = cooperative_groups;

// =============================================================================
// Build Configuration & Feature Flags
// =============================================================================
#define VLYN_VERSION_MAJOR   2
#define VLYN_VERSION_MINOR   0
#define VLYN_VERSION_PATCH   0

#define VLYN_MAX_MESHES             64
#define VLYN_MAX_TRIANGLES_PER_MESH 0x40000000ULL   // 1 073 741 824
#define VLYN_TILE_SIZE              65536            // triangles per streaming tile
#define VLYN_BVH_MAX_DEPTH          64
#define VLYN_ML_FEATURE_DIM         32
#define VLYN_ML_HIDDEN1             64
#define VLYN_ML_HIDDEN2             32
#define VLYN_ML_OUTPUT              1
#define VLYN_VORONOI_MAX_VERTS      32
#define VLYN_GJK_MAX_ITER           64
#define VLYN_EPA_MAX_ITER           32
#define VLYN_EPA_TOLERANCE          1e-5f
#define VLYN_WARP_SIZE              32
#define VLYN_BLOCK_SIZE             256
#define VLYN_MAX_CONTACTS_PER_PAIR  4
#define VLYN_MORTON_BITS            21
#define VLYN_CLUSTER_K              512             // k-means clusters per tile

// =============================================================================
// CUDA Utility Macros
// =============================================================================
#define VLYN_CUDA_CHECK(call)                                                   \
    do {                                                                        \
        cudaError_t err = (call);                                               \
        if (err != cudaSuccess) {                                               \
            fprintf(stderr, "[VLyn] CUDA error %s at %s:%d — %s\n",            \
                cudaGetErrorName(err), __FILE__, __LINE__,                      \
                cudaGetErrorString(err));                                        \
            return VLYN_ERR_CUDA;                                               \
        }                                                                       \
    } while(0)

#define VLYN_DEVICE   __device__ __forceinline__
#define VLYN_HOST_DEV __host__ __device__ __forceinline__
#define VLYN_GLOBAL   __global__
#define VLYN_SHARED   __shared__

// Warp reduction helper (single-lane result at lane 0)
#define VLYN_WARP_REDUCE_SUM(val)                                               \
    do {                                                                        \
        for (int _m = VLYN_WARP_SIZE/2; _m > 0; _m >>= 1)                     \
            val += __shfl_down_sync(0xffffffff, val, _m);                       \
    } while(0)

#define VLYN_WARP_REDUCE_MIN(val)                                               \
    do {                                                                        \
        for (int _m = VLYN_WARP_SIZE/2; _m > 0; _m >>= 1)                     \
            val = fminf(val, __shfl_down_sync(0xffffffff, val, _m));            \
    } while(0)

#define VLYN_WARP_REDUCE_MAX(val)                                               \
    do {                                                                        \
        for (int _m = VLYN_WARP_SIZE/2; _m > 0; _m >>= 1)                     \
            val = fmaxf(val, __shfl_down_sync(0xffffffff, val, _m));            \
    } while(0)

// =============================================================================
// Error Codes
// =============================================================================
typedef enum {
    VLYN_OK                   = 0,
    VLYN_ERR_CUDA             = -1,
    VLYN_ERR_OOM              = -2,
    VLYN_ERR_NULL_PTR         = -3,
    VLYN_ERR_INVALID_MESH     = -4,
    VLYN_ERR_MAX_MESHES       = -5,
    VLYN_ERR_NOT_INITIALIZED  = -6,
    VLYN_ERR_STREAM           = -7,
    VLYN_ERR_BVH_BUILD        = -8,
    VLYN_ERR_ML_INFERENCE     = -9,
    VLYN_ERR_VORONOI          = -10,
} VLynError;

// =============================================================================
// Vec2 — 2D float vector
// =============================================================================
struct alignas(8) Vec2 {
    float x, y;

    VLYN_HOST_DEV Vec2() : x(0), y(0) {}
    VLYN_HOST_DEV Vec2(float x, float y) : x(x), y(y) {}

    VLYN_HOST_DEV Vec2 operator+(const Vec2& o) const { return {x+o.x, y+o.y}; }
    VLYN_HOST_DEV Vec2 operator-(const Vec2& o) const { return {x-o.x, y-o.y}; }
    VLYN_HOST_DEV Vec2 operator*(float s)        const { return {x*s,   y*s};   }
    VLYN_HOST_DEV float dot(const Vec2& o)       const { return x*o.x + y*o.y; }
    VLYN_HOST_DEV float lengthSq()               const { return dot(*this); }
    VLYN_HOST_DEV float length()                 const { return sqrtf(lengthSq()); }
    VLYN_HOST_DEV Vec2 normalize()               const { float l=length(); return {x/l,y/l}; }
};

// =============================================================================
// Vec3 — 3D float vector (16-byte aligned for CUDA coalescing)
// =============================================================================
struct alignas(16) Vec3 {
    float x, y, z;
    float _pad;

    VLYN_HOST_DEV Vec3() : x(0), y(0), z(0), _pad(0) {}
    VLYN_HOST_DEV Vec3(float x, float y, float z) : x(x), y(y), z(z), _pad(0) {}
    VLYN_HOST_DEV explicit Vec3(float s) : x(s), y(s), z(s), _pad(0) {}

    VLYN_HOST_DEV Vec3  operator+(const Vec3& o) const { return {x+o.x, y+o.y, z+o.z}; }
    VLYN_HOST_DEV Vec3  operator-(const Vec3& o) const { return {x-o.x, y-o.y, z-o.z}; }
    VLYN_HOST_DEV Vec3  operator*(float s)        const { return {x*s,   y*s,   z*s};   }
    VLYN_HOST_DEV Vec3  operator/(float s)        const { return {x/s,   y/s,   z/s};   }
    VLYN_HOST_DEV Vec3& operator+=(const Vec3& o)       { x+=o.x; y+=o.y; z+=o.z; return *this; }
    VLYN_HOST_DEV Vec3& operator-=(const Vec3& o)       { x-=o.x; y-=o.y; z-=o.z; return *this; }
    VLYN_HOST_DEV Vec3& operator*=(float s)             { x*=s;   y*=s;   z*=s;   return *this; }

    VLYN_HOST_DEV float dot(const Vec3& o)  const { return x*o.x + y*o.y + z*o.z; }
    VLYN_HOST_DEV float lengthSq()          const { return dot(*this); }
    VLYN_HOST_DEV float length()            const { return sqrtf(lengthSq()); }
    VLYN_HOST_DEV Vec3  normalize()         const { float l=length(); return (l>1e-10f) ? *this/l : Vec3(0,1,0); }
    VLYN_HOST_DEV bool  isZero()            const { return lengthSq() < 1e-20f; }

    VLYN_HOST_DEV Vec3 cross(const Vec3& o) const {
        return { y*o.z - z*o.y,
                 z*o.x - x*o.z,
                 x*o.y - y*o.x };
    }

    VLYN_HOST_DEV Vec3 abs() const { return {fabsf(x), fabsf(y), fabsf(z)}; }

    VLYN_HOST_DEV float& operator[](int i) {
        return i == 0 ? x : (i == 1 ? y : z);
    }
    VLYN_HOST_DEV float operator[](int i) const {
        return i == 0 ? x : (i == 1 ? y : z);
    }

    // Min / max component-wise
    VLYN_HOST_DEV static Vec3 min(const Vec3& a, const Vec3& b) {
        return { fminf(a.x,b.x), fminf(a.y,b.y), fminf(a.z,b.z) };
    }
    VLYN_HOST_DEV static Vec3 max(const Vec3& a, const Vec3& b) {
        return { fmaxf(a.x,b.x), fmaxf(a.y,b.y), fmaxf(a.z,b.z) };
    }

    // Lerp
    VLYN_HOST_DEV static Vec3 lerp(const Vec3& a, const Vec3& b, float t) {
        return a + (b - a) * t;
    }
};

// Free operators
VLYN_HOST_DEV Vec3 operator*(float s, const Vec3& v) { return v*s; }

// =============================================================================
// Mat3 — 3x3 float matrix (row-major)
// =============================================================================
struct alignas(16) Mat3 {
    float m[3][3];

    VLYN_HOST_DEV Mat3() {
        for(int i=0;i<3;i++) for(int j=0;j<3;j++) m[i][j]=(i==j)?1.f:0.f;
    }

    VLYN_HOST_DEV Vec3 mul(const Vec3& v) const {
        return { m[0][0]*v.x + m[0][1]*v.y + m[0][2]*v.z,
                 m[1][0]*v.x + m[1][1]*v.y + m[1][2]*v.z,
                 m[2][0]*v.x + m[2][1]*v.y + m[2][2]*v.z };
    }

    VLYN_HOST_DEV Mat3 mul(const Mat3& o) const {
        Mat3 r; for(int i=0;i<3;i++) for(int j=0;j<3;j++) {
            r.m[i][j]=0;
            for(int k=0;k<3;k++) r.m[i][j]+=m[i][k]*o.m[k][j];
        } return r;
    }

    VLYN_HOST_DEV Mat3 transpose() const {
        Mat3 r;
        for(int i=0;i<3;i++) for(int j=0;j<3;j++) r.m[i][j]=m[j][i];
        return r;
    }

    VLYN_HOST_DEV float det() const {
        return m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])
              -m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])
              +m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0]);
    }

    // Outer product a ⊗ b
    VLYN_HOST_DEV static Mat3 outer(const Vec3& a, const Vec3& b) {
        Mat3 r;
        for(int i=0;i<3;i++) for(int j=0;j<3;j++) r.m[i][j]=a[i]*b[j];
        return r;
    }

    // Covariance from set of 3 axis vectors
    VLYN_HOST_DEV static Mat3 covariance(const Vec3& ex, const Vec3& ey, const Vec3& ez) {
        Mat3 r;
        r.m[0][0]=ex.x; r.m[0][1]=ex.y; r.m[0][2]=ex.z;
        r.m[1][0]=ey.x; r.m[1][1]=ey.y; r.m[1][2]=ey.z;
        r.m[2][0]=ez.x; r.m[2][1]=ez.y; r.m[2][2]=ez.z;
        return r;
    }
};

// =============================================================================
// Quaternion
// =============================================================================
struct alignas(16) Quat {
    float w, x, y, z;

    VLYN_HOST_DEV Quat() : w(1), x(0), y(0), z(0) {}
    VLYN_HOST_DEV Quat(float w, float x, float y, float z) : w(w), x(x), y(y), z(z) {}

    VLYN_HOST_DEV static Quat fromAxisAngle(Vec3 axis, float angle) {
        float s = sinf(angle*0.5f);
        return { cosf(angle*0.5f), axis.x*s, axis.y*s, axis.z*s };
    }

    VLYN_HOST_DEV Quat operator*(const Quat& o) const {
        return { w*o.w - x*o.x - y*o.y - z*o.z,
                 w*o.x + x*o.w + y*o.z - z*o.y,
                 w*o.y - x*o.z + y*o.w + z*o.x,
                 w*o.z + x*o.y - y*o.x + z*o.w };
    }

    VLYN_HOST_DEV Vec3 rotate(const Vec3& v) const {
        Vec3 u(x, y, z);
        Vec3 t = u.cross(v) * 2.f;
        return v + t*w + u.cross(t);
    }

    VLYN_HOST_DEV Mat3 toMat3() const {
        Mat3 r;
        r.m[0][0] = 1-2*(y*y+z*z); r.m[0][1] = 2*(x*y-w*z); r.m[0][2] = 2*(x*z+w*y);
        r.m[1][0] = 2*(x*y+w*z);   r.m[1][1] = 1-2*(x*x+z*z); r.m[1][2] = 2*(y*z-w*x);
        r.m[2][0] = 2*(x*z-w*y);   r.m[2][1] = 2*(y*z+w*x);   r.m[2][2] = 1-2*(x*x+y*y);
        return r;
    }

    VLYN_HOST_DEV Quat normalize() const {
        float n = sqrtf(w*w+x*x+y*y+z*z);
        return {w/n, x/n, y/n, z/n};
    }
};

// =============================================================================
// Transform — rigid body transform (translation + rotation)
// =============================================================================
struct alignas(16) Transform {
    Vec3  pos;
    Quat  rot;
    float scale;

    VLYN_HOST_DEV Transform() : pos(0,0,0), rot(), scale(1.f) {}

    VLYN_HOST_DEV Vec3 apply(const Vec3& v) const {
        return rot.rotate(v * scale) + pos;
    }

    VLYN_HOST_DEV Vec3 applyInverse(const Vec3& v) const {
        Vec3 d = v - pos;
        Quat invRot = { rot.w, -rot.x, -rot.y, -rot.z };
        return invRot.rotate(d) / scale;
    }
};

// =============================================================================
// AABB — Axis-Aligned Bounding Box
// =============================================================================
struct alignas(32) AABB {
    Vec3 mn;     // minimum corner
    Vec3 mx;     // maximum corner

    VLYN_HOST_DEV AABB() : mn( FLT_MAX, FLT_MAX, FLT_MAX),
                            mx(-FLT_MAX,-FLT_MAX,-FLT_MAX) {}
    VLYN_HOST_DEV AABB(const Vec3& mn, const Vec3& mx) : mn(mn), mx(mx) {}

    VLYN_HOST_DEV Vec3  center()  const { return (mn + mx) * 0.5f; }
    VLYN_HOST_DEV Vec3  extent()  const { return mx - mn; }
    VLYN_HOST_DEV float volume()  const { Vec3 e=extent(); return e.x*e.y*e.z; }
    VLYN_HOST_DEV float surface() const {
        Vec3 e=extent(); return 2.f*(e.x*e.y + e.y*e.z + e.z*e.x);
    }

    VLYN_HOST_DEV void expand(const Vec3& p) {
        mn = Vec3::min(mn, p);
        mx = Vec3::max(mx, p);
    }

    VLYN_HOST_DEV void expand(const AABB& o) {
        mn = Vec3::min(mn, o.mn);
        mx = Vec3::max(mx, o.mx);
    }

    VLYN_HOST_DEV bool overlaps(const AABB& o) const {
        return (mn.x <= o.mx.x) & (mx.x >= o.mn.x) &
               (mn.y <= o.mx.y) & (mx.y >= o.mn.y) &
               (mn.z <= o.mx.z) & (mx.z >= o.mn.z);
    }

    VLYN_HOST_DEV bool contains(const Vec3& p) const {
        return (p.x >= mn.x) & (p.x <= mx.x) &
               (p.y >= mn.y) & (p.y <= mx.y) &
               (p.z >= mn.z) & (p.z <= mx.z);
    }

    // SAH (Surface Area Heuristic) cost
    VLYN_HOST_DEV float sah() const { return surface(); }

    // Merge two AABBs
    VLYN_HOST_DEV static AABB merge(const AABB& a, const AABB& b) {
        return { Vec3::min(a.mn, b.mn), Vec3::max(a.mx, b.mx) };
    }

    // Expand by epsilon for numerical stability
    VLYN_HOST_DEV AABB expanded(float eps) const {
        return { mn - Vec3(eps), mx + Vec3(eps) };
    }
};

// =============================================================================
// Triangle — 3 vertices + derived data
// =============================================================================
struct alignas(64) Triangle {
    Vec3  v0, v1, v2;   // vertices
    Vec3  normal;        // face normal (normalized)
    Vec3  centroid;      // (v0+v1+v2)/3
    float area;          // triangle area
    uint32_t meshId;     // source mesh index
    uint32_t triId;      // index within mesh
    uint32_t clusterId;  // assigned cluster (set during scan)
    uint32_t _pad;

    VLYN_HOST_DEV void computeDerived() {
        Vec3 e0 = v1 - v0;
        Vec3 e1 = v2 - v0;
        Vec3 cr = e0.cross(e1);
        area     = cr.length() * 0.5f;
        normal   = cr.normalize();
        centroid = (v0 + v1 + v2) * (1.f/3.f);
    }

    VLYN_HOST_DEV AABB aabb() const {
        return { Vec3::min(Vec3::min(v0,v1),v2),
                 Vec3::max(Vec3::max(v0,v1),v2) };
    }

    // Möller–Trumbore ray-triangle intersection
    VLYN_HOST_DEV bool rayIntersect(const Vec3& orig, const Vec3& dir,
                                    float& t, float& u, float& v) const {
        const float eps = 1e-8f;
        Vec3 e1 = v1 - v0, e2 = v2 - v0;
        Vec3 h  = dir.cross(e2);
        float a = e1.dot(h);
        if (fabsf(a) < eps) return false;
        float f = 1.f / a;
        Vec3 s = orig - v0;
        u = f * s.dot(h);
        if (u < 0.f || u > 1.f) return false;
        Vec3 q = s.cross(e1);
        v = f * dir.dot(q);
        if (v < 0.f || u + v > 1.f) return false;
        t = f * e2.dot(q);
        return t > eps;
    }

    // Closest point on triangle to point p
    VLYN_HOST_DEV Vec3 closestPoint(const Vec3& p) const {
        Vec3 ab = v1 - v0, ac = v2 - v0, ap = p - v0;
        float d1 = ab.dot(ap), d2 = ac.dot(ap);
        if (d1 <= 0 && d2 <= 0) return v0;
        Vec3 bp = p - v1;
        float d3 = ab.dot(bp), d4 = ac.dot(bp);
        if (d3 >= 0 && d4 <= d3) return v1;
        float vc = d1*d4 - d3*d2;
        if (vc <= 0 && d1 >= 0 && d3 <= 0) return v0 + ab*(d1/(d1-d3));
        Vec3 cp = p - v2;
        float d5 = ab.dot(cp), d6 = ac.dot(cp);
        if (d6 >= 0 && d5 <= d6) return v2;
        float vb = d5*d2 - d1*d6;
        if (vb <= 0 && d2 >= 0 && d6 <= 0) return v0 + ac*(d2/(d2-d6));
        float va = d3*d6 - d5*d4;
        if (va <= 0 && (d4-d3) >= 0 && (d5-d6) >= 0) {
            float w = (d4-d3)/((d4-d3)+(d5-d6));
            return v1 + (v2-v1)*w;
        }
        float denom = 1.f/(va+vb+vc);
        return v0 + ab*(vb*denom) + ac*(vc*denom);
    }
};

// =============================================================================
// BVH Node — for Linear BVH (LBVH) Karras 2012
// =============================================================================
struct alignas(64) BVHNode {
    AABB    aabb;            // 32 bytes
    int32_t leftChild;       // index of left child (< 0 = leaf)
    int32_t rightChild;      // index of right child
    int32_t parent;          // parent node index (-1 for root)
    int32_t triOffset;       // first triangle (for leaf)
    int32_t triCount;        // count (for leaf, 0 for internal)
    uint32_t mortonCode;     // sorted morton code
    int32_t splitAxis;       // 0=X 1=Y 2=Z (internal nodes)
    uint32_t atomicCounter;  // for bottom-up AABB construction
    uint32_t _pad[2];

    VLYN_HOST_DEV bool isLeaf()  const { return triCount > 0; }
    VLYN_HOST_DEV bool isRoot()  const { return parent == -1; }
};

// =============================================================================
// Cluster — ML feature cluster for a set of triangles
// =============================================================================
struct alignas(64) Cluster {
    Vec3     centroid;
    AABB     bounds;
    Vec3     avgNormal;
    float    avgArea;
    float    areaVariance;
    float    normalVariance;
    uint32_t triCount;
    uint32_t meshId;
    uint32_t clusterIdx;
    float    density;         // triangles per unit volume
    // 32-dim feature vector (populated by ML extractor)
    float    features[VLYN_ML_FEATURE_DIM];
};

// =============================================================================
// Collision Contact Point
// NOTE: alignas(64) removed — it inflated sizeof(ContactPoint) to 192 bytes
// while the public VLynContactPoint is 72 bytes. The 120-byte gap per contact
// (4 contacts × 120 = 480 bytes) caused cudaMemcpy to write into adjacent
// memory, corrupting contactCount and all downstream fields.
// Vec3 already has alignas(16) so GPU coalescing is preserved.
// =============================================================================
struct ContactPoint {
    Vec3     position;       // world-space contact point
    Vec3     normal;         // contact normal (pointing from B to A)
    float    penetrationDepth;
    float    separation;     // positive = gap, negative = overlap
    uint32_t triIdA;         // triangle index in mesh A
    uint32_t triIdB;         // triangle index in mesh B
    uint32_t meshIdA;
    uint32_t meshIdB;
    float    confidence;     // ML confidence score [0,1]
    uint32_t voronoiRegion;  // Voronoi feature region tag
    uint32_t _pad[2];
};

// =============================================================================
// Collision Result — output per pair
// NOTE: alignas(64) removed — with alignas(64) ContactPoint this struct was
// 960 bytes internally vs 332 bytes for VLynCollisionResult publicly.
// Now both are layout-compatible: 16 header bytes + 4×72 contacts + 28 tail
// = 332 bytes, matching VLynCollisionResult exactly.
// =============================================================================
struct CollisionResult {
    uint32_t     meshIdA;
    uint32_t     meshIdB;
    uint32_t     contactCount;
    uint32_t     flags;         // bitmask: bit0=separating, bit1=resting, bit2=colliding
    ContactPoint contacts[VLYN_MAX_CONTACTS_PER_PAIR];
    float        closestDist;   // closest distance between objects
    Vec3         separatingAxis;
    double       timestamp;     // seconds since epoch
};

// =============================================================================
// Simplex — for GJK algorithm (up to 4 support points)
// =============================================================================
struct Simplex {
    Vec3    pts[4];   // simplex vertices (in Minkowski difference)
    Vec3    wA[4];    // witness points on shape A
    Vec3    wB[4];    // witness points on shape B
    int     size;

    VLYN_HOST_DEV Simplex() : size(0) {}

    VLYN_HOST_DEV void push(const Vec3& p, const Vec3& a, const Vec3& b) {
        // shift down
        for (int i = size; i > 0; --i) {
            pts[i] = pts[i-1]; wA[i] = wA[i-1]; wB[i] = wB[i-1];
        }
        pts[0] = p; wA[0] = a; wB[0] = b;
        if (size < 4) ++size;
    }

    VLYN_HOST_DEV Vec3 last() const { return pts[0]; }

    VLYN_HOST_DEV void set(int i, const Vec3& p, const Vec3& a, const Vec3& b) {
        pts[i] = p; wA[i] = a; wB[i] = b;
    }
};

// =============================================================================
// Polytope face — for EPA algorithm
// =============================================================================
struct PolytopeFace {
    Vec3    normal;
    float   dist;
    uint32_t a, b, c;   // vertex indices
};

// =============================================================================
// VoronoiRegion — Voronoi feature of a simplex
// =============================================================================
enum class VoronoiRegion : uint8_t {
    NONE       = 0,
    VERTEX_A   = 1,
    VERTEX_B   = 2,
    VERTEX_C   = 3,
    VERTEX_D   = 4,
    EDGE_AB    = 5,
    EDGE_AC    = 6,
    EDGE_AD    = 7,
    EDGE_BC    = 8,
    EDGE_BD    = 9,
    EDGE_CD    = 10,
    FACE_ABC   = 11,
    FACE_ACD   = 12,
    FACE_ADB   = 13,
    FACE_BCD   = 14,
    INTERIOR   = 15,
};

// =============================================================================
// ML Layer Weights — fully connected layer stored in GPU memory
// =============================================================================
struct FCLayer {
    float* weight;    // [out_dim x in_dim]  row-major
    float* bias;      // [out_dim]
    int    inDim;
    int    outDim;
    bool   relu;
    bool   sigmoid;
};

// =============================================================================
// Neural Network — 3-layer collision predictor
// =============================================================================
struct CollisionNet {
    FCLayer layers[3];
    float*  d_scratch;    // device scratch buffer for activations
    int     scratchBytes;
    bool    initialized;
};

// =============================================================================
// Mesh Descriptor — registered mesh in the system
// =============================================================================
struct MeshDesc {
    Triangle*  d_triangles;   // device pointer
    BVHNode*   d_bvh;         // device BVH nodes
    uint32_t*  d_mortonCodes; // sorted Morton codes
    uint32_t*  d_triOrder;    // sorted triangle indices
    Cluster*   d_clusters;    // k-means clusters
    uint32_t   triCount;
    uint32_t   bvhNodeCount;
    uint32_t   clusterCount;
    AABB       worldBounds;
    Transform  transform;
    float      bvhBuildTime;  // ms
    float      clusterTime;   // ms
    bool       isDirty;       // needs BVH rebuild
    uint32_t   meshId;
};

// =============================================================================
// CVS Configuration — passed to CVSCrt()
// =============================================================================
typedef struct CVSConfig {
    int     maxMeshes;          // default: VLYN_MAX_MESHES
    int     gpuDevice;          // CUDA device index (-1 = auto)
    size_t  tileSize;           // triangles per streaming tile
    int     numStreams;          // CUDA streams for parallelism
    float   mlThreshold;        // ML confidence threshold [0,1]
    float   voronoiEpsilon;     // numerical epsilon for Voronoi
    bool    enableML;           // enable ML broad-phase culling
    bool    enableVoronoi;      // enable Voronoi narrow phase
    bool    enableProfiling;    // collect timing statistics
    bool    asyncMode;          // asynchronous query processing
    int     clusterK;           // k-means cluster count
    int     gjkMaxIter;         // GJK iteration cap
    int     epaMaxIter;         // EPA iteration cap
    float   contactMergeEps;    // merge near-duplicate contacts
    bool    enableOnlineTraining; // train ML narrow-phase net on fallback
                                   // ground truth every query (adds backward-
                                   // pass GPU cost per call; off by default)
} CVSConfig;

// =============================================================================
// CVS Context — opaque handle returned by CVSCrt()
// =============================================================================
typedef struct CVSContext* CVSHandle;

// =============================================================================
// Profiling Stats
// =============================================================================
struct VLynStats {
    double meshScanMs;
    double bvhBuildMs;
    double mlInferenceMs;
    double voronoiMs;
    double totalMs;
    uint64_t candidatePairs;
    uint64_t mlRejected;
    uint64_t narrowPhasePairs;
    uint64_t contactsFound;
    float    mlAcceptRate;
    float    throughputMTriPerSec;
};

// =============================================================================
// Utility: Morton code helpers (21-bit per axis, 63-bit total)
// =============================================================================
VLYN_HOST_DEV uint64_t mortonExpand21(uint32_t v) {
    uint64_t x = v & 0x1fffff;
    x = (x | (x << 32)) & 0x1f00000000ffffULL;
    x = (x | (x << 16)) & 0x1f0000ff0000ffULL;
    x = (x | (x <<  8)) & 0x100f00f00f00f0fULL;
    x = (x | (x <<  4)) & 0x10c30c30c30c3ULL;
    x = (x | (x <<  2)) & 0x1249249249249ULL;
    return x;
}

VLYN_HOST_DEV uint64_t mortonEncode3D(uint32_t x, uint32_t y, uint32_t z) {
    return mortonExpand21(x) | (mortonExpand21(y) << 1) | (mortonExpand21(z) << 2);
}

VLYN_HOST_DEV uint64_t mortonFromVec3(const Vec3& p, const AABB& bounds) {
    Vec3 ext = bounds.mx - bounds.mn;
    float scaleX = (ext.x > 1e-10f) ? (float)((1u<<21)-1) / ext.x : 0.f;
    float scaleY = (ext.y > 1e-10f) ? (float)((1u<<21)-1) / ext.y : 0.f;
    float scaleZ = (ext.z > 1e-10f) ? (float)((1u<<21)-1) / ext.z : 0.f;
    uint32_t ix = (uint32_t)fmaxf(0.f, fminf((float)((1u<<21)-1), (p.x-bounds.mn.x)*scaleX));
    uint32_t iy = (uint32_t)fmaxf(0.f, fminf((float)((1u<<21)-1), (p.y-bounds.mn.y)*scaleY));
    uint32_t iz = (uint32_t)fmaxf(0.f, fminf((float)((1u<<21)-1), (p.z-bounds.mn.z)*scaleZ));
    return mortonEncode3D(ix, iy, iz);
}

// =============================================================================
// Utility: CLZ (count leading zeros) on 64-bit Morton codes
// =============================================================================
VLYN_DEVICE int clz64(uint64_t x) {
    return __clzll(x);
}

// =============================================================================
// Utility: Safe atomicMin / atomicMax on float (via int reinterpret)
// =============================================================================
VLYN_DEVICE float atomicMinFloat(float* addr, float val) {
    int* iaddr = (int*)addr;
    int old = *iaddr, assumed;
    do {
        assumed = old;
        old = atomicCAS(iaddr, assumed,
            __float_as_int(fminf(val, __int_as_float(assumed))));
    } while (assumed != old);
    return __int_as_float(old);
}

VLYN_DEVICE float atomicMaxFloat(float* addr, float val) {
    int* iaddr = (int*)addr;
    int old = *iaddr, assumed;
    do {
        assumed = old;
        old = atomicCAS(iaddr, assumed,
            __float_as_int(fmaxf(val, __int_as_float(assumed))));
    } while (assumed != old);
    return __int_as_float(old);
}

// =============================================================================
// Utility: Expand AABB atomically (device only)
// =============================================================================
VLYN_DEVICE void atomicExpandAABB(AABB* box, const Vec3& p) {
    atomicMinFloat(&box->mn.x, p.x);
    atomicMinFloat(&box->mn.y, p.y);
    atomicMinFloat(&box->mn.z, p.z);
    atomicMaxFloat(&box->mx.x, p.x);
    atomicMaxFloat(&box->mx.y, p.y);
    atomicMaxFloat(&box->mx.z, p.z);
}

// =============================================================================
// Utility: ReLU / Sigmoid (device)
// =============================================================================
VLYN_DEVICE float relu(float x) { return fmaxf(0.f, x); }
VLYN_DEVICE float sigmoid(float x) { return 1.f / (1.f + expf(-x)); }
VLYN_DEVICE float tanhAct(float x) { return tanhf(x); }

// =============================================================================
// Utility: Warp ballot helpers
// =============================================================================
VLYN_DEVICE int warpActiveCount(bool pred) {
    return __popc(__ballot_sync(0xffffffff, pred));
}

VLYN_DEVICE int warpFirstActive(bool pred) {
    uint32_t mask = __ballot_sync(0xffffffff, pred);
    return __ffs(mask) - 1;
}

// =============================================================================
// Utility: Block-level inclusive prefix sum (in shared memory)
// =============================================================================
template<int N>
VLYN_DEVICE void blockPrefixSum(int* arr, int n) {
    VLYN_SHARED int tmp[N];
    int tid = threadIdx.x;
    if (tid < n) tmp[tid] = arr[tid];
    __syncthreads();
    for (int step = 1; step < n; step <<= 1) {
        int val = (tid >= step) ? tmp[tid-step] : 0;
        __syncthreads();
        if (tid < n) tmp[tid] += val;
        __syncthreads();
    }
    if (tid < n) arr[tid] = tmp[tid];
}

// =============================================================================
// Utility: Default CVSConfig
// =============================================================================
inline CVSConfig VLynDefaultConfig() {
    CVSConfig c;
    c.maxMeshes        = VLYN_MAX_MESHES;
    c.gpuDevice        = -1;
    c.tileSize         = VLYN_TILE_SIZE;
    c.numStreams        = 4;
    c.mlThreshold      = 0.1f;  // lowered from 0.3: a freshly-initialised network
                                 // outputs scores near 0.5 with high variance;
                                 // 0.3 caused total rejection on first post-warmup
                                 // frame. 0.1 keeps more pairs alive (conservative
                                 // culling) until the network is well-trained.
    c.voronoiEpsilon   = 1e-6f;
    c.enableML         = true;
    c.enableVoronoi    = true;
    c.enableProfiling  = false;
    c.asyncMode        = false;
    c.clusterK         = VLYN_CLUSTER_K;
    c.gjkMaxIter       = VLYN_GJK_MAX_ITER;
    c.epaMaxIter       = VLYN_EPA_MAX_ITER;
    c.contactMergeEps  = 1e-4f;
    return c;
}

// =============================================================================
// Utility: Triangle-Triangle overlap test (Tomas Akenine-Möller 2001)
// Fast version using separating axis theorem
// =============================================================================
VLYN_HOST_DEV bool triTriOverlapSAT(
        const Vec3& a0, const Vec3& a1, const Vec3& a2,
        const Vec3& b0, const Vec3& b1, const Vec3& b2)
{
    // edge vectors
    Vec3 aE[3] = { a1-a0, a2-a1, a0-a2 };
    Vec3 bE[3] = { b1-b0, b2-b1, b0-b2 };

    // Face normals
    Vec3 nA = aE[0].cross(aE[1]);
    Vec3 nB = bE[0].cross(bE[1]);

    auto project = [](const Vec3& axis, const Vec3& p0, const Vec3& p1, const Vec3& p2,
                      float& minV, float& maxV) {
        float v0 = axis.dot(p0), v1 = axis.dot(p1), v2 = axis.dot(p2);
        minV = fminf(v0, fminf(v1, v2));
        maxV = fmaxf(v0, fmaxf(v1, v2));
    };

    auto testAxis = [&](const Vec3& axis) -> bool {
        if (axis.lengthSq() < 1e-10f) return false;
        float amn,amx,bmn,bmx;
        project(axis, a0,a1,a2, amn,amx);
        project(axis, b0,b1,b2, bmn,bmx);
        return amx < bmn || bmx < amn;
    };

    // Test face normals
    if (testAxis(nA)) return false;
    if (testAxis(nB)) return false;

    // Test 9 cross-product axes
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            if (testAxis(aE[i].cross(bE[j]))) return false;

    return true;
}

// =============================================================================
// Utility: Point-in-AABB fast test
// =============================================================================
VLYN_HOST_DEV bool pointInAABB(const Vec3& p, const AABB& b) {
    return (p.x >= b.mn.x) & (p.x <= b.mx.x) &
           (p.y >= b.mn.y) & (p.y <= b.mx.y) &
           (p.z >= b.mn.z) & (p.z <= b.mx.z);
}

// =============================================================================
// Utility: Squared distance between two AABBs
// =============================================================================
VLYN_HOST_DEV float aabbSqDist(const AABB& a, const AABB& b) {
    float dx = fmaxf(0.f, fmaxf(a.mn.x - b.mx.x, b.mn.x - a.mx.x));
    float dy = fmaxf(0.f, fmaxf(a.mn.y - b.mx.y, b.mn.y - a.mx.y));
    float dz = fmaxf(0.f, fmaxf(a.mn.z - b.mx.z, b.mn.z - a.mx.z));
    return dx*dx + dy*dy + dz*dz;
}

// =============================================================================
// Utility: Pseudo-random float [0,1] from seed (xorshift)
// =============================================================================
VLYN_HOST_DEV float randFloat(uint32_t& seed) {
    seed ^= seed << 13;
    seed ^= seed >> 17;
    seed ^= seed << 5;
    return (seed & 0x7fffff) / (float)0x7fffff;
}

// =============================================================================
// Weight layout (GPU memory) — same 3-layer MLP shape as broad-phase net,
// but distinct weight buffers/context since input/output dims differ.
//   W1: [H1 x IN], b1,g1,be1,rm1,rv1: [H1]
//   W2: [H2 x H1], b2,g2,be2,rm2,rv2: [H2]
//   W3: [OUT x H2], b3: [OUT]
// =============================================================================
struct MLNarrowWeights {
    float* W1;   float* b1;
    float* g1;   float* be1;  float* rm1;  float* rv1;

    float* W2;   float* b2;
    float* g2;   float* be2;  float* rm2;  float* rv2;

    float* W3;   float* b3;   // OUT_DIM=5, last row is sigmoid(collisionProb),
                              // remaining 4 rows are linear regression heads

    // Adam moments (online training)
    float* mW1; float* vW1;  float* mb1; float* vb1;
    float* mW2; float* vW2;  float* mb2; float* vb2;
    float* mW3; float* vW3;  float* mb3; float* vb3;

    // Adam moments for BatchNorm gamma/beta
    float* mg1; float* vg1;  float* mbe1; float* vbe1;
    float* mg2; float* vg2;  float* mbe2; float* vbe2;

    // Gradient accumulators (populated by backward pass)
    float* gW1; float* gb1;  float* gg1; float* gbe1;
    float* gW2; float* gb2;  float* gg2; float* gbe2;
    float* gW3; float* gb3;

    int    stepCount;
};

// =============================================================================
// Full narrow-phase ML context
// =============================================================================
struct MLNarrowContext {
    MLNarrowWeights weights;
    cublasHandle_t  cublas;

    // Forward scratch
    float* d_h0;   // [BATCH x IN_DIM]   raw extracted features
    float* d_h1;   // [BATCH x H1_DIM]
    float* d_h2;   // [BATCH x H2_DIM]
    float* d_out;  // [BATCH x OUT_DIM]  = [prob, depth, nx, ny, nz]

    // Backward scratch
    float* d_dh2;
    float* d_dh1;
    float* d_dh0;

    // Cached forward-pass intermediates for a correct backward pass (see
    // VLyn_ml.cu's MLContext for the identical pattern / rationale).
    float* d_xhat1;    // [BATCH x H1_DIM] BN1 normalized values
    float* d_invStd1;  // [H1_DIM]
    float* d_preAct1;  // [BATCH x H1_DIM] post-BN1, pre-LeakyReLU
    float* d_xhat2;    // [BATCH x H2_DIM] BN2 normalized values
    float* d_invStd2;  // [H2_DIM]
    float* d_preAct2;  // [BATCH x H2_DIM] post-BN2, pre-LeakyReLU

    // Feature normalization
    float* d_featMean;  // [IN_DIM]
    float* d_featStd;   // [IN_DIM]

    int    maxBatch;
    bool   trainingMode;

    float  confLow;     // MLN_CONF_LOW  (runtime-tunable)
    float  confHigh;    // MLN_CONF_HIGH (runtime-tunable)

    // Running counters (for stats / adaptive threshold tuning, host-readable)
    uint64_t totalPairs;
    uint64_t mlAcceptedPairs;   // pairs resolved by ML alone (confident)
    uint64_t fallbackPairs;     // pairs that fell back to GJK/EPA
};


// =============================================================================
// End of VLyn_types.cuh
// =============================================================================
