// =============================================================================
// VLyn_ml_internal.cuh  —  Neural Collision Predictor (Internal Header)
// 3-layer fully-connected network with CUDA tensor operations.
// Predicts collision probability for cluster pairs — rejects 98%+ of pairs
// before expensive Voronoi/GJK narrow phase.
// =============================================================================
#ifndef VLYN_ML_INTERNAL_CUH
#define VLYN_ML_INTERNAL_CUH

#include "VLyn_types.cuh"
#include <cuda_runtime.h>
#include <cublas_v2.h>

// =============================================================================
// Layer dimensions
// =============================================================================
#define ML_IN_DIM       64   // (VLYN_ML_FEATURE_DIM * 2) — two clusters concatenated
#define ML_H1_DIM       128
#define ML_H2_DIM       64
#define ML_OUT_DIM      1

// Batch size for GPU inference
#define ML_BATCH_SIZE   4096

// Leaky ReLU slope
#define ML_LEAKY_ALPHA  0.01f

// Adam optimizer hyperparameters
#define ML_LR           1e-3f
#define ML_BETA1        0.9f
#define ML_BETA2        0.999f
#define ML_EPSILON      1e-8f

// =============================================================================
// Weight layout (GPU memory):
//   W1: [ML_H1_DIM x ML_IN_DIM]
//   b1: [ML_H1_DIM]
//   g1: [ML_H1_DIM]  — BN gamma
//   be1:[ML_H1_DIM]  — BN beta
//   rm1:[ML_H1_DIM]  — BN running mean
//   rv1:[ML_H1_DIM]  — BN running var
//   W2: [ML_H2_DIM x ML_H1_DIM]
//   b2: [ML_H2_DIM]
//   g2: [ML_H2_DIM]
//   be2:[ML_H2_DIM]
//   rm2:[ML_H2_DIM]
//   rv2:[ML_H2_DIM]
//   W3: [ML_OUT_DIM x ML_H2_DIM]
//   b3: [ML_OUT_DIM]
// =============================================================================
struct MLWeights {
    float* W1;   // [H1 x IN]
    float* b1;
    float* g1;   // BN gamma
    float* be1;  // BN beta
    float* rm1;  // BN running mean
    float* rv1;  // BN running var

    float* W2;   // [H2 x H1]
    float* b2;
    float* g2;
    float* be2;
    float* rm2;
    float* rv2;

    float* W3;   // [OUT x H2]
    float* b3;

    // Adam moments (for online training)
    float* mW1; float* vW1;
    float* mb1; float* vb1;
    float* mW2; float* vW2;
    float* mb2; float* vb2;
    float* mW3; float* vW3;
    float* mb3; float* vb3;

    // Adam moments for BatchNorm gamma/beta
    float* mg1;  float* vg1;  float* mbe1; float* vbe1;
    float* mg2;  float* vg2;  float* mbe2; float* vbe2;

    // Gradient accumulators (populated by backward pass, consumed by Adam step)
    float* gW1; float* gb1; float* gg1; float* gbe1;
    float* gW2; float* gb2; float* gg2; float* gbe2;
    float* gW3; float* gb3;

    int    stepCount;  // for Adam bias correction
};

// =============================================================================
// Full ML context
// =============================================================================
struct MLContext {
    MLWeights weights;
    cublasHandle_t cublas;

    // Scratch buffers for forward pass
    float* d_h0;   // [BATCH x IN_DIM]
    float* d_h1;   // [BATCH x H1_DIM]
    float* d_h2;   // [BATCH x H2_DIM]
    float* d_out;  // [BATCH x OUT_DIM]

    // Scratch for backward pass
    float* d_dh2;
    float* d_dh1;
    float* d_dh0;

    // Cached forward-pass intermediates needed for a correct backward pass.
    // BN "xhat" (normalized-before-scale/shift) and per-feature invStd are
    // required by the batchnorm backward formula; the pre-LeakyReLU (i.e.
    // post-BN) values are required to reconstruct the LeakyReLU derivative
    // mask (>0 ? 1 : alpha).
    float* d_xhat1;    // [BATCH x H1_DIM] BN1 normalized values
    float* d_invStd1;  // [H1_DIM] BN1 1/sqrt(var+eps) for this batch
    float* d_preAct1;  // [BATCH x H1_DIM] post-BN1, pre-LeakyReLU (BN1 output)
    float* d_xhat2;    // [BATCH x H2_DIM] BN2 normalized values
    float* d_invStd2;  // [H2_DIM] BN2 1/sqrt(var+eps) for this batch
    float* d_preAct2;  // [BATCH x H2_DIM] post-BN2, pre-LeakyReLU (BN2 output)

    // Feature normalization statistics (running mean/std per feature)
    float* d_featMean;  // [IN_DIM] running mean for online normalization
    float* d_featStd;   // [IN_DIM] running std  for online normalization
    float* d_featCount; // [IN_DIM] total samples seen (Welford running count)

    int    maxBatch;
    bool   trainingMode;
    float  threshold;
};

// =============================================================================
// ML API prototypes (called from VLyn_core.cu)
// =============================================================================

// Allocate and initialize ML context with CUBLAS handle and GPU memory
VLynError mlAllocContext(MLContext* ctx, float threshold);

// Initialize neural network weights (Xavier initialization + batch norm)
VLynError mlInitWeights(MLContext* ctx);

// Forward pass: inference on cluster pair features
VLynError mlForward(
    MLContext* ctx,
    const float* d_input,
    float* d_output,
    int batch,
    cudaStream_t stream);

// Training step: batched gradient descent update using confirmed collision
// ground truth. d_features is [batch x ML_IN_DIM], d_labels is [batch],
// values 1.0 = collision, 0.0 = no collision (both on device).
VLynError mlTrainStep(
    MLContext* ctx,
    const float* d_features,
    const float* d_labels,
    int batch,
    cudaStream_t stream);

// Warm-up training: run the exact Voronoi/GJK-EPA solver on the BVH pair
// list, reduce multi-contact results to per-pair binary labels, and take
// one mlTrainStep. Used during the warm-up phase before ML inference begins.
VLynError mlTrainOnFallbackBroad(
    MLContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const Cluster* d_clustersA,
    const Cluster* d_clustersB,
    const uint64_t* d_bvhPairs,
    int nPairs,
    int gjkIter, int epaIter,
    cudaStream_t stream);

// Inference and filtering: given ORIGINAL triangle pairs from the BVH broad
// phase (uint64_t, [32:triIdxA|32:triIdxB]), look up each triangle's cluster
// (Triangle::clusterId) and filter by ML score. Output stays in the same
// uint64_t triangle-pair format so it can be fed directly into the
// narrow-phase stage without any additional translation.
VLynError mlInferAndFilter(
    MLContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const Cluster* d_clustersA,
    const Cluster* d_clustersB,
    const uint64_t* d_trianglePairs,
    int nPairs,
    uint64_t* d_filteredPairs,
    uint32_t* d_filteredCount,
    uint32_t maxFiltered,
    cudaStream_t stream);

// Free GPU memory associated with ML context
VLynError mlFreeContext(MLContext* ctx);

#endif // VLYN_ML_INTERNAL_CUH
