// =============================================================================
// VLyn_ml_narrow_internal.cuh  —  Neural Narrow-Phase Predictor (Internal Header)
//
// Broad-phase ML (VLyn_ml_internal.cuh) predicts "should this cluster pair even
// be considered" and rejects ~98% of pairs before GJK/EPA. This header defines
// a SECOND, separate network that operates one stage later, on surviving
// TRIANGLE pairs, and predicts the actual narrow-phase RESULT:
//
//      [ collisionProb, penetrationDepth, normal.x, normal.y, normal.z ]
//
// i.e. it tries to regress exactly what narrowPhasePair() (GJK+EPA) would have
// computed, so that on high-confidence pairs we can skip GJK/EPA entirely and
// on low-confidence pairs we fall back to the exact geometric solver. This is
// a confidence-gated approximation, not a filter — the exact solver is always
// the ground truth and the network is trained online against its output.
// =============================================================================
#ifndef VLYN_ML_NARROW_INTERNAL_CUH
#define VLYN_ML_NARROW_INTERNAL_CUH

#include "VLyn_types.cuh"
#include <cuda_runtime.h>
#include <cublas_v2.h>

// =============================================================================
// Feature layout (24 dims, per triangle pair — NOT cluster-level)
//   [0-2]   nA (face normal of triangle A)
//   [3-5]   nB (face normal of triangle B)
//   [6]     dot(nA, nB)                     — orientation alignment
//   [7-9]   centroidB - centroidA (raw offset vector)
//   [10]    |centroidB - centroidA|         — center distance
//   [11]    areaA
//   [12]    areaB
//   [13]    log(areaA / max(areaB,eps))     — scale ratio (log for symmetry)
//   [14]    minEdgeLenA
//   [15]    minEdgeLenB
//   [16]    maxEdgeLenA
//   [17]    maxEdgeLenB
//   [18]    projDist  = dot(centroidB-centroidA, nA)   — signed dist along A's normal
//   [19]    projDistB = dot(centroidA-centroidB, nB)   — signed dist along B's normal
//   [20]    aabbSqDist(triA.aabb(), triB.aabb())
//   [21]    coplanarity = 1 - |dot(nA,nB)|              — near-0 if parallel
//   [22-23] reserved / padding (kept 0, future features)
// =============================================================================
#define MLN_FEATURE_DIM     24
#define MLN_IN_DIM          24   // single triangle-pair feature vector (not concatenated x2)
#define MLN_H1_DIM          96
#define MLN_H2_DIM          48
#define MLN_OUT_DIM         5    // [collisionProb, penetrationDepth, nx, ny, nz]

#define MLN_BATCH_SIZE      4096

#define MLN_LEAKY_ALPHA     0.01f

#define MLN_LR              5e-4f
#define MLN_BETA1           0.9f
#define MLN_BETA2           0.999f
#define MLN_EPSILON         1e-8f

// Confidence gating thresholds:
//   collisionProb outside [MLN_LOW, MLN_HIGH]  -> confident, trust the network
//   collisionProb inside  [MLN_LOW, MLN_HIGH]  -> ambiguous, fall back to GJK/EPA
#define MLN_CONF_LOW        0.08f
#define MLN_CONF_HIGH       0.92f

// =============================================================================
// Kernel prototypes
// =============================================================================

// Extract per-triangle-pair feature vectors (see layout above) directly from
// the surviving BVH/broad-phase-ML pair list, one thread per pair.
__global__ void kernelExtractNarrowPairFeatures(
    const Triangle* __restrict__ d_trisA,
    const Triangle* __restrict__ d_trisB,
    const uint64_t* __restrict__ d_pairs,   // packed (idxA<<32 | idxB)
    int nPairs,
    float* d_features,          // [nPairs x MLN_IN_DIM]
    const float* d_featMean,
    const float* d_featStd);

// Consume network output and split pairs into two buckets:
//   d_confidentPairs  — write directly to CollisionResult (no GJK/EPA)
//   d_fallbackPairs   — must still go through narrowPhasePair()
__global__ void kernelGateNarrowPredictions(
    const uint64_t* __restrict__ d_pairs,
    const float* __restrict__ d_mlOut,      // [nPairs x MLN_OUT_DIM]
    int nPairs,
    const Triangle* __restrict__ d_trisA,
    const Triangle* __restrict__ d_trisB,
    float confLow, float confHigh,
    CollisionResult* d_results,
    uint32_t* d_resultCount,
    uint32_t maxResults,
    uint64_t* d_fallbackPairs,
    uint32_t* d_fallbackCount,
    uint32_t maxFallback);

// =============================================================================
// Host API (mirrors VLyn_ml_internal.cuh's mlAlloc/mlInit/mlForward pattern)
// =============================================================================

// Allocate context, weight buffers, cublas handle.
VLynError mlnAllocContext(MLNarrowContext* ctx, float confLow = MLN_CONF_LOW,
                           float confHigh = MLN_CONF_HIGH);

// Xavier init + batch-norm defaults, output layer biased toward "uncertain"
// (prob head bias ~0, so sigmoid(0)=0.5 => everything falls back until trained).
VLynError mlnInitWeights(MLNarrowContext* ctx);

// Forward pass only: d_input [batch x IN_DIM] -> d_output [batch x OUT_DIM]
VLynError mlnForward(
    MLNarrowContext* ctx,
    const float* d_input,
    float* d_output,
    int batch,
    cudaStream_t stream);

// Online training step against a ground-truth GJK/EPA result for ONE pair.
// label = { didCollide(0/1), penetrationDepth, normal.x, normal.y, normal.z }.
// Called opportunistically whenever the fallback path computes an exact
// result, so the network keeps learning from its own mistakes.
VLynError mlnTrainStep(
    MLNarrowContext* ctx,
    const float* d_input,       // [1 x IN_DIM]
    const float* d_label,       // [1 x OUT_DIM] ground truth from GJK/EPA
    cudaStream_t stream);

// Batched training step (multiple ground-truth pairs at once — more efficient
// than one-at-a-time mlnTrainStep during heavy fallback traffic).
VLynError mlnTrainBatch(
    MLNarrowContext* ctx,
    const float* d_inputs,      // [batch x IN_DIM]
    const float* d_labels,      // [batch x OUT_DIM]
    int batch,
    cudaStream_t stream);

// Full pipeline: extract features -> forward -> gate -> partial results +
// fallback pair list for exact narrow phase. This is the function
// VLyn_core.cu / VLyn_voronoi.cu call in place of (or ahead of) the direct
// narrowPhasePair() sweep.
VLynError mlnPredictNarrowPhase(
    MLNarrowContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const uint64_t* d_pairs,
    int nPairs,
    CollisionResult* d_results,
    uint32_t* d_resultCount,
    uint32_t maxResults,
    uint64_t* d_fallbackPairs,
    uint32_t* d_fallbackCount,
    uint32_t maxFallback,
    cudaStream_t stream);

// Online training entry point: given the fallback pair list that was just
// resolved exactly by voronoiNarrowPhase(), recomputes ground-truth labels
// for those same pairs (via the exact GJK/EPA solver) and takes one Adam
// training step, so the network specifically learns from the pairs it was
// uncertain about. Call this AFTER voronoiNarrowPhase() has run on the same
// fallback pair list for a given query.
VLynError mlnTrainOnFallback(
    MLNarrowContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const uint64_t* d_pairs,
    int nPairs,
    int gjkIter, int epaIter,
    cudaStream_t stream);

// Free all GPU memory owned by ctx.
VLynError mlnFreeContext(MLNarrowContext* ctx);

// =============================================================================
// Device-side feature extraction (used by kernelExtractNarrowPairFeatures and
// available for reuse/testing)
// =============================================================================
__device__ void mlnExtractPairFeature(const Triangle& tA, const Triangle& tB, float* f);

#endif // VLYN_ML_NARROW_INTERNAL_CUH
