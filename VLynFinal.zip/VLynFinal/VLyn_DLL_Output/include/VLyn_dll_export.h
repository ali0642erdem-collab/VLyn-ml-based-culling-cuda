#ifndef VLYN_DLL_EXPORT_H
#define VLYN_DLL_EXPORT_H

// Linux'ta __declspec yok, GCC visibility kullanıyoruz
#if defined(_WIN32) || defined(__CYGWIN__)
  #ifdef VLYN_DLL_EXPORTS
    #define VLYN_API __declspec(dllexport)
  #else
    #ifdef VLYN_DLL_IMPORTS
      #define VLYN_API __declspec(dllimport)
    #else
      #define VLYN_API
    #endif
  #endif
#else
  // Linux/GCC
  #ifdef VLYN_DLL_EXPORTS
    #define VLYN_API __attribute__((visibility("default")))
  #else
    #define VLYN_API
  #endif
#endif

// Suppress __declspec warnings on Linux
#ifndef _WIN32
  #define __declspec(x)
#endif

#endif // VLYN_DLL_EXPORT_H
