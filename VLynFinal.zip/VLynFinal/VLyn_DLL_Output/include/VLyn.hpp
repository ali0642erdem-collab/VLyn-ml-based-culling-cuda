// =============================================================================
// VLyn.hpp  —  Modern C++ Wrapper API
// VLyn High-Performance Geometric Collision Detection Library
//
// Provides RAII, STL-friendly, exception-safe C++ interface over the C API.
// Include this instead of VLyn.h for C++ projects.
// =============================================================================
#pragma once

#ifndef VLYN_H   // include VLyn.h only if not already included
#  include "VLyn.h"
#endif
#include <vector>
#include <stdexcept>
#include <string>
#include <cstring>
#include <array>
#include <functional>

namespace vlyn {

// =============================================================================
// Error handling
// =============================================================================

class VLynException : public std::runtime_error {
public:
    explicit VLynException(VLynError code, const std::string& msg = "")
        : std::runtime_error("VLyn error " + std::to_string((int)code)
                             + (msg.empty() ? "" : ": " + msg))
        , code_(code) {}

    VLynError code() const noexcept { return code_; }

private:
    VLynError code_;
};

inline void check(VLynError e, const char* context = "") {
    if (e != VLYN_OK)
        throw VLynException(e, context);
}

// =============================================================================
// Vec3 — thin C++ wrapper around VLynVec3
// =============================================================================

struct Vec3 : VLynVec3 {
    Vec3() noexcept { x = y = z = _pad = 0.f; }
    Vec3(float x, float y, float z) noexcept {
        this->x = x; this->y = y; this->z = z; this->_pad = 0.f;
    }
    explicit Vec3(const VLynVec3& v) noexcept : VLynVec3(v) {}

    Vec3  operator+(const Vec3& o) const noexcept { return {x+o.x, y+o.y, z+o.z}; }
    Vec3  operator-(const Vec3& o) const noexcept { return {x-o.x, y-o.y, z-o.z}; }
    Vec3  operator*(float s)       const noexcept { return {x*s,   y*s,   z*s};   }
    float dot(const Vec3& o)       const noexcept { return x*o.x + y*o.y + z*o.z; }
    float lengthSq()               const noexcept { return dot(*this); }
    float length()                 const noexcept { return std::sqrt(lengthSq()); }
};

// =============================================================================
// Transform helper
// =============================================================================

struct Transform : VLynTransform {
    Transform() noexcept {
        pos = Vec3(0,0,0);
        rot = {1.f, 0.f, 0.f, 0.f};
        scale = 1.f;
    }
    Transform(Vec3 pos, VLynQuat rot = {1,0,0,0}, float scale = 1.f) noexcept {
        this->pos   = pos;
        this->rot   = rot;
        this->scale = scale;
    }

    static Transform identity() noexcept { return {}; }

    static Transform translation(float tx, float ty, float tz) noexcept {
        Transform t;
        t.pos = Vec3(tx, ty, tz);
        return t;
    }
};

// =============================================================================
// ContactPoint / CollisionResult wrappers
// =============================================================================

using ContactPoint    = VLynContactPoint;
using CollisionResult = VLynCollisionResult;

// =============================================================================
// Config builder
// =============================================================================

struct Config : VLynConfig {
    Config() noexcept {
        *static_cast<VLynConfig*>(this) = VLynDefaultConfigC();
    }

    Config& device(int d)               noexcept { gpuDevice       = d;    return *this; }
    Config& streams(int n)              noexcept { numStreams       = n;    return *this; }
    Config& ml(bool on)                 noexcept { enableML        = on;   return *this; }
    Config& voronoi(bool on)            noexcept { enableVoronoi   = on;   return *this; }
    Config& profiling(bool on)          noexcept { enableProfiling = on;   return *this; }
    Config& mlThresh(float t)           noexcept { mlThreshold     = t;    return *this; }
    Config& clusters(int k)             noexcept { clusterK        = k;    return *this; }
    Config& gjkIter(int n)              noexcept { gjkMaxIter      = n;    return *this; }
    Config& epaIter(int n)              noexcept { epaMaxIter      = n;    return *this; }
    Config& maxMesh(int n)              noexcept { maxMeshes       = n;    return *this; }
    Config& async(bool on)              noexcept { this->asyncMode = on;   return *this; }
};

// =============================================================================
// MeshId — strong typedef to avoid raw int confusion
// =============================================================================

struct MeshId {
    int value;
    explicit MeshId(int v) noexcept : value(v) {}
    bool valid() const noexcept { return value >= 0; }
    operator int() const noexcept { return value; }
};

// =============================================================================
// Context — RAII wrapper around CVSHandle
// =============================================================================

class Context {
public:
    // Non-copyable
    Context(const Context&)            = delete;
    Context& operator=(const Context&) = delete;

    // Movable
    Context(Context&& o) noexcept : handle_(o.handle_) { o.handle_ = nullptr; }
    Context& operator=(Context&& o) noexcept {
        if (this != &o) { destroy(); handle_ = o.handle_; o.handle_ = nullptr; }
        return *this;
    }

    // Construct from config
    explicit Context(const Config& cfg = Config()) {
        handle_ = CVSCrt(static_cast<const VLynConfig*>(&cfg));
        if (!handle_)
            throw VLynException(VLYN_ERR_CUDA, "CVSCrt failed — no GPU or CUDA error");
    }

    ~Context() { destroy(); }

    // ------------------------------------------------------------------
    // Mesh registration
    // ------------------------------------------------------------------

    /**
     * Add a mesh from raw vertex + index arrays.
     * @param verts     std::vector of Vec3 vertices
     * @param indices   std::vector of uint32_t indices (3 per triangle)
     * @return MeshId
     */
    MeshId addMesh(const std::vector<Vec3>&     verts,
                   const std::vector<uint32_t>& indices)
    {
        if (indices.size() % 3 != 0)
            throw std::invalid_argument("indices.size() must be a multiple of 3");

        uint32_t triCount = static_cast<uint32_t>(indices.size() / 3);
        int id = CVSAddMesh(handle_,
                            reinterpret_cast<const VLynVec3*>(verts.data()),
                            indices.data(),
                            triCount);
        if (id < 0) throw VLynException(static_cast<VLynError>(id), "CVSAddMesh");
        return MeshId(id);
    }

    /**
     * Add a mesh from raw pointer arrays (zero-copy path).
     */
    MeshId addMesh(const VLynVec3*  verts,
                   const uint32_t*  indices,
                   uint32_t         triCount)
    {
        int id = CVSAddMesh(handle_, verts, indices, triCount);
        if (id < 0) throw VLynException(static_cast<VLynError>(id), "CVSAddMesh");
        return MeshId(id);
    }

    void removeMesh(MeshId id) {
        check(CVSRemoveMesh(handle_, id.value), "CVSRemoveMesh");
    }

    void setTransform(MeshId id, const Transform& t) {
        check(CVSSetTransform(handle_, id.value,
                              static_cast<const VLynTransform*>(&t)),
              "CVSSetTransform");
    }

    // ------------------------------------------------------------------
    // Collision queries
    // ------------------------------------------------------------------

    /**
     * Query collision between two meshes.
     * Returns vector of CollisionResult (may be empty if no contact).
     */
    std::vector<CollisionResult> query(MeshId a, MeshId b,
                                       uint32_t maxResults = 256)
    {
        std::vector<CollisionResult> buf(maxResults);
        uint32_t cnt = 0;
        check(CVSQuery(handle_, a.value, b.value,
                       buf.data(), &cnt, maxResults),
              "CVSQuery");
        buf.resize(cnt);
        return buf;
    }

    /**
     * Query collision — writes into caller-supplied buffer.
     * Returns number of results written.
     */
    uint32_t query(MeshId a, MeshId b,
                   CollisionResult* outBuf, uint32_t maxResults)
    {
        uint32_t cnt = 0;
        check(CVSQuery(handle_, a.value, b.value, outBuf, &cnt, maxResults),
              "CVSQuery");
        return cnt;
    }

    /**
     * Query all mesh pairs.
     */
    std::vector<CollisionResult> queryAll(uint32_t maxResults = 4096) {
        std::vector<CollisionResult> buf(maxResults);
        uint32_t cnt = 0;
        check(CVSQueryAll(handle_, buf.data(), &cnt, maxResults), "CVSQueryAll");
        buf.resize(cnt);
        return buf;
    }

    /**
     * Returns true if meshes A and B are colliding (any contact).
     */
    bool intersects(MeshId a, MeshId b) {
        CollisionResult r;
        uint32_t cnt = 0;
        VLynError e = CVSQuery(handle_, a.value, b.value, &r, &cnt, 1);
        return (e == VLYN_OK) && (cnt > 0);
    }

    // ------------------------------------------------------------------
    // Profiling
    // ------------------------------------------------------------------

    VLynStats stats() const {
        VLynStats s{};
        CVSGetStats(handle_, &s);
        return s;
    }

    void resetStats() {
        CVSResetStats(handle_);
    }

    // ------------------------------------------------------------------
    // Accessors
    // ------------------------------------------------------------------

    CVSHandle nativeHandle() const noexcept { return handle_; }
    bool      valid()        const noexcept { return handle_ != nullptr; }

    static const char* version() noexcept { return CVSVersion(); }

private:
    CVSHandle handle_ = nullptr;

    void destroy() noexcept {
        if (handle_) { CVSDestroy(handle_); handle_ = nullptr; }
    }
};

// =============================================================================
// Convenience free functions
// =============================================================================

/**
 * One-shot collision check: creates a temporary context, adds two meshes,
 * queries, returns results. Useful for scripting/testing.
 */
inline std::vector<CollisionResult>
quickQuery(const std::vector<Vec3>&     vertsA,
           const std::vector<uint32_t>& indicesA,
           const std::vector<Vec3>&     vertsB,
           const std::vector<uint32_t>& indicesB,
           Config cfg = Config().ml(false))
{
    Context ctx(cfg);
    MeshId a = ctx.addMesh(vertsA, indicesA);
    MeshId b = ctx.addMesh(vertsB, indicesB);
    return ctx.query(a, b);
}

} // namespace vlyn
