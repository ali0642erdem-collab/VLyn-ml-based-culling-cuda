// =============================================================================
// VLyn.h  —  Public C/C++ API Header
// VLyn High-Performance Geometric Collision Detection Library
// Include this header in your project to use the VLyn API.
// =============================================================================
#pragma once
#ifndef VLYN_H
#define VLYN_H

// Include DLL export configuration if building as DLL
#ifdef BUILDING_VLYN_DLL
    #include "VLyn_dll_export.h"
#else
    #define VLYN_API
#endif

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// -- Version
#define VLYN_API_VERSION_MAJOR 2
#define VLYN_API_VERSION_MINOR 0
#define VLYN_API_VERSION_PATCH 0

/**
 * Internal capacity of the GPU-side collision result buffer, in
 * VLynCollisionResult elements. CVSQuery()/CVSQueryAll() will never write
 * more than min(maxResults, VLYN_MAX_RESULTS_CAPACITY) results regardless
 * of what maxResults you pass — but the caller's h_results array itself
 * still must be sized to at least maxResults elements, since the library
 * has no way to verify the caller's actual allocation size. Do NOT
 * redefine a same-named "CVS_MAX_RESULTS" constant yourself with a
 * different value; use this one, or your own smaller cap, consistently
 * for both the array allocation size and the maxResults argument.
 */
#define VLYN_MAX_RESULTS_CAPACITY (1u << 16)  // 65536

// -- Opaque handle
typedef struct CVSContext* CVSHandle;

// -- Error codes (mirrors VLyn_types.cuh)
typedef enum {
    VLYN_OK                  = 0,
    VLYN_ERR_CUDA            = -1,
    VLYN_ERR_OOM             = -2,
    VLYN_ERR_NULL_PTR        = -3,
    VLYN_ERR_INVALID_MESH    = -4,
    VLYN_ERR_MAX_MESHES      = -5,
    VLYN_ERR_NOT_INITIALIZED = -6,
    VLYN_ERR_STREAM          = -7,
    VLYN_ERR_BVH_BUILD       = -8,
    VLYN_ERR_ML_INFERENCE    = -9,
    VLYN_ERR_VORONOI         = -10,
} VLynError;

// -- Simple 3D vector (binary-compatible with VLyn_types.cuh Vec3)
// alignas(16) matches the internal Vec3, so sizeof(VLynContactPoint)==80 and
// sizeof(VLynCollisionResult)==384, identical to the internal structs.
#ifdef __cplusplus
typedef struct alignas(16) { float x, y, z, _pad; } VLynVec3;
#else
// C11 _Alignas or __attribute__((aligned(16))) for C callers
typedef struct { float x, y, z, _pad; } __attribute__((aligned(16))) VLynVec3;
#endif

// -- Quaternion
typedef struct { float w, x, y, z;   } VLynQuat;

// -- Transform
typedef struct {
    VLynVec3 pos;
    VLynQuat rot;
    float    scale;
} VLynTransform;

// -- Contact point
typedef struct {
    VLynVec3 position;
    VLynVec3 normal;
    float    penetrationDepth;
    float    separation;
    uint32_t triIdA, triIdB;
    uint32_t meshIdA, meshIdB;
    float    confidence;
    uint32_t voronoiRegion;
    uint32_t _pad[2];
} VLynContactPoint;

// -- Collision result
typedef struct {
    uint32_t        meshIdA, meshIdB;
    uint32_t        contactCount;
    uint32_t        flags;
    VLynContactPoint contacts[4];
    float           closestDist;
    VLynVec3        separatingAxis;
    double          timestamp;
} VLynCollisionResult;

// -- Configuration
typedef struct {
    int   maxMeshes;
    int   gpuDevice;
    size_t tileSize;
    int   numStreams;
    float mlThreshold;
    float voronoiEpsilon;
    bool  enableML;
    bool  enableVoronoi;
    bool  enableProfiling;
    bool  asyncMode;
    int   clusterK;
    int   gjkMaxIter;
    int   epaMaxIter;
    float contactMergeEps;
    bool  enableOnlineTraining;
} VLynConfig;

// -- Stats
typedef struct {
    double   meshScanMs, bvhBuildMs, mlInferenceMs, voronoiMs, totalMs;
    uint64_t candidatePairs, mlRejected, narrowPhasePairs, contactsFound;
    float    mlAcceptRate, throughputMTriPerSec;
} VLynStats;

// =============================================================================
// API Functions
// =============================================================================

/** Create a VLyn context. Returns NULL on failure. */
VLYN_API CVSHandle   CVSCrt(const VLynConfig* cfg);

/** Destroy context and free all GPU resources. */
VLYN_API void        CVSDestroy(CVSHandle handle);

/**
 * Register a triangle mesh.
 * @param h_verts    Host array of vertices (VLynVec3[])
 * @param h_indices  Host array of indices (uint32_t[triCount*3])
 * @param triCount   Number of triangles
 * @return meshId (>=0) on success, negative VLynError on failure.
 */
VLYN_API int         CVSAddMesh(CVSHandle handle,
                       const VLynVec3*   h_verts,
                       const uint32_t*  h_indices,
                       uint32_t         triCount);

/** Unregister and free a mesh. */
VLYN_API VLynError   CVSRemoveMesh(CVSHandle handle, int meshId);

/** Update the rigid-body transform of a mesh. BVH rebuilt lazily. */
VLYN_API VLynError   CVSSetTransform(CVSHandle handle, int meshId,
                             const VLynTransform* t);

/**
 * Run full collision detection between two meshes.
 *
 * IMPORTANT — buffer sizing: h_results must point to an ARRAY of at least
 * maxResults VLynCollisionResult elements (NOT a single struct). A single
 * mesh pair query can find MANY colliding triangle pairs — one
 * VLynCollisionResult is written per colliding triangle pair found, up to
 * maxResults of them. Passing the address of a single struct with
 * maxResults > 1 will cause an out-of-bounds write (stack/heap corruption,
 * access violation) as soon as more than one triangle-pair collision is
 * found. Example of correct usage:
 *
 *     std::vector<VLynCollisionResult> results(256);
 *     uint32_t count = 0;
 *     CVSQuery(ctx, meshA, meshB, results.data(), &count, (uint32_t)results.size());
 *
 * @param h_results   Caller-supplied output ARRAY (capacity == maxResults).
 * @param resultCount Set to number of results actually written (<= maxResults).
 * @param maxResults  Capacity of h_results, in VLynCollisionResult elements.
 */
VLYN_API VLynError   CVSQuery(CVSHandle handle,
                     int meshIdA, int meshIdB,
                     VLynCollisionResult* h_results,
                     uint32_t* resultCount,
                     uint32_t  maxResults);

/**
 * Run CVSQuery for all distinct mesh pairs (i < j).
 * Same buffer-sizing contract as CVSQuery: h_results must be an array of
 * at least maxResults elements, not a single struct.
 */
VLYN_API VLynError   CVSQueryAll(CVSHandle handle,
                        VLynCollisionResult* h_results,
                        uint32_t* resultCount,
                        uint32_t  maxResults);

/** Retrieve profiling statistics. */
VLYN_API VLynError   CVSGetStats(CVSHandle handle, VLynStats* stats);

/** Zero profiling counters. */
VLYN_API VLynError   CVSResetStats(CVSHandle handle);

/** Return version string, e.g. "2.0.0". */
VLYN_API const char* CVSVersion(void);

/** Return a default configuration. */
static inline VLynConfig VLynDefaultConfigC(void) {
    VLynConfig c = {0};
    c.maxMeshes      = 64;
    c.gpuDevice      = -1;
    c.tileSize       = 65536;
    c.numStreams      = 4;
    c.mlThreshold    = 0.1f;  // lowered from 0.3 — see VLyn_types.cuh
    c.voronoiEpsilon = 1e-6f;
    c.enableML       = true;
    c.enableVoronoi  = true;
    c.enableProfiling= false;
    c.asyncMode      = false;
    c.clusterK       = 512;
    c.gjkMaxIter     = 64;
    c.epaMaxIter     = 32;
    c.contactMergeEps= 1e-4f;
    c.enableOnlineTraining = false;
    return c;
}

#ifdef __cplusplus
} // extern "C"
#endif
#endif // VLYN_H
