// =============================================================================
// VLyn_dll_wrapper.hpp  —  C++ Wrapper for VLyn DLL
// Provides a modern C++ interface while maintaining DLL compatibility
// =============================================================================

#pragma once

#ifndef VLYN_DLL_WRAPPER_HPP
#define VLYN_DLL_WRAPPER_HPP

// Include the export configuration
#include "VLyn_dll_export.h"

// Include the original C API
#include "VLyn.h"

#ifdef __cplusplus

namespace VLyn {

// =============================================================================
// C++ Wrapper Classes for Type Safety and Ease of Use
// =============================================================================

// Forward declarations
class Context;
struct ContactPoint;
struct CollisionResult;
struct Config;
struct Stats;

// =============================================================================
// Vec3 Wrapper
// =============================================================================
struct Vec3 {
    float x, y, z;
    
    Vec3() : x(0), y(0), z(0) {}
    Vec3(float x_, float y_, float z_) : x(x_), y(y_), z(z_) {}
    
    // Convert from C API
    Vec3(const VLynVec3& v) : x(v.x), y(v.y), z(v.z) {}
    
    // Convert to C API
    operator VLynVec3() const {
        VLynVec3 v;
        v.x = x; v.y = y; v.z = z; v._pad = 0;
        return v;
    }
};

// =============================================================================
// Quaternion Wrapper
// =============================================================================
struct Quat {
    float w, x, y, z;
    
    Quat() : w(1), x(0), y(0), z(0) {}
    Quat(float w_, float x_, float y_, float z_) : w(w_), x(x_), y(y_), z(z_) {}
    
    // Convert from C API
    Quat(const VLynQuat& q) : w(q.w), x(q.x), y(q.y), z(q.z) {}
    
    // Convert to C API
    operator VLynQuat() const { return {w, x, y, z}; }
};

// =============================================================================
// Transform Wrapper
// =============================================================================
struct Transform {
    Vec3 pos;
    Quat rot;
    float scale;
    
    Transform() : scale(1.0f) {}
    
    // Convert from C API
    Transform(const VLynTransform& t) 
        : pos(t.pos), rot(t.rot), scale(t.scale) {}
    
    // Convert to C API
    operator VLynTransform() const {
        VLynTransform t;
        t.pos = pos;
        t.rot = rot;
        t.scale = scale;
        return t;
    }
};

// =============================================================================
// ContactPoint Wrapper
// =============================================================================
struct ContactPoint {
    Vec3     position;
    Vec3     normal;
    float    penetrationDepth;
    float    separation;
    uint32_t triIdA, triIdB;
    uint32_t meshIdA, meshIdB;
    float    confidence;
    uint32_t voronoiRegion;
    
    // Convert from C API
    ContactPoint(const VLynContactPoint& cp)
        : position(cp.position)
        , normal(cp.normal)
        , penetrationDepth(cp.penetrationDepth)
        , separation(cp.separation)
        , triIdA(cp.triIdA)
        , triIdB(cp.triIdB)
        , meshIdA(cp.meshIdA)
        , meshIdB(cp.meshIdB)
        , confidence(cp.confidence)
        , voronoiRegion(cp.voronoiRegion)
    {}
    
    // Convert to C API
    operator VLynContactPoint() const {
        VLynContactPoint cp;
        cp.position = position;
        cp.normal = normal;
        cp.penetrationDepth = penetrationDepth;
        cp.separation = separation;
        cp.triIdA = triIdA;
        cp.triIdB = triIdB;
        cp.meshIdA = meshIdA;
        cp.meshIdB = meshIdB;
        cp.confidence = confidence;
        cp.voronoiRegion = voronoiRegion;
        memset(cp._pad, 0, sizeof(cp._pad));
        return cp;
    }
    
private:
    void memset(void*, int, size_t) {}
};

// =============================================================================
// CollisionResult Wrapper
// =============================================================================
struct CollisionResult {
    uint32_t           meshIdA, meshIdB;
    uint32_t           contactCount;
    uint32_t           flags;
    std::vector<ContactPoint> contacts;
    float              closestDist;
    Vec3               separatingAxis;
    double             timestamp;
    
    // Convert from C API
    CollisionResult(const VLynCollisionResult& cr)
        : meshIdA(cr.meshIdA)
        , meshIdB(cr.meshIdB)
        , contactCount(cr.contactCount)
        , flags(cr.flags)
        , closestDist(cr.closestDist)
        , separatingAxis(cr.separatingAxis)
        , timestamp(cr.timestamp)
    {
        contacts.reserve(cr.contactCount);
        for (uint32_t i = 0; i < cr.contactCount; ++i) {
            contacts.emplace_back(cr.contacts[i]);
        }
    }
};

// =============================================================================
// Config Wrapper
// =============================================================================
struct Config {
    int   maxMeshes;
    int   gpuDevice;
    size_t tileSize;
    int   numStreams;
    float mlThreshold;
    float voronoiEpsilon;
    bool  enableML;
    bool  enableVoronoi;
    bool  enableProfiling;
    bool  asyncMode;
    int   clusterK;
    int   gjkMaxIter;
    int   epaMaxIter;
    float contactMergeEps;
    bool  enableOnlineTraining;
    
    Config() {
        VLynConfig c = VLynDefaultConfigC();
        maxMeshes = c.maxMeshes;
        gpuDevice = c.gpuDevice;
        tileSize = c.tileSize;
        numStreams = c.numStreams;
        mlThreshold = c.mlThreshold;
        voronoiEpsilon = c.voronoiEpsilon;
        enableML = c.enableML;
        enableVoronoi = c.enableVoronoi;
        enableProfiling = c.enableProfiling;
        asyncMode = c.asyncMode;
        clusterK = c.clusterK;
        gjkMaxIter = c.gjkMaxIter;
        epaMaxIter = c.epaMaxIter;
        contactMergeEps = c.contactMergeEps;
        enableOnlineTraining = c.enableOnlineTraining;
    }
    
    // Convert to C API
    operator VLynConfig() const {
        VLynConfig c;
        c.maxMeshes = maxMeshes;
        c.gpuDevice = gpuDevice;
        c.tileSize = tileSize;
        c.numStreams = numStreams;
        c.mlThreshold = mlThreshold;
        c.voronoiEpsilon = voronoiEpsilon;
        c.enableML = enableML;
        c.enableVoronoi = enableVoronoi;
        c.enableProfiling = enableProfiling;
        c.asyncMode = asyncMode;
        c.clusterK = clusterK;
        c.gjkMaxIter = gjkMaxIter;
        c.epaMaxIter = epaMaxIter;
        c.contactMergeEps = contactMergeEps;
        c.enableOnlineTraining = enableOnlineTraining;
        return c;
    }
};

// =============================================================================
// Stats Wrapper
// =============================================================================
struct Stats {
    double   meshScanMs;
    double   bvhBuildMs;
    double   mlInferenceMs;
    double   voronoiMs;
    double   totalMs;
    uint64_t candidatePairs;
    uint64_t mlRejected;
    uint64_t narrowPhasePairs;
    uint64_t contactsFound;
    float    mlAcceptRate;
    float    throughputMTriPerSec;
    
    // Convert from C API
    Stats(const VLynStats& s)
        : meshScanMs(s.meshScanMs)
        , bvhBuildMs(s.bvhBuildMs)
        , mlInferenceMs(s.mlInferenceMs)
        , voronoiMs(s.voronoiMs)
        , totalMs(s.totalMs)
        , candidatePairs(s.candidatePairs)
        , mlRejected(s.mlRejected)
        , narrowPhasePairs(s.narrowPhasePairs)
        , contactsFound(s.contactsFound)
        , mlAcceptRate(s.mlAcceptRate)
        , throughputMTriPerSec(s.throughputMTriPerSec)
    {}
};

// =============================================================================
// Context Class - Main VLyn Engine Wrapper
// =============================================================================
class VLYN_API Context {
public:
    // Constructor using default config
    Context() : handle_(CVSCrt(nullptr)), valid_(false) {
        valid_ = (handle_ != nullptr);
    }
    
    // Constructor using custom config
    explicit Context(const Config& config) : handle_(nullptr), valid_(false) {
        VLynConfig c = config;
        handle_ = CVSCrt(&c);
        valid_ = (handle_ != nullptr);
    }
    
    // Destructor
    ~Context() {
        if (handle_) {
            CVSDestroy(handle_);
            handle_ = nullptr;
            valid_ = false;
        }
    }
    
    // Delete copy constructor and assignment
    Context(const Context&) = delete;
    Context& operator=(const Context&) = delete;
    
    // Move constructor and assignment
    Context(Context&& other) noexcept : handle_(other.handle_), valid_(other.valid_) {
        other.handle_ = nullptr;
        other.valid_ = false;
    }
    
    Context& operator=(Context&& other) noexcept {
        if (this != &other) {
            if (handle_) {
                CVSDestroy(handle_);
            }
            handle_ = other.handle_;
            valid_ = other.valid_;
            other.handle_ = nullptr;
            other.valid_ = false;
        }
        return *this;
    }
    
    // Check if context is valid
    bool isValid() const { return valid_; }
    
    // Explicit bool conversion
    explicit operator bool() const { return valid_; }
    
    // Add mesh to the context
    int AddMesh(const std::vector<Vec3>& vertices, 
                const std::vector<uint32_t>& indices) {
        if (!valid_) return VLYN_ERR_NOT_INITIALIZED;
        
        return CVSAddMesh(handle_, 
                         reinterpret_cast<const VLynVec3*>(vertices.data()),
                         indices.data(),
                         static_cast<uint32_t>(indices.size() / 3));
    }
    
    // Add mesh using raw pointers
    int AddMesh(const Vec3* vertices, const uint32_t* indices, uint32_t triCount) {
        if (!valid_) return VLYN_ERR_NOT_INITIALIZED;
        
        return CVSAddMesh(handle_,
                         reinterpret_cast<const VLynVec3*>(vertices),
                         indices,
                         triCount);
    }
    
    // Remove mesh from context
    VLynError RemoveMesh(int meshId) {
        if (!valid_) return VLYN_ERR_NOT_INITIALIZED;
        return CVSRemoveMesh(handle_, meshId);
    }
    
    // Set transform for a mesh
    VLynError SetTransform(int meshId, const Transform& t) {
        if (!valid_) return VLYN_ERR_NOT_INITIALIZED;
        
        VLynTransform ct = t;
        return CVSSetTransform(handle_, meshId, &ct);
    }
    
    // Query collision between two meshes
    std::vector<CollisionResult> Query(int meshIdA, int meshIdB) {
        std::vector<CollisionResult> results;
        
        if (!valid_) return results;
        
        std::vector<VLynCollisionResult> buffer(64);
        uint32_t resultCount = 0;
        
        VLynError err = CVSQuery(handle_, meshIdA, meshIdB,
                                buffer.data(), &resultCount, 
                                static_cast<uint32_t>(buffer.size()));
        
        if (err == VLYN_OK) {
            results.reserve(resultCount);
            for (uint32_t i = 0; i < resultCount; ++i) {
                results.emplace_back(buffer[i]);
            }
        }
        
        return results;
    }
    
    // Query all pairs
    std::vector<CollisionResult> QueryAll() {
        std::vector<CollisionResult> results;
        
        if (!valid_) return results;
        
        std::vector<VLynCollisionResult> buffer(256);
        uint32_t resultCount = 0;
        
        VLynError err = CVSQueryAll(handle_,
                                  buffer.data(), &resultCount,
                                  static_cast<uint32_t>(buffer.size()));
        
        if (err == VLYN_OK) {
            results.reserve(resultCount);
            for (uint32_t i = 0; i < resultCount; ++i) {
                results.emplace_back(buffer[i]);
            }
        }
        
        return results;
    }
    
    // Get statistics
    Stats GetStats() {
        Stats s;
        if (valid_) {
            VLynStats cs;
            if (CVSGetStats(handle_, &cs) == VLYN_OK) {
                s = Stats(cs);
            }
        }
        return s;
    }
    
    // Reset statistics
    VLynError ResetStats() {
        if (!valid_) return VLYN_ERR_NOT_INITIALIZED;
        return CVSResetStats(handle_);
    }
    
    // Get version string
    static std::string GetVersion() {
        const char* version = CVSVersion();
        return version ? version : "unknown";
    }
    
private:
    CVSHandle handle_;
    bool valid_;
};

} // namespace VLyn

#endif // __cplusplus

#endif // VLYN_DLL_WRAPPER_HPP