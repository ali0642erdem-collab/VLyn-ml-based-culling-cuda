// =============================================================================
// VLyn_core.cu  —  Core Context, Public API & Pipeline Orchestration
// VLyn High-Performance Geometric Collision Detection Library
//
// Implements the CVSContext opaque handle and the full public API:
//   CVSCrt()          — create context
//   CVSDestroy()      — destroy context + free all GPU resources
//   CVSAddMesh()      — register a triangle mesh
//   CVSRemoveMesh()   — unregister a mesh
//   CVSSetTransform() — update a mesh's rigid-body transform
//   CVSQuery()        — run collision detection between two meshes
//   CVSQueryAll()     — run all-pairs collision detection
//   CVSGetStats()     — retrieve profiling statistics
//
// Pipeline order per query:
//   1. meshScan        (VLyn_mesh.cu)   — validate, cluster, compute bounds
//   2. bvhBuild        (VLyn_bvh.cu)   — LBVH construction
//   3. bvhQueryPairs   (VLyn_bvh.cu)   — broad-phase AABB pair list
//   4. mlInferAndFilter(VLyn_ml.cu)    — ML broad-phase culling
//   5. voronoiNarrowPhase(VLyn_voronoi.cu) — GJK+EPA narrow phase
//   6. mlInferNarrowPhase(VLyn_ml_narrow.cu) - ML narrow-phase culling
// =============================================================================
#define  BUILDING_VLYN_DLL
#include "VLyn_types.cuh"
#include "VLyn_dll_export.h"

// =============================================================================
// Compile-time ABI sanity checks
// These catch struct layout mismatches between internal types and the public
// VLyn.h API *before* they become runtime corruption bugs.
//
// Real sizes (Vec3 has alignas(16) → ContactPoint alignment = 16):
//   ContactPoint raw = 72, padded to next multiple of 16 = 80 bytes
//   CollisionResult = 16 header + 4×80 contacts + 4 + 16 + 8 = 364...
//   (with double at offset 368, align 8 → size = 376 → align to 16 = 384)
//   Verified empirically: sizeof(ContactPoint)=80, sizeof(CollisionResult)=384
//
// VLyn.h's VLynVec3 now also has alignas(16), so VLynContactPoint=80 and
// VLynCollisionResult=384 — both sides match.
// =============================================================================
static_assert(sizeof(ContactPoint)    ==  80u,
    "ContactPoint size mismatch with VLynContactPoint — check alignas attributes in VLyn_types.cuh");
static_assert(sizeof(CollisionResult) == 384u,
    "CollisionResult size mismatch with VLynCollisionResult — check alignas attributes in VLyn_types.cuh");
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cassert>

// =============================================================================
// Forward declarations of internal APIs (defined in companion .cu files)
// =============================================================================

// --- VLyn_mesh.cu ---
struct TileProcessor;
struct MeshStats;
struct CVSConfig;
VLynError meshScan(
    MeshDesc*        mesh,
    Triangle*        h_tris,
    uint32_t         triCount,
    uint32_t         meshId,
    const CVSConfig& cfg,
    MeshStats*       stats,
    cudaStream_t     stream
);
void      meshFree(MeshDesc* mesh);

// --- VLyn_bvh.cu ---
struct BVHStats;
VLynError bvhBuild(MeshDesc* mesh, cudaStream_t stream);
VLynError bvhQueryPairs(const MeshDesc* meshA, const MeshDesc* meshB,
                        uint64_t* d_pairs, uint32_t* d_pairCount,
                        uint32_t maxPairs, cudaStream_t stream);
VLynError bvhRebuild(MeshDesc* mesh, cudaStream_t stream);

// --- VLyn_ml.cu ---
#include "VLyn_ml_internal.cuh"
VLynError mlAllocContext(MLContext* ctx, float threshold);
VLynError mlInitWeights(MLContext* ctx);
VLynError mlInferAndFilter(
    MLContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const Cluster* d_clustersA,
    const Cluster* d_clustersB,
    const uint64_t* d_trianglePairs,
    int nPairs,
    uint64_t* d_filteredPairs,
    uint32_t* d_filteredCount,
    uint32_t maxFiltered,
    cudaStream_t stream
);
// Number of BVH candidate triangle-pairs that must be processed in pure-Voronoi
// warm-up mode before the ML networks are trusted for inference.
// 1024 pairs ≈ 7-8 queries with a 12-triangle cube (144 pairs/query), which
// is enough for the Adam optimizer to move the weights away from random init
// while still being fast enough that users see ML behaviour within seconds.
#define VLYN_WARMUP_PAIR_THRESHOLD  65536u  // increased from 1024: network needs
                                              // substantially more ground-truth pairs
                                              // before inference can be trusted.
                                              // 1024 pairs on large scenes produced
                                              // a near-random classifier that rejected
                                              // everything → contactsFound always 0.

VLynError mlFreeContext(MLContext* ctx);
VLynError mlTrainStep(
    MLContext* ctx,
    const float* d_features,
    const float* d_labels,
    int batch,
    cudaStream_t stream);
VLynError mlTrainOnFallbackBroad(
    MLContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const Cluster* d_clustersA,
    const Cluster* d_clustersB,
    const uint64_t* d_bvhPairs,
    int nPairs,
    int gjkIter, int epaIter,
    cudaStream_t stream);

// --- VLyn_voronoi.cu ---
VLynError voronoiNarrowPhase(const uint64_t* d_pairs, uint32_t nPairs,
                              const Triangle* d_trisA, const Triangle* d_trisB,
                              CollisionResult* d_results, uint32_t* d_resultCount,
                              uint32_t maxResults,
                              int gjkIter, int epaIter,
                              cudaStream_t stream);
// --- VLyn_ml_narrow.cu ---
VLynError mlnAllocContext(MLNarrowContext* ctx, float confLow, float confHigh);
VLynError mlnInitWeights(MLNarrowContext* ctx);
VLynError mlnPredictNarrowPhase(
    MLNarrowContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const uint64_t* d_pairs,
    int nPairs,
    CollisionResult* d_results,
    uint32_t* d_resultCount,
    uint32_t maxResults,
    uint64_t* d_fallbackPairs,
    uint32_t* d_fallbackCount,
    uint32_t maxFallback,
    cudaStream_t stream
);
VLynError mlnFreeContext(MLNarrowContext* ctx);
VLynError mlnTrainOnFallback(
    MLNarrowContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const uint64_t* d_pairs,
    int nPairs,
    int gjkIter, int epaIter,
    cudaStream_t stream
);
// =============================================================================
// Concrete CVSContext definition (opaque to callers via CVSHandle)
// =============================================================================

#define CVS_MAX_STREAMS      8
#define CVS_MAX_PAIRS        (1u << 22)   // ~4M AABB pairs per query
#define CVS_MAX_RESULTS      (1u << 16)   // ~64K contact results

struct CVSContext {
    // Configuration (immutable after init)
    CVSConfig     cfg;

    // Registered meshes
    MeshDesc      meshes[VLYN_MAX_MESHES];
    int           meshCount;

    // CUDA streams for async pipeline
    cudaStream_t  streams[CVS_MAX_STREAMS];
    int           numStreams;

    // ML broad-phase context
    MLContext*     ml;
    bool           mlReady;
    MLNarrowContext* mlNarrow;
    bool            mlNarrowReady;
    // Device scratch buffers (reused across queries)
    uint64_t*     d_bvhPairs;        // AABB-overlap pairs from BVH traversal
    uint32_t*     d_bvhPairCount;
    uint64_t*     d_mlPairs;         // pairs surviving ML filter (same uint64_t triangle-pair format as d_bvhPairs)
    uint32_t*     d_mlPairCount;
    CollisionResult* d_results;      // final contact results
    uint32_t*     d_resultCount;
    uint64_t*        d_fallbackPairs; 
    uint32_t*        d_fallbackCount;
    // Profiling accumulators
    VLynStats     stats;
    cudaEvent_t   evStart, evStop;

    bool          initialized;

    // -----------------------------------------------------------------------
    // Warm-up state: before the ML nets have seen enough ground truth to
    // make useful predictions, CVSQuery runs in pure-Voronoi mode and trains
    // both networks from the exact GJK/EPA results. Once enough pairs have
    // been processed, warmupComplete flips to true and the normal ML
    // broad-phase + ML narrow-phase pipeline takes over.
    //
    // Threshold: VLYN_WARMUP_PAIR_THRESHOLD total BVH pairs processed.
    // This is deliberately conservative — a network that has never seen real
    // geometry data should not be trusted to filter or classify anything.
    // -----------------------------------------------------------------------
    uint64_t      warmupPairsProcessed;  // cumulative BVH pairs seen so far
    bool          warmupComplete;         // true once threshold crossed
};

// =============================================================================
// Internal helpers
// =============================================================================

static VLynError cvsAllocScratch(CVSContext* ctx) {
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_bvhPairs,
                               CVS_MAX_PAIRS * sizeof(uint64_t)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_bvhPairCount, sizeof(uint32_t)));

    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_mlPairs,
                               CVS_MAX_PAIRS * sizeof(uint64_t)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_mlPairCount, sizeof(uint32_t)));

    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_results,
                               CVS_MAX_RESULTS * sizeof(CollisionResult)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_resultCount, sizeof(uint32_t)));
    
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_fallbackPairs, CVS_MAX_PAIRS * 
                                                    sizeof(uint64_t)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_fallbackCount, sizeof(uint32_t)));

    return VLYN_OK;
}

static void cvsFreeScratch(CVSContext* ctx) {
    if (ctx->d_bvhPairs)    { cudaFree(ctx->d_bvhPairs);    ctx->d_bvhPairs    = nullptr; }
    if (ctx->d_bvhPairCount){ cudaFree(ctx->d_bvhPairCount); ctx->d_bvhPairCount= nullptr; }
    if (ctx->d_mlPairs)     { cudaFree(ctx->d_mlPairs);      ctx->d_mlPairs     = nullptr; }
    if (ctx->d_mlPairCount) { cudaFree(ctx->d_mlPairCount);  ctx->d_mlPairCount = nullptr; }
    if (ctx->d_results)     { cudaFree(ctx->d_results);      ctx->d_results     = nullptr; }
    if (ctx->d_resultCount) { cudaFree(ctx->d_resultCount);  ctx->d_resultCount = nullptr; }
    if (ctx->d_fallbackPairs) { cudaFree(ctx->d_fallbackPairs); ctx->d_fallbackPairs = nullptr; }
    if (ctx->d_fallbackCount) { cudaFree(ctx->d_fallbackCount); ctx->d_fallbackCount = nullptr; }
}

// =============================================================================
// CVSCrt — create and initialise a CVS context
// =============================================================================
extern "C" VLYN_API CVSHandle CVSCrt(const CVSConfig* cfg) {
    if (!cfg) return nullptr;

    // Select GPU device
    int devId = cfg->gpuDevice;
    if (devId < 0) {
        // Auto-select: pick device with most memory
        int devCount = 0;
        if (cudaGetDeviceCount(&devCount) != cudaSuccess || devCount == 0) {
            fprintf(stderr, "[VLyn] No CUDA-capable GPU found.\n");
            return nullptr;
        }
        size_t bestMem = 0;
        devId = 0;
        for (int d = 0; d < devCount; ++d) {
            cudaDeviceProp prop;
            cudaGetDeviceProperties(&prop, d);
            if (prop.totalGlobalMem > bestMem) {
                bestMem = prop.totalGlobalMem;
                devId   = d;
            }
        }
    }

    if (cudaSetDevice(devId) != cudaSuccess) {
        fprintf(stderr, "[VLyn] Failed to set CUDA device %d.\n", devId);
        return nullptr;
    }

    // Allocate context on heap
    CVSContext* ctx = (CVSContext*)calloc(1, sizeof(CVSContext));
    if (!ctx) return nullptr;

    ctx->cfg       = *cfg;
    ctx->meshCount = 0;
    ctx->mlReady   = false;

    // Create CUDA streams
    ctx->numStreams = (cfg->numStreams > CVS_MAX_STREAMS)
                   ? CVS_MAX_STREAMS : cfg->numStreams;
    for (int s = 0; s < ctx->numStreams; ++s) {
        if (cudaStreamCreateWithFlags(&ctx->streams[s],
                cudaStreamNonBlocking) != cudaSuccess) {
            fprintf(stderr, "[VLyn] Failed to create CUDA stream %d.\n", s);
            free(ctx);
            return nullptr;
        }
    }

    // Allocate device scratch buffers
    if (cvsAllocScratch(ctx) != VLYN_OK) {
        fprintf(stderr, "[VLyn] Failed to allocate GPU scratch buffers.\n");
        free(ctx);
        return nullptr;
    }

    // Profiling events
    if (cfg->enableProfiling) {
        cudaEventCreate(&ctx->evStart);
        cudaEventCreate(&ctx->evStop);
    }

    // ML context
    if (cfg->enableML) {
        ctx->ml = (MLContext*)calloc(1, sizeof(MLContext));
        // --- Broad-Phase ML Init ---
        if (ctx->ml) {
            if (mlAllocContext(ctx->ml, cfg->mlThreshold) == VLYN_OK &&
                mlInitWeights(ctx->ml)                    == VLYN_OK) {
                ctx->mlReady = true;
            } else {
                fprintf(stderr, "[VLyn] ML init failed — running without ML culling.\n");
            }
        }
        // --- Narrow-Phase ML Init ---
        // DÜZELTME: mlnAllocContext(MLNarrowContext*, ...) bir MLNarrowContext'e
        // yazar, bir MLNarrowContext*'e değil — dolayısıyla önce gerçek bellek
        // ayırmamız (calloc) ve context'i ctx->mlNarrow alanına atamamız gerekir.
        // Eski kod bir null işaretçiyi (tmpNarrow) doğrudan fonksiyona geçiriyordu,
        // bu da mlnAllocContext içindeki ilk `ctx->confLow = confLow;` satırında
        // null-pointer dereference'a yol açardı (ya da en iyi ihtimalle UB).
        ctx->mlNarrow = (MLNarrowContext*)calloc(1, sizeof(MLNarrowContext));
        if (ctx->mlNarrow &&
            mlnAllocContext(ctx->mlNarrow, 0.15f, 0.85f) == VLYN_OK &&
            mlnInitWeights(ctx->mlNarrow) == VLYN_OK)
        {
            ctx->mlNarrowReady = true;
        } else {
            fprintf(stderr, "[VLyn] ML Narrow init failed — falling back to pure Voronoi.\n");
            if (ctx->mlNarrow) {
                // Best-effort partial cleanup; individual cudaFree(nullptr) calls
                // inside mlnFreeContext are safe no-ops for buffers that never
                // got allocated before the failure.
                mlnFreeContext(ctx->mlNarrow);
                free(ctx->mlNarrow);
                ctx->mlNarrow = nullptr;
            }
            ctx->mlNarrowReady = false;
        }
    }
    
    memset(&ctx->stats, 0, sizeof(VLynStats));
    ctx->warmupPairsProcessed = 0;
    ctx->warmupComplete       = false;
    ctx->initialized = true;

    cudaDeviceProp prop;
    cudaGetDeviceProperties(&prop, devId);
    fprintf(stderr, "[VLyn v%d.%d.%d] Initialized on %s (%zu MB), "
            "%d streams, ML=%s, Voronoi=%s\n",
            VLYN_VERSION_MAJOR, VLYN_VERSION_MINOR, VLYN_VERSION_PATCH,
            prop.name,
            prop.totalGlobalMem >> 20,
            ctx->numStreams,
            ctx->mlReady ? "ON" : "OFF",
            cfg->enableVoronoi ? "ON" : "OFF");

    return (CVSHandle)ctx;
}

// =============================================================================
// CVSDestroy — release all resources
// =============================================================================
extern "C" VLYN_API void CVSDestroy(CVSHandle handle) {
    if (!handle) return;
    CVSContext* ctx = (CVSContext*)handle;

    // Free meshes
    for (int i = 0; i < ctx->meshCount; ++i)
        meshFree(&ctx->meshes[i]);

    // Free ML
    if (ctx->ml) {
        mlFreeContext(ctx->ml);
        free(ctx->ml);
        ctx->ml = nullptr;
    }
    if (ctx->mlNarrow) {
        mlnFreeContext(ctx->mlNarrow);
        free(ctx->mlNarrow);
        ctx->mlNarrow = nullptr;
    }
    // Free scratch
    cvsFreeScratch(ctx);

    // Destroy streams
    for (int s = 0; s < ctx->numStreams; ++s)
        cudaStreamDestroy(ctx->streams[s]);

    // Profiling events
    if (ctx->cfg.enableProfiling) {
        cudaEventDestroy(ctx->evStart);
        cudaEventDestroy(ctx->evStop);
    }

    free(ctx);
}

// =============================================================================
// CVSAddMesh — register a triangle mesh (host-side vertices + indices)
//   h_verts    : flat array of VLynVec3 vertices (host) — 16 bytes each (x,y,z,_pad)
//   h_indices  : flat array of uint32 triangle indices (3 per tri) (host)
//   triCount   : number of triangles
//   Returns    : meshId (≥0) on success, or negative VLynError
//
// IMPORTANT: The public API takes const VLynVec3* (16-byte stride, with _pad).
// Internally Vec3 is also 16 bytes (alignas(16) + float _pad), so the memory
// layout is identical — we read via const float* with stride 4 floats to be
// explicit and safe across TU boundaries.
// =============================================================================
extern "C" VLYN_API int CVSAddMesh(CVSHandle handle,
               const float*    h_verts_raw,   // actually const VLynVec3*; each element = 4 floats
               const uint32_t* h_indices,
               uint32_t        triCount)
{
    if (!handle || !h_verts_raw || !h_indices || triCount == 0)
        return VLYN_ERR_NULL_PTR;
    CVSContext* ctx = (CVSContext*)handle;
    if (!ctx->initialized)            return VLYN_ERR_NOT_INITIALIZED;
    if (ctx->meshCount >= VLYN_MAX_MESHES) return VLYN_ERR_MAX_MESHES;

    int meshId = ctx->meshCount;
    MeshDesc* mesh = &ctx->meshes[meshId];
    memset(mesh, 0, sizeof(MeshDesc));
    mesh->meshId = (uint32_t)meshId;
    mesh->isDirty = false;

    cudaStream_t stream = ctx->streams[meshId % ctx->numStreams];

    // 1. Allocate GPU triangle buffer and upload
    VLYN_CUDA_CHECK(cudaMalloc(&mesh->d_triangles, triCount * sizeof(Triangle)));
    mesh->triCount = triCount;

    // Build Triangle array on host then upload
    // VLynVec3 = { float x, y, z, _pad } → stride = 4 floats = 16 bytes
    // Internal Vec3 = alignas(16) { float x, y, z, _pad } → same layout
    Triangle* h_tris = (Triangle*)malloc(triCount * sizeof(Triangle));
    if (!h_tris) return VLYN_ERR_OOM;

    for (uint32_t i = 0; i < triCount; ++i) {
        uint32_t ia = h_indices[i*3 + 0];
        uint32_t ib = h_indices[i*3 + 1];
        uint32_t ic = h_indices[i*3 + 2];
        // Read each vertex with explicit 4-float (16-byte) stride
        const float* va = h_verts_raw + ia * 4;
        const float* vb = h_verts_raw + ib * 4;
        const float* vc = h_verts_raw + ic * 4;
        h_tris[i].v0 = Vec3(va[0], va[1], va[2]);
        h_tris[i].v1 = Vec3(vb[0], vb[1], vb[2]);
        h_tris[i].v2 = Vec3(vc[0], vc[1], vc[2]);
        h_tris[i].meshId    = (uint32_t)meshId;
        h_tris[i].triId     = i;
        h_tris[i].clusterId = 0;
        h_tris[i]._pad      = 0;
        h_tris[i].computeDerived();
    }

    VLYN_CUDA_CHECK(cudaMemcpyAsync(mesh->d_triangles, h_tris,
                                    triCount * sizeof(Triangle),
                                    cudaMemcpyHostToDevice, stream));
    free(h_tris);

    VLynError e = meshScan(mesh, nullptr, triCount, (uint32_t)meshId, ctx->cfg, nullptr, stream);
    if (e != VLYN_OK) { meshFree(mesh); return e; }

    // 3. BVH build
    e = bvhBuild(mesh, stream);
    if (e != VLYN_OK) { meshFree(mesh); return e; }

    cudaStreamSynchronize(stream);

    ctx->meshCount++;
    return meshId;
}

// =============================================================================
// CVSRemoveMesh — unregister a mesh (free GPU resources)
// =============================================================================
extern "C" VLYN_API VLynError CVSRemoveMesh(CVSHandle handle, int meshId) {
    if (!handle) return VLYN_ERR_NULL_PTR;
    CVSContext* ctx = (CVSContext*)handle;
    if (meshId < 0 || meshId >= ctx->meshCount) return VLYN_ERR_INVALID_MESH;

    meshFree(&ctx->meshes[meshId]);

    // Compact the mesh array
    for (int i = meshId; i < ctx->meshCount - 1; ++i) {
        ctx->meshes[i] = ctx->meshes[i+1];
        ctx->meshes[i].meshId = (uint32_t)i;
    }
    ctx->meshCount--;
    return VLYN_OK;
}

// =============================================================================
// CVSSetTransform — update the rigid-body transform of a registered mesh
//   After calling this, the BVH will be rebuilt lazily on the next query.
//
// The public VLynTransform layout (VLyn.h):
//   VLynVec3 pos   → 16 bytes (x,y,z,_pad)
//   VLynQuat rot   → 16 bytes (w,x,y,z)
//   float    scale →  4 bytes
//   total          → 36 bytes
//
// Internal Transform layout (VLyn_types.cuh, alignas(16)):
//   Vec3 pos  → 16 bytes (alignas(16), x,y,z,_pad)
//   Quat rot  → 16 bytes (alignas(16), w,x,y,z)
//   float scale → 4 bytes
//   total       → 36 bytes (same, since alignas(16) on the struct
//                  doesn't change size when fields already fill to 36)
//
// Both are 36 bytes with identical field order — a direct cast is safe.
// We still copy field-by-field for clarity and robustness against future
// alignment changes.
// =============================================================================
extern "C" VLYN_API VLynError CVSSetTransform(CVSHandle handle, int meshId,
                                               const float* t_raw)  // actually const VLynTransform*
{
    if (!handle || !t_raw) return VLYN_ERR_NULL_PTR;
    CVSContext* ctx = (CVSContext*)handle;
    if (meshId < 0 || meshId >= ctx->meshCount) return VLYN_ERR_INVALID_MESH;

    // VLynTransform memory layout (floats):
    //   [0..2] pos.x,y,z   [3] pos._pad
    //   [4]    rot.w        [5..7] rot.x,y,z
    //   [8]    scale
    Transform& dst = ctx->meshes[meshId].transform;
    dst.pos   = Vec3(t_raw[0], t_raw[1], t_raw[2]);
    dst.rot   = Quat(t_raw[4], t_raw[5], t_raw[6], t_raw[7]);  // w,x,y,z
    dst.scale = t_raw[8];

    ctx->meshes[meshId].isDirty = true;
    return VLYN_OK;
}


//==============================================================================
//bug: ⚠️ Critical Architectural Note (Very Important)
//For the hybrid system to function flawlessly, `atomicAdd` must be used when writing results to the `d_resultCount` value within the //kernels (in the CUDA file) of the `voronoiNarrowPhase` function.
//This is because `mlnPredictNarrowPhase` writes its confirmed findings to the list and sets the counter (e.g., 1500). Subsequently, 
//`voronoiNarrowPhase` must append its own findings (fallback solutions) to the list, starting from index 1500. The reset operation //(`memset`) was intentionally performed externally (within `CVSQuery`).
// =============================================================================
//   CVSQuery — run full collision detection pipeline between meshA and meshB
//   Results written into caller-supplied buffer h_results[maxResults].
//   *resultCount is set to the number of contacts found.
// =============================================================================
// NOTE: h_results is declared CollisionResult* internally but the public API
// signature is VLynCollisionResult*. After removing alignas(64) from both
// ContactPoint and CollisionResult, sizeof(CollisionResult)==384 ==
// sizeof(VLynCollisionResult). The extern "C" boundary erases the type, so
// the pointer cast is safe at the ABI level.
extern "C" VLYN_API VLynError CVSQuery(CVSHandle       handle,
                                       int               meshIdA,
                                       int               meshIdB,
                                       CollisionResult*  h_results,   // == VLynCollisionResult* by size
                                       uint32_t*         resultCount,
                                       uint32_t          maxResults)
{
    if (!handle || !h_results || !resultCount) return VLYN_ERR_NULL_PTR;
    CVSContext* ctx = (CVSContext*)handle;
    if (!ctx->initialized)                     return VLYN_ERR_NOT_INITIALIZED;
    if (meshIdA < 0 || meshIdA >= ctx->meshCount) return VLYN_ERR_INVALID_MESH;
    if (meshIdB < 0 || meshIdB >= ctx->meshCount) return VLYN_ERR_INVALID_MESH;

    *resultCount = 0;

    MeshDesc* mA = &ctx->meshes[meshIdA];
    MeshDesc* mB = &ctx->meshes[meshIdB];
    cudaStream_t stream = ctx->streams[0];

    // --- Lazy BVH rebuild if transform changed ---
    if (mA->isDirty) {
        VLynError e = bvhRebuild(mA, stream);
        if (e != VLYN_OK) return e;
        mA->isDirty = false;
    }
    if (mB->isDirty) {
        VLynError e = bvhRebuild(mB, stream);
        if (e != VLYN_OK) return e;
        mB->isDirty = false;
    }

    // Quick AABB pre-reject
    if (!mA->worldBounds.overlaps(mB->worldBounds)) {
        *resultCount = 0;
        return VLYN_OK;
    }

    float t0ms = 0.f;
    if (ctx->cfg.enableProfiling)
        cudaEventRecord(ctx->evStart, stream);

    // -----------------------------------------------------------------------
    // Stage 1: BVH broad phase — collect AABB-overlapping triangle pairs
    // -----------------------------------------------------------------------
    VLYN_CUDA_CHECK(cudaMemsetAsync(ctx->d_bvhPairCount, 0, sizeof(uint32_t), stream));

    VLynError e = bvhQueryPairs(mA, mB,
                                ctx->d_bvhPairs, ctx->d_bvhPairCount,
                                CVS_MAX_PAIRS, stream);
    if (e != VLYN_OK) return e;

    uint32_t h_bvhCount = 0;
    VLYN_CUDA_CHECK(cudaMemcpyAsync(&h_bvhCount, ctx->d_bvhPairCount,
                                    sizeof(uint32_t),
                                    cudaMemcpyDeviceToHost, stream));
    cudaStreamSynchronize(stream);

    if (h_bvhCount == 0) {
        *resultCount = 0;
        return VLYN_OK;
    }

    // -----------------------------------------------------------------------
    // PHASE A: Warm-up — ML networks not yet trusted for inference.
    //
    // Run ALL BVH pairs through pure Voronoi/GJK-EPA narrow phase (no ML
    // filtering, no ML narrow-phase prediction). Use the exact results to
    // train BOTH the broad-phase net (mlTrainOnFallbackBroad) and the
    // narrow-phase net (mlnTrainOnFallback), so both networks see real
    // ground-truth geometry before they ever make a live inference decision.
    //
    // Once warmupPairsProcessed >= VLYN_WARMUP_PAIR_THRESHOLD, flip
    // warmupComplete = true and switch to the ML pipeline for all future
    // queries.
    // -----------------------------------------------------------------------
    if (!ctx->warmupComplete)
    {
        uint32_t clampedResults = (maxResults < CVS_MAX_RESULTS)
                                ? maxResults : CVS_MAX_RESULTS;

        VLYN_CUDA_CHECK(cudaMemsetAsync(ctx->d_resultCount, 0, sizeof(uint32_t), stream));
        VLYN_CUDA_CHECK(cudaMemsetAsync(ctx->d_results, 0,
                                        clampedResults * sizeof(CollisionResult),
                                        stream));

        // Voronoi narrow phase on ALL BVH pairs (no ML filtering yet)
        e = voronoiNarrowPhase(
            ctx->d_bvhPairs, h_bvhCount,
            mA->d_triangles, mB->d_triangles,
            ctx->d_results, ctx->d_resultCount,
            clampedResults,
            ctx->cfg.gjkMaxIter, ctx->cfg.epaMaxIter,
            stream);
        if (e != VLYN_OK) return e;

        // Train broad-phase net from these ground-truth pairs
        if (ctx->cfg.enableML && ctx->mlReady &&
            mA->d_clusters && mB->d_clusters)
        {
            VLynError te = mlTrainOnFallbackBroad(
                ctx->ml,
                mA->d_triangles, mB->d_triangles,
                mA->d_clusters,  mB->d_clusters,
                ctx->d_bvhPairs, (int)h_bvhCount,
                ctx->cfg.gjkMaxIter, ctx->cfg.epaMaxIter,
                stream);
            if (te != VLYN_OK)
                fprintf(stderr, "[VLyn] warm-up broad train failed (err=%d)\n", (int)te);
        }

        // Train narrow-phase net from these ground-truth pairs
        if (ctx->cfg.enableML && ctx->mlNarrowReady) {
            VLynError te = mlnTrainOnFallback(
                ctx->mlNarrow,
                mA->d_triangles, mB->d_triangles,
                ctx->d_bvhPairs, (int)h_bvhCount,
                ctx->cfg.gjkMaxIter, ctx->cfg.epaMaxIter,
                stream);
            if (te != VLYN_OK)
                fprintf(stderr, "[VLyn] warm-up narrow train failed (err=%d)\n", (int)te);
        }

        ctx->warmupPairsProcessed += h_bvhCount;
        if (ctx->warmupPairsProcessed >= VLYN_WARMUP_PAIR_THRESHOLD) {
            ctx->warmupComplete = true;
            fprintf(stderr, "[VLyn] Warm-up complete (%llu pairs). "
                            "Switching to ML pipeline.\n",
                    (unsigned long long)ctx->warmupPairsProcessed);
        }

        // Copy warm-up results to host and return
        uint32_t h_cnt = 0;
        VLYN_CUDA_CHECK(cudaMemcpyAsync(&h_cnt, ctx->d_resultCount,
                                        sizeof(uint32_t),
                                        cudaMemcpyDeviceToHost, stream));
        cudaStreamSynchronize(stream);
        h_cnt = (h_cnt < clampedResults) ? h_cnt : clampedResults;
        if (h_cnt > 0) {
            VLYN_CUDA_CHECK(cudaMemcpyAsync(h_results, ctx->d_results,
                                            h_cnt * sizeof(CollisionResult),
                                            cudaMemcpyDeviceToHost, stream));
            cudaStreamSynchronize(stream);
        }
        *resultCount = h_cnt;
        ctx->stats.candidatePairs    += h_bvhCount;
        ctx->stats.narrowPhasePairs  += h_bvhCount;
        ctx->stats.contactsFound     += h_cnt;
        if (ctx->cfg.enableProfiling) {
            cudaEventRecord(ctx->evStop, stream);
            cudaEventSynchronize(ctx->evStop);
            cudaEventElapsedTime(&t0ms, ctx->evStart, ctx->evStop);
            ctx->stats.totalMs += t0ms;
        }
        return VLYN_OK;
    }

    // -----------------------------------------------------------------------
    // PHASE B: Full ML pipeline (warmup complete).
    //
    // Stage 2: ML broad-phase culling — filters BVH pairs using the now-
    //   trained broad-phase net. Only pairs with score >= threshold survive.
    // Stage 3: ML narrow-phase prediction — classifies surviving pairs;
    //   confident hits written directly to d_results, uncertain pairs go
    //   to the fallback buffer.
    // Stage 4: Voronoi/GJK-EPA fallback — resolves uncertain pairs exactly.
    // Stage 5: Online training (opt-in) — trains narrow-phase net from the
    //   exact fallback results so it keeps improving during normal use.
    // -----------------------------------------------------------------------
    uint64_t narrowPairs = h_bvhCount;

    // Stage 2: ML broad-phase culling
    if (ctx->cfg.enableML && ctx->mlReady &&
        mA->d_clusters && mB->d_clusters)
    {
        VLYN_CUDA_CHECK(cudaMemsetAsync(ctx->d_mlPairCount, 0, sizeof(uint32_t), stream));

        e = mlInferAndFilter(
            ctx->ml,
            mA->d_triangles, mB->d_triangles,
            mA->d_clusters,  mB->d_clusters,
            ctx->d_bvhPairs,
            (int)h_bvhCount,
            ctx->d_mlPairs,
            ctx->d_mlPairCount,
            CVS_MAX_PAIRS,
            stream);
        if (e == VLYN_OK) {
            uint32_t h_mlCount = 0;
            VLYN_CUDA_CHECK(cudaMemcpyAsync(&h_mlCount, ctx->d_mlPairCount,
                                            sizeof(uint32_t),
                                            cudaMemcpyDeviceToHost, stream));
            cudaStreamSynchronize(stream);
            ctx->stats.mlRejected += (h_bvhCount - h_mlCount);
            narrowPairs            = h_mlCount;
        }
        // on ML error: fall through with all BVH pairs
    }

    ctx->stats.narrowPhasePairs += narrowPairs;

    uint32_t clampedResults = (maxResults < CVS_MAX_RESULTS)
                            ? maxResults : CVS_MAX_RESULTS;

    VLYN_CUDA_CHECK(cudaMemsetAsync(ctx->d_resultCount, 0, sizeof(uint32_t), stream));
    // Zero the result buffer too — not just the count. Without this, stale
    // CollisionResult data from a previous CVSQuery call (which may have found
    // more results than this call) remains in d_results. If the kernel only
    // writes N slots this query but the host reads M > N (due to a race or
    // reuse), it sees old contactCount / float garbage (BOZUK RESULT).
    VLYN_CUDA_CHECK(cudaMemsetAsync(ctx->d_results, 0,
                                    clampedResults * sizeof(CollisionResult),
                                    stream));

    // Narrow-phase input: filtered pairs (or all BVH pairs if ML broad-phase
    // was off/failed). Both buffers are uint64_t triangle-pair format.
    uint64_t* narrowInputPairs = (ctx->cfg.enableML && ctx->mlReady &&
                                  mA->d_clusters && mB->d_clusters)
                               ? ctx->d_mlPairs
                               : ctx->d_bvhPairs;

    uint32_t fallbackPairsCount  = (uint32_t)narrowPairs;
    uint64_t* fallbackPairsBuffer = narrowInputPairs;

    // Safety fallback: if ML rejected ALL pairs (network undertrained or
    // threshold too aggressive), fall back to all BVH pairs rather than
    // returning zero contacts. This prevents a silent miss of real collisions
    // on the first post-warmup frames while the network is still learning.
    if (narrowPairs == 0 && h_bvhCount > 0) {
        fprintf(stderr, "[VLyn] ML rejected all %u BVH pairs — falling back to full Voronoi.\n",
                (uint32_t)h_bvhCount);
        narrowPairs         = h_bvhCount;
        narrowInputPairs    = ctx->d_bvhPairs;
        fallbackPairsCount  = (uint32_t)h_bvhCount;
        fallbackPairsBuffer = ctx->d_bvhPairs;
    }

    if (narrowPairs == 0) {
        *resultCount = 0;
        return VLYN_OK;
    }

    // Stage 3: ML narrow-phase prediction
    if (ctx->cfg.enableML && ctx->mlNarrowReady) {
        VLYN_CUDA_CHECK(cudaMemsetAsync(ctx->d_fallbackCount, 0, sizeof(uint32_t), stream));

        e = mlnPredictNarrowPhase(
            ctx->mlNarrow,
            mA->d_triangles, mB->d_triangles,
            narrowInputPairs, (int)narrowPairs,
            ctx->d_results, ctx->d_resultCount,
            clampedResults,
            ctx->d_fallbackPairs, ctx->d_fallbackCount,
            CVS_MAX_PAIRS,
            stream);

        if (e == VLYN_OK) {
            uint32_t h_fallbackCount = 0;
            VLYN_CUDA_CHECK(cudaMemcpyAsync(&h_fallbackCount, ctx->d_fallbackCount,
                                            sizeof(uint32_t),
                                            cudaMemcpyDeviceToHost, stream));
            cudaStreamSynchronize(stream);
            fallbackPairsCount  = h_fallbackCount;
            fallbackPairsBuffer = ctx->d_fallbackPairs;
        }
    }

    // Stage 4: Voronoi/GJK-EPA fallback for uncertain pairs
    if (ctx->cfg.enableVoronoi && fallbackPairsCount > 0) {
        e = voronoiNarrowPhase(
            fallbackPairsBuffer, fallbackPairsCount,
            mA->d_triangles, mB->d_triangles,
            ctx->d_results, ctx->d_resultCount,
            clampedResults,
            ctx->cfg.gjkMaxIter, ctx->cfg.epaMaxIter,
            stream);
        if (e != VLYN_OK) return e;

        // Stage 5: Online training from fallback ground truth (opt-in)
        if (ctx->cfg.enableOnlineTraining && ctx->cfg.enableML) {
            // Train narrow-phase net from pairs it was uncertain about
            if (ctx->mlNarrowReady) {
                VLynError te = mlnTrainOnFallback(
                    ctx->mlNarrow,
                    mA->d_triangles, mB->d_triangles,
                    fallbackPairsBuffer, (int)fallbackPairsCount,
                    ctx->cfg.gjkMaxIter, ctx->cfg.epaMaxIter,
                    stream);
                if (te != VLYN_OK)
                    fprintf(stderr, "[VLyn] mlnTrainOnFallback failed (err=%d)\n", (int)te);
            }

            // Train broad-phase net from the same fallback pairs — these are
            // the pairs that survived broad-phase filtering and went to exact
            // Voronoi, so they are confirmed collision/no-collision ground truth
            // that the broad-phase net can learn from too. Without this, the
            // broad-phase net freezes at warm-up weights and never improves.
            if (ctx->mlReady && mA->d_clusters && mB->d_clusters) {
                VLynError te = mlTrainOnFallbackBroad(
                    ctx->ml,
                    mA->d_triangles, mB->d_triangles,
                    mA->d_clusters,  mB->d_clusters,
                    fallbackPairsBuffer, (int)fallbackPairsCount,
                    ctx->cfg.gjkMaxIter, ctx->cfg.epaMaxIter,
                    stream);
                if (te != VLYN_OK)
                    fprintf(stderr, "[VLyn] mlTrainOnFallbackBroad failed (err=%d)\n", (int)te);
            }
        }
    }

    // Copy results to host
    uint32_t h_cnt = 0;
    VLYN_CUDA_CHECK(cudaMemcpyAsync(&h_cnt, ctx->d_resultCount,
                                    sizeof(uint32_t),
                                    cudaMemcpyDeviceToHost, stream));
    cudaStreamSynchronize(stream);

    h_cnt = (h_cnt < clampedResults) ? h_cnt : clampedResults;
    if (h_cnt > 0) {
        VLYN_CUDA_CHECK(cudaMemcpyAsync(h_results, ctx->d_results,
                                        h_cnt * sizeof(CollisionResult),
                                        cudaMemcpyDeviceToHost, stream));
        cudaStreamSynchronize(stream);
    }

    *resultCount = h_cnt;
    ctx->stats.contactsFound += h_cnt;

    // Always update mlAcceptRate — independent of profiling flag so the stat
    // is visible even when enableProfiling is false.
    if (h_bvhCount > 0)
        ctx->stats.mlAcceptRate = (float)narrowPairs / (float)h_bvhCount;

    if (ctx->cfg.enableProfiling) {
        cudaEventRecord(ctx->evStop, stream);
        cudaEventSynchronize(ctx->evStop);
        cudaEventElapsedTime(&t0ms, ctx->evStart, ctx->evStop);
        ctx->stats.totalMs += t0ms;
    }

    return VLYN_OK;
}
// =============================================================================
// CVSQueryAll — run CVSQuery for every distinct pair (i, j) with i < j
//   Returns total contacts written (sum across all pairs).
// =============================================================================
extern "C" VLYN_API VLynError CVSQueryAll(CVSHandle        handle,
                      CollisionResult* h_results,   // == VLynCollisionResult* by size (both 384 bytes)
                      uint32_t*        resultCount,
                      uint32_t         maxResults)
{
    if (!handle || !h_results || !resultCount) return VLYN_ERR_NULL_PTR;
    CVSContext* ctx = (CVSContext*)handle;

    *resultCount = 0;
    uint32_t remaining = maxResults;

    for (int i = 0; i < ctx->meshCount; ++i) {
        for (int j = i + 1; j < ctx->meshCount; ++j) {
            if (remaining == 0) break;

            uint32_t cnt = 0;
            VLynError e = CVSQuery(handle, i, j,
                                   h_results + *resultCount,
                                   &cnt, remaining);
            if (e != VLYN_OK) return e;
            *resultCount += cnt;
            remaining    -= cnt;
        }
    }
    return VLYN_OK;
}

// =============================================================================
// CVSGetStats — fill *stats with accumulated profiling data
// =============================================================================
extern "C" VLYN_API VLynError CVSGetStats(CVSHandle handle, VLynStats* stats) {
    if (!handle || !stats) return VLYN_ERR_NULL_PTR;
    CVSContext* ctx = (CVSContext*)handle;
    *stats = ctx->stats;
    return VLYN_OK;
}

// =============================================================================
// CVSResetStats — zero profiling counters
// =============================================================================
extern "C" VLYN_API VLynError CVSResetStats(CVSHandle handle) {
    if (!handle) return VLYN_ERR_NULL_PTR;
    CVSContext* ctx = (CVSContext*)handle;
    memset(&ctx->stats, 0, sizeof(VLynStats));
    return VLYN_OK;
}

// =============================================================================
// CVSVersion — return version string "MAJOR.MINOR.PATCH"
// =============================================================================
extern "C" VLYN_API const char* CVSVersion(void) {
    return "2.0.0";
}

// =============================================================================
// End of VLyn_core.cu
// =============================================================================
