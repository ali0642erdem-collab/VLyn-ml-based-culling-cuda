// =============================================================================
// VLyn_voronoi.cu  —  Voronoi-Enhanced Narrow Phase (GJK + EPA + Contact Gen)
//
// Implements:
//   1. GJK (Gilbert-Johnson-Keerthi) with Voronoi region feature tracking
//      for numerical stability (Van Den Bergen 1999 / Erin Catto 2010 style)
//   2. EPA (Expanding Polytope Algorithm) for penetration depth
//   3. Contact manifold generation (4-point reduced manifold)
//   4. CUDA parallelism: each warp processes one triangle pair
// =============================================================================
#include "VLyn_types.cuh"
#include <cuda_runtime.h>
#include <cooperative_groups.h>
#include <cstdio>

namespace cg = cooperative_groups;

// ABI guard — ContactPoint=80 bytes, CollisionResult=384 bytes (Vec3 is alignas(16))
static_assert(sizeof(ContactPoint)    ==  80u, "ContactPoint size mismatch");
static_assert(sizeof(CollisionResult) == 384u, "CollisionResult size mismatch");

// =============================================================================
// Constants
// =============================================================================
#define EPA_MAX_FACES       256
#define EPA_MAX_EDGES       512
#define GJK_TOLERANCE       1e-6f
#define CONTACT_MERGE_EPS   1e-4f
#define MAX_MANIFOLD_POINTS 4

// =============================================================================
// Support function for a convex shape (triangle hull)
// Returns the point in the shape furthest along direction d
// =============================================================================
VLYN_DEVICE Vec3 supportTriangle(
    const Vec3& v0, const Vec3& v1, const Vec3& v2,
    const Vec3& d)
{
    float d0 = d.dot(v0);
    float d1 = d.dot(v1);
    float d2 = d.dot(v2);
    if (d0 >= d1 && d0 >= d2) return v0;
    if (d1 >= d2)               return v1;
    return v2;
}

// Minkowski support for two convex shapes
VLYN_DEVICE Vec3 minkSupport(
    const Vec3& a0, const Vec3& a1, const Vec3& a2,
    const Vec3& b0, const Vec3& b1, const Vec3& b2,
    const Vec3& d,
    Vec3& wA, Vec3& wB)
{
    wA = supportTriangle(a0, a1, a2,  d);
    wB = supportTriangle(b0, b1, b2,  d * -1.f);
    return wA - wB;
}

// =============================================================================
// Voronoi simplex subroutine — Line (2-point simplex)
// Returns true if origin is in the Voronoi region of edge, false if vertex
// =============================================================================
VLYN_DEVICE bool doSimplexLine(Simplex& s, Vec3& d) {
    Vec3 ab = s.pts[1] - s.pts[0];
    Vec3 ao = Vec3(0,0,0) - s.pts[0];

    float t = ab.dot(ao);
    if (t > 0.f) {
        float len2 = ab.lengthSq();
        if (t < len2) {
            // Origin in Voronoi region of edge AB
            d = ao - ab * (t / len2);  // perpendicular from AB to origin
            return false;
        } else {
            // Origin past B — keep only B
            s.set(0, s.pts[1], s.wA[1], s.wB[1]);
            s.size = 1;
            d = Vec3(0,0,0) - s.pts[0];
            return false;
        }
    } else {
        // Origin past A — keep only A
        s.size = 1;
        d = ao;
        return false;
    }
}

// =============================================================================
// Voronoi simplex subroutine — Triangle (3-point simplex)
// =============================================================================
VLYN_DEVICE bool doSimplexTriangle(Simplex& s, Vec3& d) {
    Vec3 a = s.pts[0], b = s.pts[1], c = s.pts[2];
    Vec3 ab = b - a, ac = c - a, ao = Vec3(0,0,0) - a;
    Vec3 abc = ab.cross(ac);  // triangle normal

    // Check which side of AB triangle normal the origin is on
    Vec3 abPerp = ab.cross(abc);
    if (abPerp.dot(ao) > 0.f) {
        // Outside edge AB
        s.set(0, b, s.wA[1], s.wB[1]);
        s.set(1, a, s.wA[0], s.wB[0]);
        s.size = 2;
        d = ab.cross(ao).cross(ab);
        return false;
    }

    Vec3 acPerp = abc.cross(ac);
    if (acPerp.dot(ao) > 0.f) {
        // Outside edge AC
        s.set(1, c, s.wA[2], s.wB[2]);
        s.size = 2;
        d = ac.cross(ao).cross(ac);
        return false;
    }

    // Inside triangle — check which face
    if (abc.dot(ao) > 0.f) {
        d = abc;  // origin above triangle
    } else {
        // Swap B and C to flip normal
        Simplex tmp = s;
        s.set(1, tmp.pts[2], tmp.wA[2], tmp.wB[2]);
        s.set(2, tmp.pts[1], tmp.wA[1], tmp.wB[1]);
        d = abc * -1.f;
    }
    return false;
}

// =============================================================================
// Voronoi simplex subroutine — Tetrahedron (4-point simplex)
// Returns true if origin is inside the tetrahedron (intersection found)
// =============================================================================
VLYN_DEVICE bool doSimplexTetra(Simplex& s, Vec3& d) {
    Vec3 a = s.pts[0], b = s.pts[1], c = s.pts[2], e = s.pts[3];
    Vec3 ab = b-a, ac = c-a, ae = e-a, ao = Vec3(0,0,0)-a;

    Vec3 abc = ab.cross(ac);
    Vec3 abe = ab.cross(ae);
    Vec3 ace = ac.cross(ae);

    // Check each face
    if (abc.dot(ao) > 0.f) {
        s.set(0, s.pts[0], s.wA[0], s.wB[0]);
        s.set(1, s.pts[1], s.wA[1], s.wB[1]);
        s.set(2, s.pts[2], s.wA[2], s.wB[2]);
        s.size = 3;
        return doSimplexTriangle(s, d);
    }
    if (abe.dot(ao) > 0.f) {
        s.set(0, s.pts[0], s.wA[0], s.wB[0]);
        s.set(1, s.pts[3], s.wA[3], s.wB[3]);
        s.set(2, s.pts[1], s.wA[1], s.wB[1]);
        s.size = 3;
        return doSimplexTriangle(s, d);
    }
    if (ace.dot(ao) > 0.f) {
        s.set(0, s.pts[0], s.wA[0], s.wB[0]);
        s.set(1, s.pts[2], s.wA[2], s.wB[2]);
        s.set(2, s.pts[3], s.wA[3], s.wB[3]);
        s.size = 3;
        return doSimplexTriangle(s, d);
    }

    return true;  // Origin inside tetrahedron — intersection!
}

// =============================================================================
// GJK main loop — device function
// Returns: true = intersection, false = no intersection
// On separation: closestPtA, closestPtB set to closest points
// =============================================================================
VLYN_DEVICE bool gjkIntersect(
    const Vec3& a0, const Vec3& a1, const Vec3& a2,
    const Vec3& b0, const Vec3& b1, const Vec3& b2,
    Simplex& simplex,
    float& dist,
    int maxIter)
{
    // Initial direction: centroid of A minus centroid of B
    Vec3 cA = (a0 + a1 + a2) * (1.f/3.f);
    Vec3 cB = (b0 + b1 + b2) * (1.f/3.f);
    Vec3 d  = cA - cB;
    if (d.lengthSq() < 1e-10f) d = Vec3(1,0,0);

    simplex = Simplex();

    for (int iter = 0; iter < maxIter; ++iter) {
        Vec3 wA, wB;
        Vec3 p = minkSupport(a0,a1,a2, b0,b1,b2, d, wA, wB);

        // Check if we've found a separating plane
        if (d.dot(p) < 0.f) {
            dist = -d.dot(p) / d.length();
            return false;  // No intersection
        }

        simplex.push(p, wA, wB);

        // Run simplex subroutine based on size
        bool intersect = false;
        switch (simplex.size) {
            case 2: intersect = doSimplexLine(simplex, d);      break;
            case 3: intersect = doSimplexTriangle(simplex, d);  break;
            case 4: intersect = doSimplexTetra(simplex, d);     break;
        }

        if (intersect) {
            dist = 0.f;
            return true;
        }

        if (d.lengthSq() < GJK_TOLERANCE * GJK_TOLERANCE) {
            dist = 0.f;
            return true;  // Degenerate — assume intersecting
        }
    }
    dist = 0.f;
    return true;
}

// =============================================================================
// EPA — Expanding Polytope Algorithm
// Finds penetration depth and MTD (Minimum Translation Direction)
// from a GJK intersection simplex.
// =============================================================================

struct EPAPolytope {
    Vec3      verts[EPA_MAX_FACES * 3 + 16];  // vertices of polytope
    Vec3      wA[EPA_MAX_FACES * 3 + 16];     // witness on A
    Vec3      wB[EPA_MAX_FACES * 3 + 16];     // witness on B
    int       nVerts;

    PolytopeFace faces[EPA_MAX_FACES];
    int          nFaces;

    // Silhouette edges for expansion [a, b]
    int       edgeA[EPA_MAX_EDGES];
    int       edgeB[EPA_MAX_EDGES];
    int       nEdges;
};

VLYN_DEVICE void epaAddEdge(EPAPolytope& p, int a, int b) {
    // If reverse edge already exists, remove it (silhouette computation)
    for (int i = 0; i < p.nEdges; i++) {
        if (p.edgeA[i] == b && p.edgeB[i] == a) {
            p.edgeA[i] = p.edgeA[--p.nEdges];
            p.edgeB[i] = p.edgeB[p.nEdges];
            return;
        }
    }
    if (p.nEdges < EPA_MAX_EDGES) {
        p.edgeA[p.nEdges]   = a;
        p.edgeB[p.nEdges++] = b;
    }
}

VLYN_DEVICE int epaFindClosestFace(const EPAPolytope& p) {
    int minIdx = -1;
    float minDist = FLT_MAX;
    for (int i = 0; i < p.nFaces; i++) {
        if (p.faces[i].dist < minDist) {
            minDist = p.faces[i].dist;
            minIdx  = i;
        }
    }
    return minIdx;
}

VLYN_DEVICE PolytopeFace epaComputeFace(const EPAPolytope& p, int a, int b, int c) {
    Vec3 ab = p.verts[b] - p.verts[a];
    Vec3 ac = p.verts[c] - p.verts[a];
    Vec3 n  = ab.cross(ac).normalize();
    float d = n.dot(p.verts[a]);
    if (d < 0.f) { n = n * -1.f; d = -d; }
    return { n, d, (uint32_t)a, (uint32_t)b, (uint32_t)c };
}

VLYN_DEVICE bool epaExpand(
    EPAPolytope& p,
    const Vec3& a0, const Vec3& a1, const Vec3& a2,
    const Vec3& b0, const Vec3& b1, const Vec3& b2,
    int maxIter,
    Vec3& normal, float& depth,
    Vec3& contactA, Vec3& contactB)
{
    for (int iter = 0; iter < maxIter; iter++) {
        int fi = epaFindClosestFace(p);
        if (fi < 0) return false;

        const PolytopeFace& face = p.faces[fi];
        Vec3 wA, wB;
        Vec3 sup = minkSupport(a0,a1,a2, b0,b1,b2, face.normal, wA, wB);

        float d = face.normal.dot(sup);
        if (d - face.dist < VLYN_EPA_TOLERANCE) {
            // Converged
            normal = face.normal;
            depth  = face.dist;

            // Barycentric interpolation of witness points
            Vec3 A = p.verts[face.a], B = p.verts[face.b], C = p.verts[face.c];
            Vec3 proj = face.normal * face.dist;
            // Compute barycentric coordinates
            Vec3 v0 = B-A, v1 = C-A, v2 = proj-A;
            float d00 = v0.dot(v0), d01 = v0.dot(v1);
            float d11 = v1.dot(v1), d20 = v2.dot(v0), d21 = v2.dot(v1);
            float denom = d00*d11 - d01*d01;
            float bv = (fabsf(denom) > 1e-10f) ? (d11*d20 - d01*d21)/denom : 0.f;
            float bw = (fabsf(denom) > 1e-10f) ? (d00*d21 - d01*d20)/denom : 0.f;
            float bu = 1.f - bv - bw;

            contactA = p.wA[face.a]*bu + p.wA[face.b]*bv + p.wA[face.c]*bw;
            contactB = p.wB[face.a]*bu + p.wB[face.b]*bv + p.wB[face.c]*bw;
            return true;
        }

        // Expand polytope: find silhouette edges of visible faces
        p.nEdges = 0;
        int nFacesOld = p.nFaces;
        for (int f = 0; f < nFacesOld; f++) {
            if (p.faces[f].normal.dot(sup - p.verts[p.faces[f].a]) > 0.f) {
                // Face visible from new support point — remove it
                epaAddEdge(p, p.faces[f].a, p.faces[f].b);
                epaAddEdge(p, p.faces[f].b, p.faces[f].c);
                epaAddEdge(p, p.faces[f].c, p.faces[f].a);
                // Remove face
                p.faces[f] = p.faces[--p.nFaces];
                f--;
                nFacesOld = p.nFaces + 1;
            }
        }

        // Add new vertex
        int newV = p.nVerts;
        if (newV >= EPA_MAX_FACES * 3 + 14) return false;
        p.verts[newV] = sup;
        p.wA[newV]    = wA;
        p.wB[newV]    = wB;
        p.nVerts++;

        // Create new faces from silhouette edges
        for (int e = 0; e < p.nEdges; e++) {
            if (p.nFaces >= EPA_MAX_FACES) break;
            p.faces[p.nFaces++] = epaComputeFace(p, p.edgeA[e], p.edgeB[e], newV);
        }
    }
    return false;
}

// =============================================================================
// Initialize EPA polytope from GJK simplex (tetrahedron)
// =============================================================================
VLYN_DEVICE bool epaInitFromSimplex(EPAPolytope& p, const Simplex& s) {
    if (s.size < 4) return false;
    p.nVerts = 4;
    p.nFaces = 0;
    p.nEdges = 0;
    for (int i = 0; i < 4; i++) {
        p.verts[i] = s.pts[i];
        p.wA[i]    = s.wA[i];
        p.wB[i]    = s.wB[i];
    }
    // Build 4 faces of tetrahedron
    p.faces[p.nFaces++] = epaComputeFace(p, 0, 1, 2);
    p.faces[p.nFaces++] = epaComputeFace(p, 0, 1, 3);
    p.faces[p.nFaces++] = epaComputeFace(p, 0, 2, 3);
    p.faces[p.nFaces++] = epaComputeFace(p, 1, 2, 3);
    return true;
}

// =============================================================================
// Contact manifold reduction — keep 4 "best" contact points
// Maximizes area of contact polygon
// =============================================================================
VLYN_DEVICE int reduceManifold(
    ContactPoint* contacts, int nContacts,
    ContactPoint* out, int maxOut)
{
    if (nContacts == 0) return 0;
    if (nContacts <= maxOut) {
        for (int i = 0; i < nContacts; i++) out[i] = contacts[i];
        return nContacts;
    }

    // Keep point with deepest penetration
    int deepest = 0;
    for (int i = 1; i < nContacts; i++)
        if (contacts[i].penetrationDepth > contacts[deepest].penetrationDepth)
            deepest = i;
    out[0] = contacts[deepest];
    int n = 1;

    // Keep point furthest from first
    if (n < maxOut) {
        float maxDist = -1.f;
        int   idx = -1;
        for (int i = 0; i < nContacts; i++) {
            if (i == deepest) continue;
            float d = (contacts[i].position - out[0].position).lengthSq();
            if (d > maxDist) { maxDist = d; idx = i; }
        }
        if (idx >= 0) out[n++] = contacts[idx];
    }

    // Keep point with maximum area triangle
    if (n < maxOut && nContacts > 2) {
        float maxArea = -1.f;
        int   idx = -1;
        Vec3 e = out[1].position - out[0].position;
        for (int i = 0; i < nContacts; i++) {
            if (contacts[i].position.lengthSq() < 1e-10f) continue;
            Vec3 f = contacts[i].position - out[0].position;
            float area = e.cross(f).lengthSq();
            if (area > maxArea) { maxArea = area; idx = i; }
        }
        if (idx >= 0) out[n++] = contacts[idx];
    }

    // Keep fourth point maximizing remaining area
    if (n < maxOut && nContacts > 3) {
        float maxArea = -1.f;
        int   idx = -1;
        for (int i = 0; i < nContacts; i++) {
            float area = 0.f;
            for (int j = 0; j < n; j++) {
                Vec3 d = contacts[i].position - out[j].position;
                area += d.lengthSq();
            }
            if (area > maxArea) { maxArea = area; idx = i; }
        }
        if (idx >= 0) out[n++] = contacts[idx];
    }

    return n;
}

// =============================================================================
// Voronoi feature region query — determines which Voronoi region a point
// belongs to relative to a triangle simplex.
// Used for numerically robust closest-point computation.
// =============================================================================
VLYN_DEVICE VoronoiRegion classifyVoronoi(
    const Vec3& p,
    const Vec3& a, const Vec3& b, const Vec3& c)
{
    Vec3 ab = b-a, ac = c-a, ap = p-a;
    float d1 = ab.dot(ap), d2 = ac.dot(ap);
    if (d1 <= 0 && d2 <= 0) return VoronoiRegion::VERTEX_A;

    Vec3 bp = p-b;
    float d3 = ab.dot(bp), d4 = ac.dot(bp);
    if (d3 >= 0 && d4 <= d3) return VoronoiRegion::VERTEX_B;

    Vec3 cp = p-c;
    float d5 = ab.dot(cp), d6 = ac.dot(cp);
    if (d6 >= 0 && d5 <= d6) return VoronoiRegion::VERTEX_C;

    float vc = d1*d4 - d3*d2;
    if (vc <= 0 && d1 >= 0 && d3 <= 0) return VoronoiRegion::EDGE_AB;

    float vb = d5*d2 - d1*d6;
    if (vb <= 0 && d2 >= 0 && d6 <= 0) return VoronoiRegion::EDGE_AC;

    float va = d3*d6 - d5*d4;
    if (va <= 0 && (d4-d3) >= 0 && (d5-d6) >= 0) return VoronoiRegion::EDGE_BC;

    return VoronoiRegion::FACE_ABC;
}

// =============================================================================
// Full narrow-phase query for a single triangle pair (device function)
// Returns true if collision detected, fills ContactPoint
// =============================================================================
VLYN_DEVICE bool narrowPhasePair(
    const Triangle& triA,
    const Triangle& triB,
    ContactPoint*   contacts,
    int&            nContacts,
    int             gjkIter,
    int             epaIter)
{
    nContacts = 0;

    // Fast reject: triangle-triangle SAT
    if (!triTriOverlapSAT(triA.v0, triA.v1, triA.v2,
                          triB.v0, triB.v1, triB.v2))
        return false;

    // GJK
    Simplex s;
    float dist;
    bool intersecting = gjkIntersect(
        triA.v0, triA.v1, triA.v2,
        triB.v0, triB.v1, triB.v2,
        s, dist, gjkIter);

    if (!intersecting) {
        // No collision — compute closest distance
        // (Closest point info is in simplex witness points)
        return false;
    }

    // EPA for penetration depth
    EPAPolytope poly;
    if (!epaInitFromSimplex(poly, s)) {
        // Simplex degenerate — use triangle normal as fallback
        ContactPoint cp;
        cp.normal           = triA.normal;
        cp.penetrationDepth = 0.f;
        cp.position         = (triA.centroid + triB.centroid) * 0.5f;
        cp.triIdA           = triA.triId;
        cp.triIdB           = triB.triId;
        cp.meshIdA          = triA.meshId;
        cp.meshIdB          = triB.meshId;
        cp.confidence       = 0.5f;
        cp.voronoiRegion    = (uint32_t)VoronoiRegion::FACE_ABC;
        cp.separation       = -0.001f;
        contacts[nContacts++] = cp;
        return true;
    }

    Vec3 normal, contactA, contactB;
    float depth;
    bool epaOk = epaExpand(poly,
        triA.v0, triA.v1, triA.v2,
        triB.v0, triB.v1, triB.v2,
        epaIter, normal, depth, contactA, contactB);

    if (!epaOk) {
        // EPA failed — use GJK simplex last point
        ContactPoint cp;
        cp.normal           = triA.normal;
        cp.penetrationDepth = 0.01f;
        cp.position         = triA.centroid;
        cp.triIdA           = triA.triId;
        cp.triIdB           = triB.triId;
        cp.meshIdA          = triA.meshId;
        cp.meshIdB          = triB.meshId;
        cp.confidence       = 0.3f;
        cp.voronoiRegion    = (uint32_t)VoronoiRegion::INTERIOR;
        cp.separation       = -depth;
        contacts[nContacts++] = cp;
        return true;
    }

    // Fill primary contact point
    ContactPoint cp;
    cp.normal           = normal;
    cp.penetrationDepth = depth;
    cp.position         = (contactA + contactB) * 0.5f;
    cp.triIdA           = triA.triId;
    cp.triIdB           = triB.triId;
    cp.meshIdA          = triA.meshId;
    cp.meshIdB          = triB.meshId;
    cp.confidence       = 1.f;
    cp.voronoiRegion    = (uint32_t)classifyVoronoi(
        cp.position, triA.v0, triA.v1, triA.v2);
    cp.separation       = -depth;
    contacts[nContacts++] = cp;

    // Attempt to build full contact manifold (vertex-face, edge-edge contacts)
    // Check 3 vertex-face contacts (vertices of A penetrating B)
    const Vec3* vA[3] = { &triA.v0, &triA.v1, &triA.v2 };
    for (int i = 0; i < 3 && nContacts < 4; i++) {
        Vec3 closest = triB.closestPoint(*vA[i]);
        Vec3 diff = *vA[i] - closest;
        if (diff.dot(normal) < 0.f) {
            ContactPoint cp2;
            cp2.position         = *vA[i];
            cp2.normal           = normal;
            cp2.penetrationDepth = -diff.dot(normal);
            cp2.separation       = diff.dot(normal);
            cp2.triIdA           = triA.triId;
            cp2.triIdB           = triB.triId;
            cp2.meshIdA          = triA.meshId;
            cp2.meshIdB          = triB.meshId;
            cp2.confidence       = 0.9f;
            cp2.voronoiRegion    = (uint32_t)VoronoiRegion::VERTEX_A;
            contacts[nContacts++] = cp2;
        }
    }

    return true;
}

// =============================================================================
// Main Voronoi narrow-phase kernel
// One warp = one triangle pair
// =============================================================================
VLYN_GLOBAL void kernelVoronoiNarrowPhase(
    const uint64_t* __restrict__  d_pairs,      // [nPairs] packed triA|triB indices
    uint32_t                      nPairs,
    const Triangle* __restrict__  d_trisA,
    const Triangle* __restrict__  d_trisB,
    CollisionResult* __restrict__ d_results,
    uint32_t* __restrict__        d_resultCount,
    uint32_t                      maxResults,
    int gjkIter, int epaIter)
{
    // One warp per pair
    int pairIdx = (blockIdx.x * blockDim.x + threadIdx.x) / VLYN_WARP_SIZE;
    int lane    = threadIdx.x % VLYN_WARP_SIZE;

    if (pairIdx >= (int)nPairs) return;
    if (lane != 0) return;  // Only lane 0 does work (single-threaded per pair)

    uint64_t packed = d_pairs[pairIdx];
    uint32_t idxA   = (uint32_t)(packed >> 32);
    uint32_t idxB   = (uint32_t)(packed & 0xffffffff);

    const Triangle& tA = d_trisA[idxA];
    const Triangle& tB = d_trisB[idxB];

    ContactPoint rawContacts[VLYN_MAX_CONTACTS_PER_PAIR * 2];
    int nRaw = 0;

    bool hit = narrowPhasePair(tA, tB, rawContacts, nRaw, gjkIter, epaIter);

    if (hit && nRaw > 0) {
        uint32_t slot = atomicAdd(d_resultCount, 1);
        if (slot >= maxResults) return;

        CollisionResult& res = d_results[slot];
        // Explicit field-by-field zero — memset() is a HOST function and
        // silently does nothing inside a __global__ kernel, leaving
        // cudaMalloc garbage in contacts[1..3] which the host reads as
        // invalid contactCount values (9, 11, etc.).
        res.meshIdA = 0; res.meshIdB = 0; res.contactCount = 0; res.flags = 0;
        for (int ci = 0; ci < VLYN_MAX_CONTACTS_PER_PAIR; ++ci) {
            ContactPoint& cp = res.contacts[ci];
            cp.position = Vec3(0,0,0); cp.normal = Vec3(0,0,0);
            cp.penetrationDepth = 0.f; cp.separation = 0.f;
            cp.triIdA = 0; cp.triIdB = 0; cp.meshIdA = 0; cp.meshIdB = 0;
            cp.confidence = 0.f; cp.voronoiRegion = 0;
            cp._pad[0] = 0; cp._pad[1] = 0;
        }
        res.closestDist = 0.f; res.separatingAxis = Vec3(0,0,0); res.timestamp = 0.0;

        res.meshIdA   = tA.meshId;
        res.meshIdB   = tB.meshId;
        res.timestamp = 0.0;  // filled by host
        res.flags     = 0x4;  // colliding

        // Reduce to best 4 contacts
        ContactPoint best[VLYN_MAX_CONTACTS_PER_PAIR];
        int nBest = reduceManifold(rawContacts, nRaw, best, VLYN_MAX_CONTACTS_PER_PAIR);
        res.contactCount = (uint32_t)nBest;
        for (int i = 0; i < nBest; i++) res.contacts[i] = best[i];

        // Compute closest distance
        res.closestDist    = -best[0].penetrationDepth;
        res.separatingAxis = best[0].normal;
    }
}

// =============================================================================
// Kernel: Voronoi cluster-level overlap check
// Before triangle-level, check if Voronoi cells of two clusters overlap.
// A Voronoi cell is approximated as the AABB expanded by avg normal offset.
// =============================================================================
VLYN_GLOBAL void kernelVoronoiClusterCheck(
    const Cluster* __restrict__ d_clustersA,
    const Cluster* __restrict__ d_clustersB,
    const uint32_t* __restrict__ d_clusterPairs,
    uint32_t nPairs,
    uint32_t* __restrict__ d_kept,
    uint32_t* __restrict__ d_keptCount,
    uint32_t maxKept,
    float eps)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= (int)nPairs) return;

    uint32_t enc  = d_clusterPairs[i];
    uint32_t idxA = enc >> 16;
    uint32_t idxB = enc & 0xffff;

    const Cluster& cA = d_clustersA[idxA];
    const Cluster& cB = d_clustersB[idxB];

    // Expand bounds by eps * avgArea
    float epsA = sqrtf(cA.avgArea) * eps;
    float epsB = sqrtf(cB.avgArea) * eps;

    AABB exA = cA.bounds.expanded(epsA);
    AABB exB = cB.bounds.expanded(epsB);

    if (exA.overlaps(exB)) {
        uint32_t slot = atomicAdd(d_keptCount, 1);
        if (slot < maxKept)
            d_kept[slot] = enc;
    }
}

// =============================================================================
// Kernel: Distance-based early exit
// If AABB squared distance > (sumRadius)^2, trivially not colliding
// =============================================================================
VLYN_GLOBAL void kernelDistanceCull(
    const uint64_t* __restrict__ d_pairs,
    uint32_t nPairs,
    const Triangle* __restrict__ d_trisA,
    const Triangle* __restrict__ d_trisB,
    float maxDist,
    uint64_t* __restrict__ d_out,
    uint32_t* __restrict__ d_outCount,
    uint32_t maxOut)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= (int)nPairs) return;

    uint64_t pair = d_pairs[i];
    uint32_t idxA = (uint32_t)(pair >> 32);
    uint32_t idxB = (uint32_t)(pair & 0xffffffff);

    float dx = d_trisA[idxA].centroid.x - d_trisB[idxB].centroid.x;
    float dy = d_trisA[idxA].centroid.y - d_trisB[idxB].centroid.y;
    float dz = d_trisA[idxA].centroid.z - d_trisB[idxB].centroid.z;
    float d2 = dx*dx + dy*dy + dz*dz;

    if (d2 <= maxDist * maxDist) {
        uint32_t slot = atomicAdd(d_outCount, 1);
        if (slot < maxOut)
            d_out[slot] = pair;
    }
}

// =============================================================================
// voronoiNarrowPhase — public entry point called by interface
// =============================================================================
VLynError voronoiNarrowPhase(
    const uint64_t* d_pairs,
    uint32_t nPairs,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    CollisionResult* d_results,
    uint32_t* d_resultCount,
    uint32_t maxResults,
    int gjkIter, int epaIter,
    cudaStream_t stream)
{
    if (nPairs == 0) return VLYN_OK;
    // NOTE: do NOT reset d_resultCount here. mlnPredictNarrowPhase may have
    // already written results and advanced d_resultCount. This function appends
    // via atomicAdd inside the kernel. Only CVSQuery zeros d_resultCount once.

    // One warp per pair
    int totalThreads = (int)nPairs * VLYN_WARP_SIZE;
    int blocks = (totalThreads + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;

    kernelVoronoiNarrowPhase<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_pairs, nPairs,
        d_trisA, d_trisB,
        d_results, d_resultCount, maxResults,
        gjkIter, epaIter);

    return VLYN_OK;
}

// =============================================================================
// Training-label extraction: run the EXACT GJK/EPA solver over a pair list
// and emit dense [nPairs x 5] labels = [didCollide, penetrationDepth, nx,ny,nz],
// one row per input pair in the SAME order as d_pairs.
// =============================================================================
VLYN_GLOBAL void kernelVoronoiTrainLabels(
    const uint64_t* __restrict__  d_pairs,
    uint32_t                        nPairs,
    const Triangle* __restrict__  d_trisA,
    const Triangle* __restrict__  d_trisB,
    float* __restrict__             d_labels,   // [nPairs x 5]
    int gjkIter, int epaIter)
{
    int p = blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= (int)nPairs) return;

    uint64_t packed = d_pairs[p];
    uint32_t idxA   = (uint32_t)(packed >> 32);
    uint32_t idxB   = (uint32_t)(packed & 0xffffffff);

    const Triangle& tA = d_trisA[idxA];
    const Triangle& tB = d_trisB[idxB];

    ContactPoint rawContacts[VLYN_MAX_CONTACTS_PER_PAIR * 2];
    int nRaw = 0;
    bool hit = narrowPhasePair(tA, tB, rawContacts, nRaw, gjkIter, epaIter);

    float* row = d_labels + p * 5;
    if (hit && nRaw > 0) {
        row[0] = 1.f;
        row[1] = rawContacts[0].penetrationDepth;
        row[2] = rawContacts[0].normal.x;
        row[3] = rawContacts[0].normal.y;
        row[4] = rawContacts[0].normal.z;
    } else {
        row[0] = 0.f;
        row[1] = 0.f;
        row[2] = 0.f;
        row[3] = 0.f;
        row[4] = 0.f;
    }
}

// =============================================================================
// Host wrapper for computing training labels via GJK/EPA fallback
// =============================================================================
VLynError voronoiComputeTrainLabels(
    const uint64_t* d_pairs,
    uint32_t nPairs,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    float* d_labels,
    int gjkIter,
    int epaIter,
    cudaStream_t stream)
{
    if (nPairs == 0) return VLYN_OK;

    int blocks = (nPairs + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;

    kernelVoronoiTrainLabels<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_pairs, nPairs, d_trisA, d_trisB, d_labels, gjkIter, epaIter);

    return VLYN_OK;
}

// =============================================================================
// End of VLyn_voronoi.cu
// =============================================================================
