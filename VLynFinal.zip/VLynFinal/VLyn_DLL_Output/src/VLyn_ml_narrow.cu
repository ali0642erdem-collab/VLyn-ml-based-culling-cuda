// =============================================================================
// VLyn_ml_narrow.cu  —  Neural Narrow-Phase Predictor (ML Narrow-Phase Bypass)
//
// This is NOT broad-phase pruning (see VLyn_ml.cu). It runs one stage later,
// on triangle pairs that already survived BVH + broad-phase ML culling, and
// tries to predict the actual GJK/EPA RESULT rather than a keep/reject flag:
//
//     [collisionProb, penetrationDepth, normal.x, normal.y, normal.z]
//
// Architecture:
//   Input  : 24-dim per-triangle-pair feature vector
//   Layer1 : FC(24 -> 96) + BatchNorm + LeakyReLU
//   Layer2 : FC(96 -> 48) + BatchNorm + LeakyReLU
//   Layer3 : FC(48 -> 5)  -> [Sigmoid(prob), depth, nx, ny, nz]  (linear heads
//            for the last 4 outputs, sigmoid only on the probability head)
//
// Gating: predictions with collisionProb outside [confLow, confHigh] are
// trusted directly (no GJK/EPA); predictions inside that band are ambiguous
// and routed to the exact narrowPhasePair() solver as a fallback. The exact
// solver's output is then used as an online training label, so the network
// keeps improving specifically on the cases it found hardest.
// =============================================================================
#include "VLyn_types.cuh"
#include "VLyn_ml_narrow_internal.cuh"
#include <cuda_runtime.h>
#include <cublas_v2.h>
#include <cstdio>
#include <cstring>
#include <cmath>

// ABI guard — ContactPoint=80 bytes, CollisionResult=384 bytes (Vec3 is alignas(16))
static_assert(sizeof(ContactPoint)    ==  80u, "ContactPoint size mismatch");
static_assert(sizeof(CollisionResult) == 384u, "CollisionResult size mismatch");

// Defined in VLyn_voronoi.cu: runs the exact GJK/EPA solver over a pair list
// and emits dense [nPairs x 5] training labels in the same order as d_pairs.
// Used below to build online-training ground truth for the narrow-phase net
// from whatever pairs it was uncertain about (the fallback set).
extern VLynError voronoiComputeTrainLabels(
    const uint64_t* d_pairs,
    uint32_t nPairs,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    float* d_labels,
    int gjkIter, int epaIter,
    cudaStream_t stream);

// Forward declaration: mlnTrainBatch is defined later in this file but is
// called by mlnTrainOnFallback above its definition.
VLynError mlnTrainBatch(
    MLNarrowContext* ctx,
    const float* d_inputs,
    const float* d_labels,
    int batch,
    cudaStream_t stream);

// =============================================================================
// GPU memory allocation
// =============================================================================
VLynError mlnAllocContext(MLNarrowContext* ctx, float confLow, float confHigh) {
    ctx->confLow  = confLow;
    ctx->confHigh = confHigh;
    ctx->maxBatch = MLN_BATCH_SIZE;
    ctx->trainingMode = false;
    ctx->totalPairs = 0;
    ctx->mlAcceptedPairs = 0;
    ctx->fallbackPairs = 0;

    MLNarrowWeights& w = ctx->weights;

    VLYN_CUDA_CHECK(cudaMalloc(&w.W1,  MLN_H1_DIM * MLN_IN_DIM  * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.b1,  MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.g1,  MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.be1, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.rm1, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.rv1, MLN_H1_DIM * sizeof(float)));

    VLYN_CUDA_CHECK(cudaMalloc(&w.W2,  MLN_H2_DIM * MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.b2,  MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.g2,  MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.be2, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.rm2, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.rv2, MLN_H2_DIM * sizeof(float)));

    VLYN_CUDA_CHECK(cudaMalloc(&w.W3,  MLN_OUT_DIM * MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.b3,  MLN_OUT_DIM * sizeof(float)));

    // Adam moments
    VLYN_CUDA_CHECK(cudaMalloc(&w.mW1, MLN_H1_DIM * MLN_IN_DIM  * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vW1, MLN_H1_DIM * MLN_IN_DIM  * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.mb1, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vb1, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.mW2, MLN_H2_DIM * MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vW2, MLN_H2_DIM * MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.mb2, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vb2, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.mW3, MLN_OUT_DIM * MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vW3, MLN_OUT_DIM * MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.mb3, MLN_OUT_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vb3, MLN_OUT_DIM * sizeof(float)));

    // Adam moments for BatchNorm gamma/beta
    VLYN_CUDA_CHECK(cudaMalloc(&w.mg1,  MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vg1,  MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.mbe1, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vbe1, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.mg2,  MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vg2,  MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.mbe2, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.vbe2, MLN_H2_DIM * sizeof(float)));

    // Gradient accumulators
    VLYN_CUDA_CHECK(cudaMalloc(&w.gW1,  MLN_H1_DIM * MLN_IN_DIM  * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.gb1,  MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.gg1,  MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.gbe1, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.gW2,  MLN_H2_DIM * MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.gb2,  MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.gg2,  MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.gbe2, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.gW3,  MLN_OUT_DIM * MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&w.gb3,  MLN_OUT_DIM * sizeof(float)));

    VLYN_CUDA_CHECK(cudaMemset(w.mW1, 0, MLN_H1_DIM * MLN_IN_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vW1, 0, MLN_H1_DIM * MLN_IN_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.mW2, 0, MLN_H2_DIM * MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vW2, 0, MLN_H2_DIM * MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.mW3, 0, MLN_OUT_DIM * MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vW3, 0, MLN_OUT_DIM * MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.mb1, 0, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vb1, 0, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.mb2, 0, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vb2, 0, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.mb3, 0, MLN_OUT_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vb3, 0, MLN_OUT_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.mg1,  0, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vg1,  0, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.mbe1, 0, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vbe1, 0, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.mg2,  0, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vg2,  0, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.mbe2, 0, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(w.vbe2, 0, MLN_H2_DIM * sizeof(float)));

    // Scratch activations
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_h0,  MLN_BATCH_SIZE * MLN_IN_DIM  * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_h1,  MLN_BATCH_SIZE * MLN_H1_DIM  * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_h2,  MLN_BATCH_SIZE * MLN_H2_DIM  * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_out, MLN_BATCH_SIZE * MLN_OUT_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_dh2, MLN_BATCH_SIZE * MLN_H2_DIM  * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_dh1, MLN_BATCH_SIZE * MLN_H1_DIM  * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_dh0, MLN_BATCH_SIZE * MLN_IN_DIM  * sizeof(float)));

    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_xhat1,   MLN_BATCH_SIZE * MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_invStd1, MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_preAct1, MLN_BATCH_SIZE * MLN_H1_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_xhat2,   MLN_BATCH_SIZE * MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_invStd2, MLN_H2_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_preAct2, MLN_BATCH_SIZE * MLN_H2_DIM * sizeof(float)));

    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_featMean, MLN_IN_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMalloc(&ctx->d_featStd,  MLN_IN_DIM * sizeof(float)));
    VLYN_CUDA_CHECK(cudaMemset(ctx->d_featMean, 0, MLN_IN_DIM * sizeof(float)));
    {
        float ones[MLN_IN_DIM];
        for (int i = 0; i < MLN_IN_DIM; i++) ones[i] = 1.f;
        VLYN_CUDA_CHECK(cudaMemcpy(ctx->d_featStd, ones, MLN_IN_DIM * sizeof(float),
                                   cudaMemcpyHostToDevice));
    }

    if (cublasCreate_v2(&ctx->cublas) != CUBLAS_STATUS_SUCCESS)
        return VLYN_ERR_CUDA;

    ctx->weights.stepCount = 0;
    return VLYN_OK;
}

// =============================================================================
// Weight init kernels (reused pattern from broad-phase net)
// =============================================================================
VLYN_GLOBAL void kernelMLNXavierInit(float* w, int fanIn, int fanOut, uint32_t seed) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int n = fanIn * fanOut;
    if (i >= n) return;
    uint32_t s = seed + (uint32_t)i * 2654435761u;
    float r = randFloat(s);
    float limit = sqrtf(6.f / (float)(fanIn + fanOut));
    w[i] = (r * 2.f - 1.f) * limit;
}

VLYN_GLOBAL void kernelMLNBiasInit(float* b, int n, float val) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    b[i] = val;
}

VLynError mlnInitWeights(MLNarrowContext* ctx) {
    auto launch = [](float* w, int fi, int fo, uint32_t seed) {
        int n = fi * fo;
        int blocks = (n + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
        kernelMLNXavierInit<<<blocks, VLYN_BLOCK_SIZE>>>(w, fi, fo, seed);
    };

    launch(ctx->weights.W1, MLN_IN_DIM, MLN_H1_DIM, 0x2f4d6b91);
    launch(ctx->weights.W2, MLN_H1_DIM, MLN_H2_DIM, 0x7a1c3e5f);
    launch(ctx->weights.W3, MLN_H2_DIM, MLN_OUT_DIM, 0xb08d2c47);

    cudaMemset(ctx->weights.b1, 0, MLN_H1_DIM  * sizeof(float));
    cudaMemset(ctx->weights.b2, 0, MLN_H2_DIM  * sizeof(float));
    // Bias init: prob head (row 0 of W3/b3) starts at 0 -> sigmoid=0.5
    // (maximally uncertain -> everything initially routes to GJK/EPA fallback,
    //  which is the safe default until the network has trained).
    cudaMemset(ctx->weights.b3, 0, MLN_OUT_DIM * sizeof(float));

    int b1 = (MLN_H1_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE;
    int b2 = (MLN_H2_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE;
    kernelMLNBiasInit<<<b1, VLYN_BLOCK_SIZE>>>(ctx->weights.g1,  MLN_H1_DIM, 1.f);
    kernelMLNBiasInit<<<b1, VLYN_BLOCK_SIZE>>>(ctx->weights.be1, MLN_H1_DIM, 0.f);
    kernelMLNBiasInit<<<b1, VLYN_BLOCK_SIZE>>>(ctx->weights.rm1, MLN_H1_DIM, 0.f);
    kernelMLNBiasInit<<<b1, VLYN_BLOCK_SIZE>>>(ctx->weights.rv1, MLN_H1_DIM, 1.f);
    kernelMLNBiasInit<<<b2, VLYN_BLOCK_SIZE>>>(ctx->weights.g2,  MLN_H2_DIM, 1.f);
    kernelMLNBiasInit<<<b2, VLYN_BLOCK_SIZE>>>(ctx->weights.be2, MLN_H2_DIM, 0.f);
    kernelMLNBiasInit<<<b2, VLYN_BLOCK_SIZE>>>(ctx->weights.rm2, MLN_H2_DIM, 0.f);
    kernelMLNBiasInit<<<b2, VLYN_BLOCK_SIZE>>>(ctx->weights.rv2, MLN_H2_DIM, 1.f);

    return VLYN_OK;
}

// =============================================================================
// Device-side feature extraction (shared by kernel + host reuse)
// =============================================================================
__device__ void mlnExtractPairFeature(const Triangle& tA, const Triangle& tB, float* f) {
    Vec3 nA = tA.normal, nB = tB.normal;
    Vec3 cA = tA.centroid, cB = tB.centroid;
    Vec3 dc = cB - cA;

    f[0] = nA.x; f[1] = nA.y; f[2] = nA.z;
    f[3] = nB.x; f[4] = nB.y; f[5] = nB.z;
    f[6] = nA.dot(nB);

    f[7] = dc.x; f[8] = dc.y; f[9] = dc.z;
    f[10] = dc.length();

    f[11] = tA.area;
    f[12] = tB.area;
    f[13] = logf(tA.area / fmaxf(tB.area, 1e-8f));

    // Edge lengths
    float eA0 = (tA.v1 - tA.v0).length();
    float eA1 = (tA.v2 - tA.v1).length();
    float eA2 = (tA.v0 - tA.v2).length();
    float eB0 = (tB.v1 - tB.v0).length();
    float eB1 = (tB.v2 - tB.v1).length();
    float eB2 = (tB.v0 - tB.v2).length();

    f[14] = fminf(eA0, fminf(eA1, eA2));
    f[15] = fminf(eB0, fminf(eB1, eB2));
    f[16] = fmaxf(eA0, fmaxf(eA1, eA2));
    f[17] = fmaxf(eB0, fmaxf(eB1, eB2));

    f[18] = dc.dot(nA);        // signed distance of B's centroid along A's normal
    f[19] = (cA - cB).dot(nB); // signed distance of A's centroid along B's normal

    AABB boxA = tA.aabb();
    AABB boxB = tB.aabb();
    f[20] = aabbSqDist(boxA, boxB);

    f[21] = 1.f - fabsf(f[6]);  // coplanarity indicator
    f[22] = 0.f;                // reserved
    f[23] = 0.f;                // reserved
}

VLYN_GLOBAL void kernelExtractNarrowPairFeatures(
    const Triangle* __restrict__ d_trisA,
    const Triangle* __restrict__ d_trisB,
    const uint64_t* __restrict__ d_pairs,
    int nPairs,
    float* __restrict__ d_features,
    const float* __restrict__ d_featMean,
    const float* __restrict__ d_featStd)
{
    int p = blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= nPairs) return;

    uint64_t packed = d_pairs[p];
    uint32_t idxA = (uint32_t)(packed >> 32);
    uint32_t idxB = (uint32_t)(packed & 0xffffffff);

    const Triangle& tA = d_trisA[idxA];
    const Triangle& tB = d_trisB[idxB];

    float* feat = d_features + p * MLN_IN_DIM;
    mlnExtractPairFeature(tA, tB, feat);

    for (int i = 0; i < MLN_IN_DIM; i++) {
        float std = d_featStd[i];
        feat[i] = (feat[i] - d_featMean[i]) / (std > 1e-8f ? std : 1.f);
    }
}

// =============================================================================
// Shared activation kernels (same math as broad-phase net, distinct symbols
// to avoid ODR clashes when both .cu files are linked into the same DLL)
// =============================================================================
VLYN_GLOBAL void kernelMLNBatchNormInfer(
    float* __restrict__ d_x,
    const float* __restrict__ d_gamma,
    const float* __restrict__ d_beta,
    const float* __restrict__ d_runMean,
    const float* __restrict__ d_runVar,
    int batch, int dim, float eps)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int b = blockIdx.y;
    if (i >= dim || b >= batch) return;
    float xn = (d_x[b*dim + i] - d_runMean[i]) / sqrtf(d_runVar[i] + eps);
    d_x[b*dim + i] = d_gamma[i] * xn + d_beta[i];
}

VLYN_GLOBAL void kernelMLNBatchNormTrain(
    float* __restrict__ d_x,
    float* __restrict__ d_gamma,
    float* __restrict__ d_beta,
    float* __restrict__ d_runMean,
    float* __restrict__ d_runVar,
    float* __restrict__ d_xhat,    // [batch x dim] cached normalized values, may be null
    float* __restrict__ d_invStd,  // [dim] cached 1/sqrt(var+eps), may be null
    int batch, int dim, float eps, float momentum)
{
    VLYN_SHARED float smMean[MLN_H1_DIM + 4];
    VLYN_SHARED float smVar[MLN_H1_DIM + 4];

    int feat = blockIdx.x;
    if (feat >= dim) return;

    float sum = 0.f;
    for (int b = threadIdx.x; b < batch; b += blockDim.x)
        sum += d_x[b*dim + feat];
    VLYN_WARP_REDUCE_SUM(sum);
    if (threadIdx.x % VLYN_WARP_SIZE == 0)
        smMean[threadIdx.x / VLYN_WARP_SIZE] = sum;
    __syncthreads();
    if (threadIdx.x == 0) {
        float total = 0.f;
        for (int w = 0; w < blockDim.x/VLYN_WARP_SIZE; w++) total += smMean[w];
        smMean[0] = total / (float)batch;
    }
    __syncthreads();
    float mean = smMean[0];

    float var = 0.f;
    for (int b = threadIdx.x; b < batch; b += blockDim.x) {
        float d = d_x[b*dim + feat] - mean;
        var += d*d;
    }
    VLYN_WARP_REDUCE_SUM(var);
    if (threadIdx.x % VLYN_WARP_SIZE == 0)
        smVar[threadIdx.x / VLYN_WARP_SIZE] = var;
    __syncthreads();
    if (threadIdx.x == 0) {
        float total = 0.f;
        for (int w = 0; w < blockDim.x/VLYN_WARP_SIZE; w++) total += smVar[w];
        smVar[0] = total / (float)batch;
        d_runMean[feat] = (1.f-momentum)*d_runMean[feat] + momentum*mean;
        d_runVar[feat]  = (1.f-momentum)*d_runVar[feat]  + momentum*smVar[0];
    }
    __syncthreads();
    float invStd = rsqrtf(smVar[0] + eps);
    if (threadIdx.x == 0 && d_invStd) d_invStd[feat] = invStd;

    for (int b = threadIdx.x; b < batch; b += blockDim.x) {
        float xhat = (d_x[b*dim + feat] - mean) * invStd;
        if (d_xhat) d_xhat[b*dim + feat] = xhat;
        d_x[b*dim + feat] = d_gamma[feat] * xhat + d_beta[feat];
    }
}

VLYN_GLOBAL void kernelMLNLeakyReLU(float* d_x, int n, float alpha) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    float v = d_x[i];
    d_x[i] = (v > 0.f) ? v : alpha * v;
}

// Applies sigmoid ONLY to output column 0 (collision probability);
// columns 1..4 (depth, nx, ny, nz) stay linear regression outputs.
VLYN_GLOBAL void kernelMLNOutputActivation(float* d_out, int batch) {
    int b = blockIdx.x * blockDim.x + threadIdx.x;
    if (b >= batch) return;
    float* row = d_out + b * MLN_OUT_DIM;
    row[0] = 1.f / (1.f + expf(-row[0]));
    // row[1..4] left as-is (linear)
}

VLYN_GLOBAL void kernelMLNAddBias(float* d_x, const float* d_bias, int batch, int dim) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int b = blockIdx.y;
    if (i >= dim || b >= batch) return;
    d_x[b*dim + i] += d_bias[i];
}

// =============================================================================
// Forward pass
// =============================================================================
VLynError mlnForward(
    MLNarrowContext* ctx,
    const float* d_input,
    float* d_output,
    int batch,
    cudaStream_t stream)
{
    if (batch <= 0 || batch > ctx->maxBatch) return VLYN_ERR_ML_INFERENCE;

    cublasSetStream(ctx->cublas, stream);
    const float alpha = 1.f, beta = 0.f;

    // Layer 1
    cublasSgemm_v2(ctx->cublas, CUBLAS_OP_T, CUBLAS_OP_N,
                MLN_H1_DIM, batch, MLN_IN_DIM,
                &alpha,
                ctx->weights.W1, MLN_IN_DIM,
                d_input,          MLN_IN_DIM,
                &beta,
                ctx->d_h1,        MLN_H1_DIM);

    dim3 bBlock(VLYN_BLOCK_SIZE), bGrid1((MLN_H1_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
    kernelMLNAddBias<<<bGrid1, bBlock, 0, stream>>>(ctx->d_h1, ctx->weights.b1, batch, MLN_H1_DIM);

    if (ctx->trainingMode) {
        dim3 bnGrid(MLN_H1_DIM), bnBlock(min(batch, VLYN_BLOCK_SIZE));
        kernelMLNBatchNormTrain<<<bnGrid, bnBlock, 0, stream>>>(
            ctx->d_h1, ctx->weights.g1, ctx->weights.be1,
            ctx->weights.rm1, ctx->weights.rv1,
            ctx->d_xhat1, ctx->d_invStd1,
            batch, MLN_H1_DIM, 1e-5f, 0.1f);
        cudaMemcpyAsync(ctx->d_preAct1, ctx->d_h1,
                         (size_t)batch * MLN_H1_DIM * sizeof(float),
                         cudaMemcpyDeviceToDevice, stream);
    } else {
        dim3 bnGrid1((MLN_H1_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
        kernelMLNBatchNormInfer<<<bnGrid1, VLYN_BLOCK_SIZE, 0, stream>>>(
            ctx->d_h1, ctx->weights.g1, ctx->weights.be1,
            ctx->weights.rm1, ctx->weights.rv1,
            batch, MLN_H1_DIM, 1e-5f);
    }
    int lrB1 = (batch * MLN_H1_DIM + VLYN_BLOCK_SIZE-1) / VLYN_BLOCK_SIZE;
    kernelMLNLeakyReLU<<<lrB1, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_h1, batch * MLN_H1_DIM, MLN_LEAKY_ALPHA);

    // Layer 2
    cublasSgemm_v2(ctx->cublas, CUBLAS_OP_T, CUBLAS_OP_N,
                MLN_H2_DIM, batch, MLN_H1_DIM,
                &alpha,
                ctx->weights.W2, MLN_H1_DIM,
                ctx->d_h1,       MLN_H1_DIM,
                &beta,
                ctx->d_h2,       MLN_H2_DIM);

    dim3 bGrid2((MLN_H2_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
    kernelMLNAddBias<<<bGrid2, bBlock, 0, stream>>>(ctx->d_h2, ctx->weights.b2, batch, MLN_H2_DIM);

    if (ctx->trainingMode) {
        dim3 bnGrid2(MLN_H2_DIM), bnBlock2(min(batch, VLYN_BLOCK_SIZE));
        kernelMLNBatchNormTrain<<<bnGrid2, bnBlock2, 0, stream>>>(
            ctx->d_h2, ctx->weights.g2, ctx->weights.be2,
            ctx->weights.rm2, ctx->weights.rv2,
            ctx->d_xhat2, ctx->d_invStd2,
            batch, MLN_H2_DIM, 1e-5f, 0.1f);
        cudaMemcpyAsync(ctx->d_preAct2, ctx->d_h2,
                         (size_t)batch * MLN_H2_DIM * sizeof(float),
                         cudaMemcpyDeviceToDevice, stream);
    } else {
        dim3 bnGrid2b((MLN_H2_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
        kernelMLNBatchNormInfer<<<bnGrid2b, VLYN_BLOCK_SIZE, 0, stream>>>(
            ctx->d_h2, ctx->weights.g2, ctx->weights.be2,
            ctx->weights.rm2, ctx->weights.rv2,
            batch, MLN_H2_DIM, 1e-5f);
    }
    int lrB2 = (batch * MLN_H2_DIM + VLYN_BLOCK_SIZE-1) / VLYN_BLOCK_SIZE;
    kernelMLNLeakyReLU<<<lrB2, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_h2, batch * MLN_H2_DIM, MLN_LEAKY_ALPHA);

    // Layer 3 (multi-head output: prob + depth + normal)
    cublasSgemm_v2(ctx->cublas, CUBLAS_OP_T, CUBLAS_OP_N,
                MLN_OUT_DIM, batch, MLN_H2_DIM,
                &alpha,
                ctx->weights.W3, MLN_H2_DIM,
                ctx->d_h2,       MLN_H2_DIM,
                &beta,
                d_output,        MLN_OUT_DIM);

    dim3 bGrid3((MLN_OUT_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
    kernelMLNAddBias<<<bGrid3, bBlock, 0, stream>>>(d_output, ctx->weights.b3, batch, MLN_OUT_DIM);

    int actBlocks = (batch + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelMLNOutputActivation<<<actBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(d_output, batch);

    return VLYN_OK;
}

// =============================================================================
// Gating kernel: split ML-predicted narrow-phase pairs into confident-direct
// vs must-fallback-to-GJK/EPA buckets.
// =============================================================================
VLYN_GLOBAL void kernelGateNarrowPredictions(
    const uint64_t* __restrict__ d_pairs,
    const float* __restrict__ d_mlOut,
    int nPairs,
    const Triangle* __restrict__ d_trisA,
    const Triangle* __restrict__ d_trisB,
    float confLow, float confHigh,
    CollisionResult* __restrict__ d_results,
    uint32_t* __restrict__ d_resultCount,
    uint32_t maxResults,
    uint64_t* __restrict__ d_fallbackPairs,
    uint32_t* __restrict__ d_fallbackCount,
    uint32_t maxFallback)
{
    int p = blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= nPairs) return;

    const float* out = d_mlOut + p * MLN_OUT_DIM;
    float prob  = out[0];
    float depth = out[1];
    Vec3  normal(out[2], out[3], out[4]);

    // Ambiguous zone -> defer to exact GJK/EPA solver.
    if (prob > confLow && prob < confHigh) {
        uint32_t slot = atomicAdd(d_fallbackCount, 1);
        if (slot < maxFallback)
            d_fallbackPairs[slot] = d_pairs[p];
        return;
    }

    // Confidently "no collision" -> drop silently, nothing to write.
    if (prob <= confLow) return;

    // Confidently "colliding" -> synthesize a CollisionResult directly from
    // the network's regression heads, skipping GJK/EPA entirely.
    uint64_t packed = d_pairs[p];
    uint32_t idxA = (uint32_t)(packed >> 32);
    uint32_t idxB = (uint32_t)(packed & 0xffffffff);
    const Triangle& tA = d_trisA[idxA];
    const Triangle& tB = d_trisB[idxB];

    float nLen = normal.length();
    Vec3 n = (nLen > 1e-6f) ? normal * (1.f / nLen) : tA.normal;
    float pen = fmaxf(0.f, depth);

    uint32_t slot = atomicAdd(d_resultCount, 1);
    if (slot >= maxResults) return;

    CollisionResult& res = d_results[slot];
    // Explicit zero — memset() is a HOST function, silent no-op in __global__.
    res.meshIdA = 0; res.meshIdB = 0; res.contactCount = 0; res.flags = 0;
    for (int ci = 0; ci < VLYN_MAX_CONTACTS_PER_PAIR; ++ci) {
        ContactPoint& cp = res.contacts[ci];
        cp.position = Vec3(0,0,0); cp.normal = Vec3(0,0,0);
        cp.penetrationDepth = 0.f; cp.separation = 0.f;
        cp.triIdA = 0; cp.triIdB = 0; cp.meshIdA = 0; cp.meshIdB = 0;
        cp.confidence = 0.f; cp.voronoiRegion = 0;
        cp._pad[0] = 0; cp._pad[1] = 0;
    }
    res.closestDist = 0.f; res.separatingAxis = Vec3(0,0,0); res.timestamp = 0.0;
    res.meshIdA = tA.meshId;
    res.meshIdB = tB.meshId;
    res.flags   = 0x4;            // colliding
    res.timestamp = 0.0;          // filled by host
    res.contactCount = 1;

    ContactPoint& cp = res.contacts[0];
    cp.position = (tA.centroid + tB.centroid) * 0.5f;
    cp.normal = n;
    cp.penetrationDepth = pen;
    cp.separation = -pen;
    cp.triIdA = tA.triId; cp.triIdB = tB.triId;
    cp.meshIdA = tA.meshId; cp.meshIdB = tB.meshId;
    cp.confidence = prob;          // ML confidence, distinct from geometric certainty
    cp.voronoiRegion = 0;

    res.closestDist = -pen;
    res.separatingAxis = n;
}
// =============================================================================
// Full predict pipeline
// =============================================================================
VLynError mlnPredictNarrowPhase(
    MLNarrowContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const uint64_t* d_pairs,
    int nPairs,
    CollisionResult* d_results,
    uint32_t* d_resultCount,
    uint32_t maxResults,
    uint64_t* d_fallbackPairs,
    uint32_t* d_fallbackCount,
    uint32_t maxFallback,
    cudaStream_t stream)
{
    if (nPairs == 0) return VLYN_OK;

    cudaMemsetAsync(d_fallbackCount, 0, sizeof(uint32_t), stream);
    // NOTE: caller is expected to have already zeroed d_resultCount if this is
    // the start of a fresh query (mirrors voronoiNarrowPhase's contract).

    int processed = 0;
    while (processed < nPairs) {
        int batch = min((int)MLN_BATCH_SIZE, nPairs - processed);
        int blocks = (batch + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;

        kernelExtractNarrowPairFeatures<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_trisA, d_trisB,
            d_pairs + processed,
            batch,
            ctx->d_h0,
            ctx->d_featMean,
            ctx->d_featStd);

        VLynError fe = mlnForward(ctx, ctx->d_h0, ctx->d_out, batch, stream);
        if (fe != VLYN_OK) return fe;

        kernelGateNarrowPredictions<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_pairs + processed,
            ctx->d_out,
            batch,
            d_trisA, d_trisB,
            ctx->confLow, ctx->confHigh,
            d_results, d_resultCount, maxResults,
            d_fallbackPairs, d_fallbackCount, maxFallback);

        processed += batch;
    }

    ctx->totalPairs += (uint64_t)nPairs;
    return VLYN_OK;
}

// =============================================================================
// Online training entry point: given the SAME pair list that was just run
// through the exact GJK/EPA fallback solver (voronoiNarrowPhase), recompute
// ground-truth labels for those pairs and take one training step so the
// narrow-phase net learns specifically from the cases it was uncertain about.
//
// This is the piece that fulfils the "online training" contract documented
// in VLyn_ml_narrow_internal.cuh: mlnTrainBatch() existing in isolation does
// nothing for the pipeline unless something calls it with real ground truth;
// this function is that caller. It is intentionally decoupled from
// mlnPredictNarrowPhase() (whose scratch buffers get overwritten mid-loop
// for large batches) and instead redoes feature extraction + label
// computation in its own batched loop.
// =============================================================================
VLynError mlnTrainOnFallback(
    MLNarrowContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const uint64_t* d_pairs,
    int nPairs,
    int gjkIter, int epaIter,
    cudaStream_t stream)
{
    if (nPairs == 0) return VLYN_OK;

    float* d_trainLabels = nullptr;
    cudaMallocAsync(&d_trainLabels, (size_t)min(nPairs, (int)MLN_BATCH_SIZE) * MLN_OUT_DIM * sizeof(float), stream);
    if (!d_trainLabels) return VLYN_ERR_OOM;

    int processed = 0;
    VLynError result = VLYN_OK;
    while (processed < nPairs) {
        int batch = min((int)MLN_BATCH_SIZE, nPairs - processed);
        int blocks = (batch + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;

        // Re-extract features for this chunk (same kernel used for inference)
        kernelExtractNarrowPairFeatures<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_trisA, d_trisB,
            d_pairs + processed,
            batch,
            ctx->d_h0,
            ctx->d_featMean,
            ctx->d_featStd);

        // Ground truth: run the exact solver on this same chunk of pairs
        VLynError le = voronoiComputeTrainLabels(
            d_pairs + processed, (uint32_t)batch,
            d_trisA, d_trisB,
            d_trainLabels,
            gjkIter, epaIter,
            stream);
        if (le != VLYN_OK) { result = le; break; }

        // One Adam step against this batch of ground truth
        VLynError te = mlnTrainBatch(ctx, ctx->d_h0, d_trainLabels, batch, stream);
        if (te != VLYN_OK) { result = te; break; }

        processed += batch;
    }

    cudaFreeAsync(d_trainLabels, stream);
    return result;
}

// =============================================================================
// Backward pass building blocks (distinct symbols from broad-phase net to
// avoid ODR clashes when both .cu files are linked into the same DLL)
// =============================================================================
VLYN_GLOBAL void kernelMLNLeakyReLUBackward(
    const float* __restrict__ d_dOut,
    const float* __restrict__ d_preAct,
    float* __restrict__       d_dIn,
    int n, float alpha)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    float g = d_dOut[i];
    d_dIn[i] = (d_preAct[i] > 0.f) ? g : alpha * g;
}

VLYN_GLOBAL void kernelMLNBiasGradReduce(
    const float* __restrict__ d_dOut,
    float* __restrict__       d_dBias,
    int batch, int dim)
{
    int feat = blockIdx.x * blockDim.x + threadIdx.x;
    if (feat >= dim) return;
    float s = 0.f;
    for (int b = 0; b < batch; ++b) s += d_dOut[b*dim + feat];
    d_dBias[feat] = s;
}

// Same standard batchnorm backward formula as VLyn_ml.cu's kernelBatchNormBackward.
VLYN_GLOBAL void kernelMLNBatchNormBackward(
    const float* __restrict__ d_dY,
    const float* __restrict__ d_xhat,
    const float* __restrict__ d_gamma,
    const float* __restrict__ d_invStd,
    float* __restrict__       d_dX,
    float* __restrict__       d_dGamma,
    float* __restrict__       d_dBeta,
    int batch, int dim)
{
    VLYN_SHARED float smDGamma[MLN_H1_DIM + 4];
    VLYN_SHARED float smDBeta[MLN_H1_DIM + 4];

    int feat = blockIdx.x;
    if (feat >= dim) return;

    float sumDGamma = 0.f, sumDBeta = 0.f;
    for (int b = threadIdx.x; b < batch; b += blockDim.x) {
        float dy = d_dY[b*dim + feat];
        float xh = d_xhat[b*dim + feat];
        sumDGamma += dy * xh;
        sumDBeta  += dy;
    }
    VLYN_WARP_REDUCE_SUM(sumDGamma);
    VLYN_WARP_REDUCE_SUM(sumDBeta);
    if (threadIdx.x % VLYN_WARP_SIZE == 0) {
        smDGamma[threadIdx.x / VLYN_WARP_SIZE] = sumDGamma;
        smDBeta[threadIdx.x / VLYN_WARP_SIZE]  = sumDBeta;
    }
    __syncthreads();
    if (threadIdx.x == 0) {
        float totalG = 0.f, totalB = 0.f;
        for (int w = 0; w < blockDim.x/VLYN_WARP_SIZE; w++) {
            totalG += smDGamma[w];
            totalB += smDBeta[w];
        }
        smDGamma[0] = totalG;
        smDBeta[0]  = totalB;
        d_dGamma[feat] = totalG;
        d_dBeta[feat]  = totalB;
    }
    __syncthreads();
    float dGamma = smDGamma[0];
    float dBeta  = smDBeta[0];
    float gamma  = d_gamma[feat];
    float invStd = d_invStd[feat];
    float invBatch = 1.f / (float)batch;

    for (int b = threadIdx.x; b < batch; b += blockDim.x) {
        float dy = d_dY[b*dim + feat];
        float xh = d_xhat[b*dim + feat];
        d_dX[b*dim + feat] = gamma * invStd * invBatch *
            ((float)batch * dy - dBeta - xh * dGamma);
    }
}

// =============================================================================
// Adam optimizer step (shared math, distinct symbol from broad-phase net)
// =============================================================================
VLYN_GLOBAL void kernelMLNAdamStep(
    float* __restrict__ w,
    const float* __restrict__ grad,
    float* __restrict__ m,
    float* __restrict__ v,
    int n,
    float lr, float beta1, float beta2, float eps,
    float bc1, float bc2)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    float g = grad[i];
    float mi = beta1 * m[i] + (1.f - beta1) * g;
    float vi = beta2 * v[i] + (1.f - beta2) * g * g;
    m[i] = mi;
    v[i] = vi;
    float mhat = mi / bc1;
    float vhat = vi / bc2;
    w[i] -= lr * mhat / (sqrtf(vhat) + eps);
}

// =============================================================================
// Combined loss + output gradient:
//   Head 0 (prob):        BCE,  dL/dz0 = p - y        (sigmoid combined grad)
//   Heads 1-4 (regression): MSE, dL/dzi = 2*(pred_i - label_i), masked to 0
//                            when label says "no collision" (y==0), since
//                            depth/normal are meaningless for non-contacts.
// =============================================================================
VLYN_GLOBAL void kernelMLNLoss(
    const float* __restrict__ d_pred,    // [batch x OUT_DIM]
    const float* __restrict__ d_label,   // [batch x OUT_DIM]
    float* __restrict__ d_dout,          // [batch x OUT_DIM] gradient
    float* __restrict__ d_loss,          // [batch] total loss (diagnostic)
    int batch)
{
    int b = blockIdx.x * blockDim.x + threadIdx.x;
    if (b >= batch) return;

    const float* pred  = d_pred  + b * MLN_OUT_DIM;
    const float* label = d_label + b * MLN_OUT_DIM;
    float* dout        = d_dout  + b * MLN_OUT_DIM;

    float p = fmaxf(1e-7f, fminf(1.f - 1e-7f, pred[0]));
    float y = label[0];
    float bce = -(y * logf(p) + (1.f - y) * logf(1.f - p));
    dout[0] = (p - y);

    float mse = 0.f;
    float mask = y;  // only penalize regression heads on true-positive contacts
    for (int k = 1; k < MLN_OUT_DIM; k++) {
        float d = pred[k] - label[k];
        mse += d * d;
        dout[k] = mask * 2.f * d;
    }

    d_loss[b] = bce + mse;
}

// =============================================================================
// Online training step — single ground-truth pair from the GJK/EPA fallback
// =============================================================================
VLynError mlnTrainStep(
    MLNarrowContext* ctx,
    const float* d_input,
    const float* d_label,
    cudaStream_t stream)
{
    return mlnTrainBatch(ctx, d_input, d_label, 1, stream);
}

// =============================================================================
// Batched online training step
//
// Full backward pass through the 3-layer MLP, mirroring VLyn_ml.cu's
// mlTrainStep but with a 5-dim multi-head output (prob + depth + normal),
// where only the sigmoid probability head uses BCE combined-gradient and the
// 4 linear regression heads use plain MSE gradient (2*(pred-label)), masked
// to zero for non-collision ground truth via kernelMLNLoss above.
// =============================================================================
VLynError mlnTrainBatch(
    MLNarrowContext* ctx,
    const float* d_inputs,
    const float* d_labels,
    int batch,
    cudaStream_t stream)
{
    if (batch <= 0 || batch > ctx->maxBatch) return VLYN_ERR_ML_INFERENCE;

    ctx->trainingMode = true;
    cublasSetStream(ctx->cublas, stream);

    VLynError fe = mlnForward(ctx, d_inputs, ctx->d_out, batch, stream);
    if (fe != VLYN_OK) { ctx->trainingMode = false; return fe; }

    const float alpha = 1.f, beta = 0.f;

    float* d_dout;
    float* d_loss;
    cudaMallocAsync(&d_dout, (size_t)batch * MLN_OUT_DIM * sizeof(float), stream);
    cudaMallocAsync(&d_loss, (size_t)batch * sizeof(float), stream);

    int blocks = (batch + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelMLNLoss<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_out, d_labels, d_dout, d_loss, batch);

    // ---- Layer 3 gradients: dW3 = h2^T . dout (col-major SGEMM), db3 = sum(dout) ----
    cublasSgemm_v2(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_T,
                MLN_H2_DIM, MLN_OUT_DIM, batch,
                &alpha,
                ctx->d_h2, MLN_H2_DIM,
                d_dout,    MLN_OUT_DIM,
                &beta,
                ctx->weights.gW3, MLN_H2_DIM);

    int b3Blocks = (MLN_OUT_DIM + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelMLNBiasGradReduce<<<b3Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_dout, ctx->weights.gb3, batch, MLN_OUT_DIM);

    // dh2 = dout . W3
    cublasSgemm_v2(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_N,
                MLN_H2_DIM, batch, MLN_OUT_DIM,
                &alpha,
                ctx->weights.W3, MLN_H2_DIM,
                d_dout,           MLN_OUT_DIM,
                &beta,
                ctx->d_dh2,       MLN_H2_DIM);

    // ---- LeakyReLU2 backward ----
    int n2 = batch * MLN_H2_DIM;
    int lr2Blocks = (n2 + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelMLNLeakyReLUBackward<<<lr2Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_dh2, ctx->d_preAct2, ctx->d_dh2, n2, MLN_LEAKY_ALPHA);

    // ---- BatchNorm2 backward ----
    dim3 bn2Grid(MLN_H2_DIM), bn2Block(min(batch, VLYN_BLOCK_SIZE));
    kernelMLNBatchNormBackward<<<bn2Grid, bn2Block, 0, stream>>>(
        ctx->d_dh2, ctx->d_xhat2, ctx->weights.g2, ctx->d_invStd2,
        ctx->d_dh2, ctx->weights.gg2, ctx->weights.gbe2,
        batch, MLN_H2_DIM);

    // ---- Layer 2 gradients ----
    cublasSgemm_v2(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_T,
                MLN_H1_DIM, MLN_H2_DIM, batch,
                &alpha,
                ctx->d_h1, MLN_H1_DIM,
                ctx->d_dh2, MLN_H2_DIM,
                &beta,
                ctx->weights.gW2, MLN_H1_DIM);

    int b2Blocks = (MLN_H2_DIM + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelMLNBiasGradReduce<<<b2Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_dh2, ctx->weights.gb2, batch, MLN_H2_DIM);

    // dh1 = dh2 . W2
    cublasSgemm_v2(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_N,
                MLN_H1_DIM, batch, MLN_H2_DIM,
                &alpha,
                ctx->weights.W2, MLN_H1_DIM,
                ctx->d_dh2,       MLN_H2_DIM,
                &beta,
                ctx->d_dh1,       MLN_H1_DIM);

    // ---- LeakyReLU1 backward ----
    int n1 = batch * MLN_H1_DIM;
    int lr1Blocks = (n1 + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelMLNLeakyReLUBackward<<<lr1Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_dh1, ctx->d_preAct1, ctx->d_dh1, n1, MLN_LEAKY_ALPHA);

    // ---- BatchNorm1 backward ----
    dim3 bn1Grid(MLN_H1_DIM), bn1Block(min(batch, VLYN_BLOCK_SIZE));
    kernelMLNBatchNormBackward<<<bn1Grid, bn1Block, 0, stream>>>(
        ctx->d_dh1, ctx->d_xhat1, ctx->weights.g1, ctx->d_invStd1,
        ctx->d_dh1, ctx->weights.gg1, ctx->weights.gbe1,
        batch, MLN_H1_DIM);

    // ---- Layer 1 gradients (dh0 not needed further — geometric input features
    //      are not learnable, so we save one SGEMM here) ----
    cublasSgemm_v2(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_T,
                MLN_IN_DIM, MLN_H1_DIM, batch,
                &alpha,
                d_inputs,   MLN_IN_DIM,
                ctx->d_dh1, MLN_H1_DIM,
                &beta,
                ctx->weights.gW1, MLN_IN_DIM);

    int b1Blocks = (MLN_H1_DIM + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelMLNBiasGradReduce<<<b1Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_dh1, ctx->weights.gb1, batch, MLN_H1_DIM);

    // ---- Adam updates for every learnable tensor ----
    ctx->weights.stepCount++;
    float t   = (float)ctx->weights.stepCount;
    float bc1 = 1.f - powf(MLN_BETA1, t);
    float bc2 = 1.f - powf(MLN_BETA2, t);

    auto adamUpdate = [&](float* w, float* g, float* m, float* v, int n) {
        int blk = (n + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
        kernelMLNAdamStep<<<blk, VLYN_BLOCK_SIZE, 0, stream>>>(
            w, g, m, v, n, MLN_LR, MLN_BETA1, MLN_BETA2, MLN_EPSILON, bc1, bc2);
    };

    adamUpdate(ctx->weights.W1, ctx->weights.gW1, ctx->weights.mW1, ctx->weights.vW1, MLN_H1_DIM * MLN_IN_DIM);
    adamUpdate(ctx->weights.b1, ctx->weights.gb1, ctx->weights.mb1, ctx->weights.vb1, MLN_H1_DIM);
    adamUpdate(ctx->weights.g1, ctx->weights.gg1, ctx->weights.mg1, ctx->weights.vg1, MLN_H1_DIM);
    adamUpdate(ctx->weights.be1, ctx->weights.gbe1, ctx->weights.mbe1, ctx->weights.vbe1, MLN_H1_DIM);

    adamUpdate(ctx->weights.W2, ctx->weights.gW2, ctx->weights.mW2, ctx->weights.vW2, MLN_H2_DIM * MLN_H1_DIM);
    adamUpdate(ctx->weights.b2, ctx->weights.gb2, ctx->weights.mb2, ctx->weights.vb2, MLN_H2_DIM);
    adamUpdate(ctx->weights.g2, ctx->weights.gg2, ctx->weights.mg2, ctx->weights.vg2, MLN_H2_DIM);
    adamUpdate(ctx->weights.be2, ctx->weights.gbe2, ctx->weights.mbe2, ctx->weights.vbe2, MLN_H2_DIM);

    adamUpdate(ctx->weights.W3, ctx->weights.gW3, ctx->weights.mW3, ctx->weights.vW3, MLN_OUT_DIM * MLN_H2_DIM);
    adamUpdate(ctx->weights.b3, ctx->weights.gb3, ctx->weights.mb3, ctx->weights.vb3, MLN_OUT_DIM);

    ctx->trainingMode = false;
    cudaFreeAsync(d_dout, stream);
    cudaFreeAsync(d_loss, stream);
    return VLYN_OK;
}

// =============================================================================
// Free narrow-phase ML context
// =============================================================================
VLynError mlnFreeContext(MLNarrowContext* ctx) {
    MLNarrowWeights& w = ctx->weights;
    cudaFree(w.W1); cudaFree(w.b1);
    cudaFree(w.g1); cudaFree(w.be1); cudaFree(w.rm1); cudaFree(w.rv1);
    cudaFree(w.W2); cudaFree(w.b2);
    cudaFree(w.g2); cudaFree(w.be2); cudaFree(w.rm2); cudaFree(w.rv2);
    cudaFree(w.W3); cudaFree(w.b3);

    cudaFree(w.mW1); cudaFree(w.vW1); cudaFree(w.mb1); cudaFree(w.vb1);
    cudaFree(w.mW2); cudaFree(w.vW2); cudaFree(w.mb2); cudaFree(w.vb2);
    cudaFree(w.mW3); cudaFree(w.vW3); cudaFree(w.mb3); cudaFree(w.vb3);

    cudaFree(w.mg1); cudaFree(w.vg1); cudaFree(w.mbe1); cudaFree(w.vbe1);
    cudaFree(w.mg2); cudaFree(w.vg2); cudaFree(w.mbe2); cudaFree(w.vbe2);

    cudaFree(w.gW1); cudaFree(w.gb1); cudaFree(w.gg1); cudaFree(w.gbe1);
    cudaFree(w.gW2); cudaFree(w.gb2); cudaFree(w.gg2); cudaFree(w.gbe2);
    cudaFree(w.gW3); cudaFree(w.gb3);

    cudaFree(ctx->d_h0); cudaFree(ctx->d_h1); cudaFree(ctx->d_h2);
    cudaFree(ctx->d_out);
    cudaFree(ctx->d_dh0); cudaFree(ctx->d_dh1); cudaFree(ctx->d_dh2);
    cudaFree(ctx->d_xhat1); cudaFree(ctx->d_invStd1); cudaFree(ctx->d_preAct1);
    cudaFree(ctx->d_xhat2); cudaFree(ctx->d_invStd2); cudaFree(ctx->d_preAct2);
    cudaFree(ctx->d_featMean); cudaFree(ctx->d_featStd);

    cublasDestroy_v2(ctx->cublas);
    return VLYN_OK;
}

// =============================================================================
// End of VLyn_ml_narrow.cu
// =============================================================================
