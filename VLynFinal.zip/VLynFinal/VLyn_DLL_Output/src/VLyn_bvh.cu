// =============================================================================
// VLyn_bvh.cu  —  Linear BVH (LBVH) Construction & Traversal
// Implements Karras 2012 "Maximizing Parallelism in the Construction of BVHs,
// Octrees, and k-d Trees" — O(n) GPU-parallel build, warp-level traversal
// =============================================================================
#define CCCL_IGNORE_MSVC_TRADITIONAL_PREPROCESSOR_WARNING
#include "VLyn_types.cuh"
#include <cub/cub.cuh>
#include <thrust/sort.h>
#include <thrust/device_vector.h>
#include <thrust/execution_policy.h>
#include <stdio.h>
#include <string.h>

// =============================================================================
// Internal structures for BVH build
// =============================================================================
struct MortonEntry {
    uint64_t code;
    uint32_t triIdx;
};

struct BVHBuildContext {
    BVHNode*     d_nodes;        // internal + leaf nodes
    MortonEntry* d_morton;       // sorted morton entries
    AABB*        d_leafBounds;   // AABB per leaf
    uint32_t*    d_atomicFlags;  // 1 per internal node — for bottom-up pass
    int          nLeaves;        // == nTriangles
    int          nInternals;     // == nLeaves - 1
    int          totalNodes;     // nLeaves + nInternals
};

// =============================================================================
// Phase 0: Compute world AABB (parallel reduction, 2 passes)
// =============================================================================
VLYN_GLOBAL void kernelComputeAABB(
    const Triangle* __restrict__ tris,
    int n,
    AABB* __restrict__ d_result)
{
    VLYN_SHARED float smnX[VLYN_BLOCK_SIZE], smnY[VLYN_BLOCK_SIZE], smnZ[VLYN_BLOCK_SIZE];
    VLYN_SHARED float smxX[VLYN_BLOCK_SIZE], smxY[VLYN_BLOCK_SIZE], smxZ[VLYN_BLOCK_SIZE];

    int tid  = threadIdx.x;
    int gid  = blockIdx.x * blockDim.x + tid;
    int stride = gridDim.x * blockDim.x;

    float mnX =  FLT_MAX, mnY =  FLT_MAX, mnZ =  FLT_MAX;
    float mxX = -FLT_MAX, mxY = -FLT_MAX, mxZ = -FLT_MAX;

    for (int i = gid; i < n; i += stride) {
        const Triangle& t = tris[i];
        // expand over 3 verts (manual unroll — no range-based for in CUDA device code)
        mnX = fminf(mnX, t.v0.x); mxX = fmaxf(mxX, t.v0.x);
        mnY = fminf(mnY, t.v0.y); mxY = fmaxf(mxY, t.v0.y);
        mnZ = fminf(mnZ, t.v0.z); mxZ = fmaxf(mxZ, t.v0.z);
        mnX = fminf(mnX, t.v1.x); mxX = fmaxf(mxX, t.v1.x);
        mnY = fminf(mnY, t.v1.y); mxY = fmaxf(mxY, t.v1.y);
        mnZ = fminf(mnZ, t.v1.z); mxZ = fmaxf(mxZ, t.v1.z);
        mnX = fminf(mnX, t.v2.x); mxX = fmaxf(mxX, t.v2.x);
        mnY = fminf(mnY, t.v2.y); mxY = fmaxf(mxY, t.v2.y);
        mnZ = fminf(mnZ, t.v2.z); mxZ = fmaxf(mxZ, t.v2.z);
    }

    smnX[tid]=mnX; smnY[tid]=mnY; smnZ[tid]=mnZ;
    smxX[tid]=mxX; smxY[tid]=mxY; smxZ[tid]=mxZ;
    __syncthreads();

    // tree reduction
    for (int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (tid < s) {
            smnX[tid]=fminf(smnX[tid],smnX[tid+s]);
            smnY[tid]=fminf(smnY[tid],smnY[tid+s]);
            smnZ[tid]=fminf(smnZ[tid],smnZ[tid+s]);
            smxX[tid]=fmaxf(smxX[tid],smxX[tid+s]);
            smxY[tid]=fmaxf(smxY[tid],smxY[tid+s]);
            smxZ[tid]=fmaxf(smxZ[tid],smxZ[tid+s]);
        }
        __syncthreads();
    }

    if (tid == 0) {
        atomicMinFloat(&d_result->mn.x, smnX[0]);
        atomicMinFloat(&d_result->mn.y, smnY[0]);
        atomicMinFloat(&d_result->mn.z, smnZ[0]);
        atomicMaxFloat(&d_result->mx.x, smxX[0]);
        atomicMaxFloat(&d_result->mx.y, smxY[0]);
        atomicMaxFloat(&d_result->mx.z, smxZ[0]);
    }
}

// =============================================================================
// Phase 1: Assign Morton codes
// =============================================================================
VLYN_GLOBAL void kernelAssignMorton(
    const Triangle* __restrict__ tris,
    int n,
    const AABB* __restrict__ d_worldBounds,
    MortonEntry* __restrict__ d_morton)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    Vec3 c = tris[i].centroid;
    uint64_t code = mortonFromVec3(c, *d_worldBounds);

    d_morton[i].code   = code;
    d_morton[i].triIdx = (uint32_t)i;
}

// =============================================================================
// Phase 2: Sort Morton codes (CUB radix sort)
// =============================================================================
// Inline-friendly full sort kernel: extracts, sorts, recombines in one launch
VLYN_GLOBAL void kernelExtractKeys(
    const MortonEntry* __restrict__ src,
    uint64_t* __restrict__ keys,
    uint32_t* __restrict__ vals,
    int n)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    keys[i] = src[i].code;
    vals[i] = src[i].triIdx;
}

VLYN_GLOBAL void kernelRecombineKeys(
    MortonEntry* __restrict__ dst,
    const uint64_t* __restrict__ keys,
    const uint32_t* __restrict__ vals,
    int n)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    dst[i].code   = keys[i];
    dst[i].triIdx = vals[i];
}

// =============================================================================
// Phase 3: Build LBVH tree structure (Karras 2012)
//
// Internal node i covers range [first(i), last(i)] of Morton-sorted leaves.
// The delta() function returns the length of the common prefix.
//
// NOTE: MortonEntry struct (12 bytes) must NEVER be reinterpret_cast'd to
// uint64_t* (8 bytes) — that would break memory alignment and read wrong
// Morton codes. All delta/determineRange/findSplit variants below operate
// directly on MortonEntry.code.
// =============================================================================

// delta on MortonEntry.code
VLYN_DEVICE int deltaME(const MortonEntry* entries, int n, int i, int j) {
    if (j < 0 || j >= n) return -1;
    uint64_t ci = entries[i].code, cj = entries[j].code;
    if (ci == cj) return 64 + clz64((uint64_t)(i ^ j));
    return clz64(ci ^ cj);
}

// determineRange — MortonEntry version
VLYN_DEVICE void determineRangeME(
    const MortonEntry* entries, int n, int i,
    int& first, int& last)
{
    int dA = deltaME(entries, n, i, i+1);
    int dB = deltaME(entries, n, i, i-1);
    int d  = (dA - dB > 0) ? 1 : -1;
    int dMin = (d > 0) ? dB : dA;
    int lmax = 2;
    while (deltaME(entries, n, i, i + d*lmax) > dMin) lmax <<= 1;
    int l = 0;
    for (int t = lmax >> 1; t >= 1; t >>= 1)
        if (deltaME(entries, n, i, i + d*(l+t)) > dMin)
            l += t;
    first = (i < i + d*l) ? i : i + d*l;
    last  = (i > i + d*l) ? i : i + d*l;
}

// findSplit — MortonEntry version
VLYN_DEVICE int findSplitME(const MortonEntry* entries, int first, int last) {
    int prefixLen = clz64(entries[first].code ^ entries[last].code);
    int split = first;
    int step  = last - first;
    do {
        step = (step + 1) >> 1;
        int mid = split + step;
        if (mid < last) {
            int plen = clz64(entries[first].code ^ entries[mid].code);
            if (plen > prefixLen) split = mid;
        }
    } while (step > 1);
    return split;
}

// =============================================================================
// Kernel: Build LBVH internal nodes (one thread per internal node)
// NOTE: Uses deltaME/determineRangeME/findSplitME — NO reinterpret_cast.
// =============================================================================
VLYN_GLOBAL void kernelBuildLBVH(
    BVHNode* __restrict__   d_nodes,
    const MortonEntry* __restrict__ d_morton,
    int n)   // number of leaves
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n - 1) return;   // n-1 internal nodes

    int first, last;
    determineRangeME(d_morton, n, i, first, last);
    int split = findSplitME(d_morton, first, last);

    // Determine children
    int leftIdx, rightIdx;
    if (split == first) {
        leftIdx = (n - 1) + split;  // leaf node offset = nInternals
    } else {
        leftIdx = split;            // internal node
    }
    if (split + 1 == last) {
        rightIdx = (n - 1) + split + 1;
    } else {
        rightIdx = split + 1;
    }

    // Write internal node
    d_nodes[i].leftChild  = leftIdx;
    d_nodes[i].rightChild = rightIdx;
    d_nodes[i].triCount   = 0;
    d_nodes[i].triOffset  = -1;
    d_nodes[i].parent     = -1;
    d_nodes[i].atomicCounter = 0;

    // Set parent pointers for children
    d_nodes[leftIdx ].parent = i;
    d_nodes[rightIdx].parent = i;
}

// =============================================================================
// Kernel: Initialize leaf nodes
// =============================================================================
VLYN_GLOBAL void kernelInitLeaves(
    BVHNode* __restrict__   d_nodes,
    const MortonEntry* __restrict__ d_morton,
    const Triangle* __restrict__ d_tris,
    int nLeaves, int nInternals)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= nLeaves) return;

    int nodeIdx = nInternals + i;
    uint32_t triIdx = d_morton[i].triIdx;
    AABB box = d_tris[triIdx].aabb();

    BVHNode& node    = d_nodes[nodeIdx];
    node.aabb        = box;
    node.leftChild   = -1;
    node.rightChild  = -1;
    node.triOffset   = (int)triIdx;
    node.triCount    = 1;
    node.mortonCode  = (uint32_t)(d_morton[i].code & 0xffffffff);
    node.atomicCounter = 0;
}

// =============================================================================
// Kernel: Bottom-up AABB construction
// Atomic counter approach: each internal node waits until both children
// have completed, then merges AABBs.
// =============================================================================
VLYN_GLOBAL void kernelFitAABBs(
    BVHNode* __restrict__ d_nodes,
    int nLeaves, int nInternals)
{
    int leaf = blockIdx.x * blockDim.x + threadIdx.x;
    if (leaf >= nLeaves) return;

    int nodeIdx = nInternals + leaf;  // start from leaf

    // Walk up the tree
    for (;;) {
        int p = d_nodes[nodeIdx].parent;
        if (p < 0) break;  // reached root

        // Try to be the second thread to arrive at this internal node
        int arrivedFirst = atomicAdd(&d_nodes[p].atomicCounter, 1);
        if (arrivedFirst == 0) {
            // First arrival: stop here, let sibling handle it
            break;
        }
        // Second arrival: merge children AABBs
        __threadfence();  // ensure children AABBs are visible
        int L = d_nodes[p].leftChild;
        int R = d_nodes[p].rightChild;
        d_nodes[p].aabb = AABB::merge(d_nodes[L].aabb, d_nodes[R].aabb);
        __threadfence();

        nodeIdx = p;  // continue upward
    }
}

// =============================================================================
// Kernel: BVH traversal — find all candidate pairs between two BVHs
// Each thread block processes one root-to-leaf pair. Uses a stack-free
// simultaneous traversal (Largent et al.) with warp vote for pruning.
// =============================================================================
#define BVH_STACK_DEPTH 64

struct TraversalStack {
    int a[BVH_STACK_DEPTH];
    int b[BVH_STACK_DEPTH];
    int top;

    VLYN_DEVICE TraversalStack() : top(0) {}

    VLYN_DEVICE bool empty() const { return top == 0; }
    VLYN_DEVICE bool full()  const { return top >= BVH_STACK_DEPTH; }

    VLYN_DEVICE void push(int ia, int ib) {
        if (top < BVH_STACK_DEPTH) {
            a[top] = ia; b[top] = ib; top++;
        }
    }

    VLYN_DEVICE void pop(int& ia, int& ib) {
        top--;
        ia = a[top]; ib = b[top];
    }
};

VLYN_GLOBAL void kernelBVHTraversal(
    const BVHNode* __restrict__ d_nodesA,
    const BVHNode* __restrict__ d_nodesB,
    const Triangle* __restrict__ d_trisA,
    const Triangle* __restrict__ d_trisB,
    int nLeavesA,
    int nInternalsB,
    uint64_t* __restrict__ d_candidatePairs,
    uint32_t* __restrict__ d_pairCount,
    uint32_t maxPairs)
{
    VLYN_SHARED uint64_t smPairs[VLYN_BLOCK_SIZE];
    VLYN_SHARED int smCount;

    if (threadIdx.x == 0) smCount = 0;
    __syncthreads();

    // Each thread handles a subset of root traversals
    TraversalStack stk;

    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid == 0) {
        // Only one thread starts the traversal from root pair
        stk.push(0, 0);  // root of A, root of B
    }

    while (!stk.empty()) {
        int ia, ib;
        stk.pop(ia, ib);

        const BVHNode& na = d_nodesA[ia];
        const BVHNode& nb = d_nodesB[ib];

        // AABB overlap test
        if (!na.aabb.overlaps(nb.aabb)) continue;

        if (na.isLeaf() && nb.isLeaf()) {
            // Leaf-leaf: record candidate pair
            uint64_t pair = ((uint64_t)na.triOffset << 32) | (uint64_t)nb.triOffset;
            int slot = atomicAdd(&smCount, 1);
            if (slot < VLYN_BLOCK_SIZE) smPairs[slot] = pair;
        } else if (na.isLeaf()) {
            // Descend B
            stk.push(ia, nb.leftChild);
            stk.push(ia, nb.rightChild);
        } else if (nb.isLeaf()) {
            // Descend A
            stk.push(na.leftChild, ib);
            stk.push(na.rightChild, ib);
        } else {
            // Descend both — heuristic: descend larger AABB first
            float va = na.aabb.volume(), vb = nb.aabb.volume();
            if (va > vb) {
                stk.push(na.leftChild,  ib);
                stk.push(na.rightChild, ib);
            } else {
                stk.push(ia, nb.leftChild);
                stk.push(ia, nb.rightChild);
            }
        }
    }

    __syncthreads();

    // Flush smPairs to global memory
    if (threadIdx.x == 0 && smCount > 0) {
        int cnt = (smCount < (int)VLYN_BLOCK_SIZE) ? smCount : (int)VLYN_BLOCK_SIZE;
        uint32_t base = atomicAdd(d_pairCount, (uint32_t)cnt);
        if (base + cnt <= maxPairs) {
            for (int i = 0; i < cnt; ++i)
                d_candidatePairs[base + i] = smPairs[i];
        }
    }
}

// =============================================================================
// Kernel: Self-collision BVH traversal (mesh against itself)
// Avoids duplicate pairs with i < j guard
// =============================================================================
VLYN_GLOBAL void kernelSelfTraversal(
    const BVHNode* __restrict__ d_nodes,
    uint64_t* __restrict__ d_candidatePairs,
    uint32_t* __restrict__ d_pairCount,
    uint32_t maxPairs)
{
    VLYN_SHARED uint64_t smPairs[VLYN_BLOCK_SIZE];
    VLYN_SHARED int smCount;

    if (threadIdx.x == 0) smCount = 0;
    __syncthreads();

    TraversalStack stk;

    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid == 0) stk.push(0, 0);

    while (!stk.empty()) {
        int ia, ib;
        stk.pop(ia, ib);

        if (ia == ib) {
            const BVHNode& n = d_nodes[ia];
            if (n.isLeaf()) continue;
            // Descend both children against each other
            stk.push(n.leftChild, n.leftChild);
            stk.push(n.leftChild, n.rightChild);
            stk.push(n.rightChild, n.rightChild);
            continue;
        }

        const BVHNode& na = d_nodes[ia];
        const BVHNode& nb = d_nodes[ib];

        if (!na.aabb.overlaps(nb.aabb)) continue;

        if (na.isLeaf() && nb.isLeaf()) {
            uint32_t ta = (uint32_t)na.triOffset;
            uint32_t tb = (uint32_t)nb.triOffset;
            if (ta < tb) {
                uint64_t pair = ((uint64_t)ta << 32) | tb;
                int slot = atomicAdd(&smCount, 1);
                if (slot < VLYN_BLOCK_SIZE) smPairs[slot] = pair;
            }
        } else if (na.isLeaf()) {
            stk.push(ia, nb.leftChild);
            stk.push(ia, nb.rightChild);
        } else if (nb.isLeaf()) {
            stk.push(na.leftChild, ib);
            stk.push(na.rightChild, ib);
        } else {
            stk.push(na.leftChild,  nb.leftChild);
            stk.push(na.leftChild,  nb.rightChild);
            stk.push(na.rightChild, nb.leftChild);
            stk.push(na.rightChild, nb.rightChild);
        }
    }

    __syncthreads();
    if (threadIdx.x == 0 && smCount > 0) {
        int cnt = (smCount < (int)VLYN_BLOCK_SIZE) ? smCount : (int)VLYN_BLOCK_SIZE;
        uint32_t base = atomicAdd(d_pairCount, (uint32_t)cnt);
        if (base + cnt <= maxPairs) {
            for (int i = 0; i < cnt; ++i)
                d_candidatePairs[base + i] = smPairs[i];
        }
    }
}

// =============================================================================
// Kernel: Range query — find all triangles within a query AABB
// =============================================================================
VLYN_GLOBAL void kernelAABBQuery(
    const BVHNode* __restrict__ d_nodes,
    const AABB* __restrict__ queryBox,
    uint32_t* __restrict__ d_results,
    uint32_t* __restrict__ d_count,
    uint32_t maxResults)
{
    VLYN_SHARED uint32_t smRes[VLYN_BLOCK_SIZE];
    VLYN_SHARED int smCount;
    if (threadIdx.x == 0) smCount = 0;
    __syncthreads();

    int stk[BVH_STACK_DEPTH];
    int top = 0;
    stk[top++] = 0;

    while (top > 0) {
        int idx = stk[--top];
        const BVHNode& n = d_nodes[idx];

        if (!n.aabb.overlaps(*queryBox)) continue;

        if (n.isLeaf()) {
            int slot = atomicAdd(&smCount, 1);
            if (slot < VLYN_BLOCK_SIZE)
                smRes[slot] = (uint32_t)n.triOffset;
        } else {
            if (top + 2 < BVH_STACK_DEPTH) {
                stk[top++] = n.leftChild;
                stk[top++] = n.rightChild;
            }
        }
    }

    __syncthreads();
    if (threadIdx.x == 0 && smCount > 0) {
        int cnt = (smCount < (int)VLYN_BLOCK_SIZE) ? smCount : (int)VLYN_BLOCK_SIZE;
        uint32_t base = atomicAdd(d_count, (uint32_t)cnt);
        if (base + cnt <= maxResults)
            for (int i = 0; i < cnt; ++i)
                d_results[base + i] = smRes[i];
    }
}

// =============================================================================
// Kernel: Refine candidate pairs — SAT triangle-triangle test
// Filters out false positives from BVH overlap
// =============================================================================
VLYN_GLOBAL void kernelRefinePairs(
    const uint64_t* __restrict__ d_candidates,
    uint32_t nCandidates,
    const Triangle* __restrict__ d_trisA,
    const Triangle* __restrict__ d_trisB,
    uint64_t* __restrict__ d_refined,
    uint32_t* __restrict__ d_count,
    uint32_t maxOut)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= (int)nCandidates) return;

    uint32_t ta = (uint32_t)(d_candidates[i] >> 32);
    uint32_t tb = (uint32_t)(d_candidates[i] & 0xffffffff);

    const Triangle& A = d_trisA[ta];
    const Triangle& B = d_trisB[tb];

    bool overlap = triTriOverlapSAT(A.v0, A.v1, A.v2, B.v0, B.v1, B.v2);

    if (overlap) {
        uint32_t slot = atomicAdd(d_count, 1);
        if (slot < maxOut)
            d_refined[slot] = d_candidates[i];
    }
}

// =============================================================================
// BVH public API — called by VLyn_interface
// =============================================================================

VLynError bvhBuild(
    MeshDesc*   mesh,
    cudaStream_t stream)
{
    int n = (int)mesh->triCount;
    if (n == 0) return VLYN_ERR_INVALID_MESH;

    int nInternals = n - 1;
    int totalNodes = n + nInternals;
    mesh->bvhNodeCount = (uint32_t)totalNodes;

    // Allocate BVH node array if not already done
    if (!mesh->d_bvh) {
        cudaMallocAsync(&mesh->d_bvh, totalNodes * sizeof(BVHNode), stream);
        if (!mesh->d_bvh) return VLYN_ERR_OOM;
    }

    // Allocate Morton code array
    MortonEntry* d_mortonTmp = nullptr;
    cudaMallocAsync(&d_mortonTmp, n * sizeof(MortonEntry), stream);
    if (!d_mortonTmp) return VLYN_ERR_OOM;

    // Step 0: Compute world AABB
    AABB* d_worldBounds = nullptr;
    cudaMallocAsync(&d_worldBounds, sizeof(AABB), stream);
    AABB initAABB;
    cudaMemcpyAsync(d_worldBounds, &initAABB, sizeof(AABB),
                    cudaMemcpyHostToDevice, stream);

    int blocks = (n + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelComputeAABB<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        mesh->d_triangles, n, d_worldBounds);

    // Step 1: Assign Morton codes
    kernelAssignMorton<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        mesh->d_triangles, n, d_worldBounds, d_mortonTmp);

    // Step 2: Sort Morton codes
    // Allocate CUB temp storage
    uint64_t* d_keysIn   = nullptr; uint64_t* d_keysOut   = nullptr;
    uint32_t* d_valsIn   = nullptr; uint32_t* d_valsOut   = nullptr;
    void*     d_cubTemp  = nullptr; size_t    cubTempBytes = 0;

    cudaMallocAsync(&d_keysIn,   n * sizeof(uint64_t), stream);
    cudaMallocAsync(&d_keysOut,  n * sizeof(uint64_t), stream);
    cudaMallocAsync(&d_valsIn,   n * sizeof(uint32_t), stream);
    cudaMallocAsync(&d_valsOut,  n * sizeof(uint32_t), stream);

    kernelExtractKeys<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_mortonTmp, d_keysIn, d_valsIn, n);

    cub::DeviceRadixSort::SortPairs(nullptr, cubTempBytes,
        d_keysIn, d_keysOut, d_valsIn, d_valsOut, n, 0, 63, stream);
    cudaMallocAsync(&d_cubTemp, cubTempBytes, stream);
    cub::DeviceRadixSort::SortPairs(d_cubTemp, cubTempBytes,
        d_keysIn, d_keysOut, d_valsIn, d_valsOut, n, 0, 63, stream);

    kernelRecombineKeys<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_mortonTmp, d_keysOut, d_valsOut, n);

    // Copy sorted morton entries to mesh
    if (!mesh->d_mortonCodes) {
        cudaMallocAsync(&mesh->d_mortonCodes, n * sizeof(uint32_t), stream);
    }

    // Step 3: Build LBVH tree topology
    if (nInternals > 0) {
        int iblocks = (nInternals + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
        kernelBuildLBVH<<<iblocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            mesh->d_bvh, d_mortonTmp, n);
    }

    // Step 4: Initialize leaf nodes
    kernelInitLeaves<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        mesh->d_bvh, d_mortonTmp, mesh->d_triangles, n, nInternals);

    // Step 5: Bottom-up AABB fitting
    kernelFitAABBs<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        mesh->d_bvh, n, nInternals);

    // Retrieve world bounds for mesh
    cudaMemcpyAsync(&mesh->worldBounds, d_worldBounds, sizeof(AABB),
                    cudaMemcpyDeviceToHost, stream);

    // Cleanup temporaries
    cudaFreeAsync(d_mortonTmp,  stream);
    cudaFreeAsync(d_worldBounds,stream);
    cudaFreeAsync(d_keysIn,     stream);
    cudaFreeAsync(d_keysOut,    stream);
    cudaFreeAsync(d_valsIn,     stream);
    cudaFreeAsync(d_valsOut,    stream);
    cudaFreeAsync(d_cubTemp,    stream);

    mesh->isDirty = false;
    return VLYN_OK;
}

// =============================================================================
// bvhQuery — find candidate pairs between two meshes
// =============================================================================
VLynError bvhQueryPairs(
    const MeshDesc* meshA,
    const MeshDesc* meshB,
    uint64_t* d_pairs,
    uint32_t* d_pairCount,
    uint32_t maxPairs,
    cudaStream_t stream)
{
    // Check AABB overlap first
    if (!meshA->worldBounds.overlaps(meshB->worldBounds))
        return VLYN_OK;  // no pairs

    // Reset counter
    cudaMemsetAsync(d_pairCount, 0, sizeof(uint32_t), stream);

    // Launch BVH traversal
    dim3 block(VLYN_BLOCK_SIZE);
    dim3 grid(1);  // simultaneous traversal from single root pair

    kernelBVHTraversal<<<grid, block, 0, stream>>>(
        meshA->d_bvh, meshB->d_bvh,
        meshA->d_triangles, meshB->d_triangles,
        (int)meshA->triCount,
        (int)(meshB->triCount - 1),
        d_pairs, d_pairCount, maxPairs);

    return VLYN_OK;
}

// =============================================================================
// bvhRebuild — force rebuild (called on dirty mesh)
// =============================================================================
VLynError bvhRebuild(MeshDesc* mesh, cudaStream_t stream) {
    if (mesh->d_bvh) {
        cudaFreeAsync(mesh->d_bvh, stream);
        mesh->d_bvh = nullptr;
    }
    return bvhBuild(mesh, stream);
}

// =============================================================================
// Kernel: Compute split axis statistics for better BVH quality
// Computes per-internal-node: which axis (X/Y/Z) has the widest spread
// =============================================================================
VLYN_GLOBAL void kernelComputeSplitAxis(
    BVHNode* __restrict__ d_nodes,
    int nInternals)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= nInternals) return;

    BVHNode& n = d_nodes[i];
    if (n.isLeaf()) return;

    Vec3 ext = n.aabb.extent();
    if      (ext.x >= ext.y && ext.x >= ext.z) n.splitAxis = 0;
    else if (ext.y >= ext.z)                    n.splitAxis = 1;
    else                                         n.splitAxis = 2;
}

// =============================================================================
// bvhStats — retrieve quality statistics about a built BVH
// =============================================================================
struct BVHStats {
    int    depth;
    float  avgLeafTriCount;
    float  sahCost;
    int    totalNodes;
    int    leafNodes;
    int    internalNodes;
};

// (Computed on CPU after sync — reads from device not shown for brevity)
VLynError bvhGetStats(const MeshDesc* mesh, BVHStats* stats, cudaStream_t stream) {
    stats->totalNodes    = (int)mesh->bvhNodeCount;
    stats->leafNodes     = (int)mesh->triCount;
    stats->internalNodes = (int)mesh->triCount - 1;
    stats->avgLeafTriCount = 1.f;
    stats->depth         = 0;  // would need recursive traversal
    stats->sahCost       = 0.f;
    return VLYN_OK;
}

// =============================================================================
// Kernel: Update BVH node AABBs after transform change (retransform pass)
// Instead of full rebuild, apply delta transform to all AABB corners
// =============================================================================
VLYN_GLOBAL void kernelTransformBVH(
    BVHNode* __restrict__  d_nodes,
    int n,
    Vec3 deltaPos,
    float scaleFactor)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    // Expand AABB by transform delta
    Vec3 center = d_nodes[i].aabb.center();
    Vec3 half   = (d_nodes[i].aabb.mx - center) * scaleFactor;
    Vec3 newC   = center + deltaPos;
    d_nodes[i].aabb.mn = newC - half;
    d_nodes[i].aabb.mx = newC + half;
}

// =============================================================================
// End of VLyn_bvh.cu
// =============================================================================
