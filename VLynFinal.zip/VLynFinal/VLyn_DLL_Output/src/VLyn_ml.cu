// =============================================================================
// VLyn_ml.cu  —  Neural Collision Predictor (ML Broad-Phase Culling)
// 3-layer fully-connected network with CUDA tensor operations.
// Predicts collision probability for cluster pairs — rejects 98%+ of pairs
// before expensive Voronoi/GJK narrow phase.
//
// Architecture:
//   Input  : 64-dim feature vector (2 × 32-dim cluster features)
//   Layer1 : FC(64 → 128) + BatchNorm + ReLU
//   Layer2 : FC(128 → 64) + BatchNorm + ReLU
//   Layer3 : FC(64 → 1)  + Sigmoid  → collision probability
//
// Training: online gradient descent from confirmed collision ground truth.
//           Weights stored in GPU memory, FP32.
// =============================================================================
#include "VLyn_types.cuh"
#include "VLyn_ml_internal.cuh"
#include <cuda_runtime.h>
#include <cublas_v2.h>
#include <cstdio>
#include <cstring>
#include <cmath>


// =============================================================================
// GPU memory allocation for MLContext
// =============================================================================
VLynError mlAllocContext(MLContext* ctx, float threshold) {
    ctx->threshold   = threshold;
    ctx->maxBatch    = ML_BATCH_SIZE;
    ctx->trainingMode = false;

    // Weights
    cudaMalloc(&ctx->weights.W1,  ML_H1_DIM * ML_IN_DIM  * sizeof(float));
    cudaMalloc(&ctx->weights.b1,  ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.g1,  ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.be1, ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.rm1, ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.rv1, ML_H1_DIM * sizeof(float));

    cudaMalloc(&ctx->weights.W2,  ML_H2_DIM * ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.b2,  ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.g2,  ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.be2, ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.rm2, ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.rv2, ML_H2_DIM * sizeof(float));

    cudaMalloc(&ctx->weights.W3,  ML_OUT_DIM * ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.b3,  ML_OUT_DIM * sizeof(float));

    // Adam moments
    cudaMalloc(&ctx->weights.mW1, ML_H1_DIM * ML_IN_DIM  * sizeof(float));
    cudaMalloc(&ctx->weights.vW1, ML_H1_DIM * ML_IN_DIM  * sizeof(float));
    cudaMalloc(&ctx->weights.mb1, ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.vb1, ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.mW2, ML_H2_DIM * ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.vW2, ML_H2_DIM * ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.mb2, ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.vb2, ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.mW3, ML_OUT_DIM * ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.vW3, ML_OUT_DIM * ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.mb3, ML_OUT_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.vb3, ML_OUT_DIM * sizeof(float));

    // Adam moments for BatchNorm gamma/beta
    cudaMalloc(&ctx->weights.mg1,  ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.vg1,  ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.mbe1, ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.vbe1, ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.mg2,  ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.vg2,  ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.mbe2, ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.vbe2, ML_H2_DIM * sizeof(float));

    // Gradient accumulators
    cudaMalloc(&ctx->weights.gW1,  ML_H1_DIM * ML_IN_DIM  * sizeof(float));
    cudaMalloc(&ctx->weights.gb1,  ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.gg1,  ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.gbe1, ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.gW2,  ML_H2_DIM * ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.gb2,  ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.gg2,  ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.gbe2, ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.gW3,  ML_OUT_DIM * ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->weights.gb3,  ML_OUT_DIM * sizeof(float));

    // Zero all Adam moments
    cudaMemset(ctx->weights.mW1, 0, ML_H1_DIM * ML_IN_DIM * sizeof(float));
    cudaMemset(ctx->weights.vW1, 0, ML_H1_DIM * ML_IN_DIM * sizeof(float));
    cudaMemset(ctx->weights.mW2, 0, ML_H2_DIM * ML_H1_DIM * sizeof(float));
    cudaMemset(ctx->weights.vW2, 0, ML_H2_DIM * ML_H1_DIM * sizeof(float));
    cudaMemset(ctx->weights.mW3, 0, ML_OUT_DIM * ML_H2_DIM * sizeof(float));
    cudaMemset(ctx->weights.vW3, 0, ML_OUT_DIM * ML_H2_DIM * sizeof(float));
    cudaMemset(ctx->weights.mb1, 0, ML_H1_DIM * sizeof(float));
    cudaMemset(ctx->weights.vb1, 0, ML_H1_DIM * sizeof(float));
    cudaMemset(ctx->weights.mb2, 0, ML_H2_DIM * sizeof(float));
    cudaMemset(ctx->weights.vb2, 0, ML_H2_DIM * sizeof(float));
    cudaMemset(ctx->weights.mb3, 0, ML_OUT_DIM * sizeof(float));
    cudaMemset(ctx->weights.vb3, 0, ML_OUT_DIM * sizeof(float));
    cudaMemset(ctx->weights.mg1,  0, ML_H1_DIM * sizeof(float));
    cudaMemset(ctx->weights.vg1,  0, ML_H1_DIM * sizeof(float));
    cudaMemset(ctx->weights.mbe1, 0, ML_H1_DIM * sizeof(float));
    cudaMemset(ctx->weights.vbe1, 0, ML_H1_DIM * sizeof(float));
    cudaMemset(ctx->weights.mg2,  0, ML_H2_DIM * sizeof(float));
    cudaMemset(ctx->weights.vg2,  0, ML_H2_DIM * sizeof(float));
    cudaMemset(ctx->weights.mbe2, 0, ML_H2_DIM * sizeof(float));
    cudaMemset(ctx->weights.vbe2, 0, ML_H2_DIM * sizeof(float));

    // Scratch activations
    cudaMalloc(&ctx->d_h0,  ML_BATCH_SIZE * ML_IN_DIM  * sizeof(float));
    cudaMalloc(&ctx->d_h1,  ML_BATCH_SIZE * ML_H1_DIM  * sizeof(float));
    cudaMalloc(&ctx->d_h2,  ML_BATCH_SIZE * ML_H2_DIM  * sizeof(float));
    cudaMalloc(&ctx->d_out, ML_BATCH_SIZE * ML_OUT_DIM * sizeof(float));
    cudaMalloc(&ctx->d_dh2, ML_BATCH_SIZE * ML_H2_DIM  * sizeof(float));
    cudaMalloc(&ctx->d_dh1, ML_BATCH_SIZE * ML_H1_DIM  * sizeof(float));
    cudaMalloc(&ctx->d_dh0, ML_BATCH_SIZE * ML_IN_DIM  * sizeof(float));

    // BN backward caches (training mode only, but always allocated so
    // trainingMode can be toggled per-call without reallocating)
    cudaMalloc(&ctx->d_xhat1,   ML_BATCH_SIZE * ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->d_invStd1, ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->d_preAct1, ML_BATCH_SIZE * ML_H1_DIM * sizeof(float));
    cudaMalloc(&ctx->d_xhat2,   ML_BATCH_SIZE * ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->d_invStd2, ML_H2_DIM * sizeof(float));
    cudaMalloc(&ctx->d_preAct2, ML_BATCH_SIZE * ML_H2_DIM * sizeof(float));

    // Feature normalization
    cudaMalloc(&ctx->d_featMean,  ML_IN_DIM * sizeof(float));
    cudaMalloc(&ctx->d_featStd,   ML_IN_DIM * sizeof(float));
    cudaMalloc(&ctx->d_featCount, ML_IN_DIM * sizeof(float));
    cudaMemset(ctx->d_featMean,  0, ML_IN_DIM * sizeof(float));
    cudaMemset(ctx->d_featCount, 0, ML_IN_DIM * sizeof(float));
    // Initialize std to 1
    float ones[ML_IN_DIM];
    for (int i = 0; i < ML_IN_DIM; i++) ones[i] = 1.f;
    cudaMemcpy(ctx->d_featStd, ones, ML_IN_DIM * sizeof(float), cudaMemcpyHostToDevice);

    // cuBLAS handle
    cublasCreate(&ctx->cublas);

    ctx->weights.stepCount = 0;
    return VLYN_OK;
}

// =============================================================================
// Weight initialization — Xavier uniform for FC layers
// =============================================================================
VLYN_GLOBAL void kernelXavierInit(float* w, int fanIn, int fanOut, uint32_t seed) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int n = fanIn * fanOut;
    if (i >= n) return;

    uint32_t s = seed + (uint32_t)i * 2654435761u;
    float r = randFloat(s);
    float limit = sqrtf(6.f / (float)(fanIn + fanOut));
    w[i] = (r * 2.f - 1.f) * limit;
}

VLYN_GLOBAL void kernelBiasInit(float* b, int n, float val) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    b[i] = val;
}

VLynError mlInitWeights(MLContext* ctx) {
    auto launch = [](float* w, int fi, int fo, uint32_t seed) {
        int n = fi * fo;
        int blocks = (n + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
        kernelXavierInit<<<blocks, VLYN_BLOCK_SIZE>>>(w, fi, fo, seed);
    };

    launch(ctx->weights.W1, ML_IN_DIM,  ML_H1_DIM, 0x1a2b3c4d);
    launch(ctx->weights.W2, ML_H1_DIM,  ML_H2_DIM, 0x5e6f7a8b);
    launch(ctx->weights.W3, ML_H2_DIM,  ML_OUT_DIM, 0x9c0d1e2f);

    // Zero biases
    cudaMemset(ctx->weights.b1, 0, ML_H1_DIM  * sizeof(float));
    cudaMemset(ctx->weights.b2, 0, ML_H2_DIM  * sizeof(float));
    cudaMemset(ctx->weights.b3, 0, ML_OUT_DIM * sizeof(float));

    // Init BN: gamma=1, beta=0, running mean=0, running var=1
    int b1 = (ML_H1_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE;
    int b2 = (ML_H2_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE;
    kernelBiasInit<<<b1, VLYN_BLOCK_SIZE>>>(ctx->weights.g1,  ML_H1_DIM, 1.f);
    kernelBiasInit<<<b1, VLYN_BLOCK_SIZE>>>(ctx->weights.be1, ML_H1_DIM, 0.f);
    kernelBiasInit<<<b1, VLYN_BLOCK_SIZE>>>(ctx->weights.rm1, ML_H1_DIM, 0.f);
    kernelBiasInit<<<b1, VLYN_BLOCK_SIZE>>>(ctx->weights.rv1, ML_H1_DIM, 1.f);
    kernelBiasInit<<<b2, VLYN_BLOCK_SIZE>>>(ctx->weights.g2,  ML_H2_DIM, 1.f);
    kernelBiasInit<<<b2, VLYN_BLOCK_SIZE>>>(ctx->weights.be2, ML_H2_DIM, 0.f);
    kernelBiasInit<<<b2, VLYN_BLOCK_SIZE>>>(ctx->weights.rm2, ML_H2_DIM, 0.f);
    kernelBiasInit<<<b2, VLYN_BLOCK_SIZE>>>(ctx->weights.rv2, ML_H2_DIM, 1.f);

    return VLYN_OK;
}

// =============================================================================
// Feature extraction kernel
// For each cluster pair (A, B), build a 64-dim input vector:
//   [0..31]  = cluster A features  (from Cluster::features[])
//   [32..63] = cluster B features
// Additionally includes derived pair features in-place.
// =============================================================================
// DÜZELTME: bu kernel önceden önceden ayrı bir kernelTrianglePairsToClusterPairs
// tarafından üretilmiş, 16-bit paketlenmiş [clusterIdxA|clusterIdxB] formatında
// bir d_clusterPairs buffer'ı bekliyordu. O ara-adım kernel'i (ve onu besleyen
// d_clusterPairs GPU buffer'ı) pipeline'dan düşürülmüştü; kalan kod bunun
// yerine ham BVH üçgen-pair'lerini (uint64_t, [triIdxA|triIdxB]) doğrudan
// 32-bit cluster-pair olarak yanlış yorumluyordu — ML broad-phase ağı
// tamamen anlamsız/gürültülü feature'lar görüyordu.
//
// Düzeltme: ara adımı kaldırmak yerine, bu kernel'in kendisi artık orijinal
// üçgen-pair'i (d_trianglePairs, uint64_t: üst 32 bit=triIdxA, alt 32
// bit=triIdxB) alıyor ve her üçgenin zaten taşıdığı clusterId alanından
// (meshScan/k-means sırasında atanır) cluster'ı buluyor. Böylece pipeline
// boyunca pair formatı tek tip (uint64_t üçgen-pair) kalıyor ve ML broad-phase
// filtrelemesinin çıktısı narrow-phase'e ekstra bir çeviri katmanına gerek
// kalmadan doğrudan geçilebiliyor.
VLYN_GLOBAL void kernelExtractClusterFeatures(
    const Triangle* __restrict__ d_trisA,
    const Triangle* __restrict__ d_trisB,
    const Cluster* __restrict__ d_clustersA,
    const Cluster* __restrict__ d_clustersB,
    const uint64_t* __restrict__ d_trianglePairs,  // packed: [32:triIdxA | 32:triIdxB]
    int nPairs,
    float* __restrict__ d_features,         // [nPairs × ML_IN_DIM]
    const float* __restrict__ d_featMean,
    const float* __restrict__ d_featStd)
{
    int p = blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= nPairs) return;

    uint64_t packed = d_trianglePairs[p];
    uint32_t triA = (uint32_t)(packed >> 32);
    uint32_t triB = (uint32_t)(packed & 0xffffffff);

    uint32_t idxA = d_trisA[triA].clusterId;
    uint32_t idxB = d_trisB[triB].clusterId;

    const Cluster& cA = d_clustersA[idxA];
    const Cluster& cB = d_clustersB[idxB];

    float* feat = d_features + p * ML_IN_DIM;

    // Copy raw cluster features
    for (int i = 0; i < VLYN_ML_FEATURE_DIM; i++) {
        feat[i]                        = cA.features[i];
        feat[i + VLYN_ML_FEATURE_DIM] = cB.features[i];
    }

    // Inject pair-level features into first 12 slots
    // [0] distance between centroids
    Vec3 dc = cA.centroid - cB.centroid;
    feat[0] = dc.length();

    // [1] normal alignment (dot product)
    feat[1] = cA.avgNormal.dot(cB.avgNormal);

    // [2] AABB overlap volume
    AABB merged = AABB::merge(cA.bounds, cB.bounds);
    float ovX = fmaxf(0.f, fminf(cA.bounds.mx.x, cB.bounds.mx.x) -
                            fmaxf(cA.bounds.mn.x, cB.bounds.mn.x));
    float ovY = fmaxf(0.f, fminf(cA.bounds.mx.y, cB.bounds.mx.y) -
                            fmaxf(cA.bounds.mn.y, cB.bounds.mn.y));
    float ovZ = fmaxf(0.f, fminf(cA.bounds.mx.z, cB.bounds.mx.z) -
                            fmaxf(cA.bounds.mn.z, cB.bounds.mn.z));
    feat[2] = ovX * ovY * ovZ;

    // [3] size ratio
    float volA = cA.bounds.volume();
    float volB = cB.bounds.volume();
    feat[3] = (volA > 1e-10f) ? volB / volA : 0.f;

    // [4] area density ratio
    feat[4] = (cA.density > 1e-10f) ? cB.density / cA.density : 0.f;

    // [5] avg area product
    feat[5] = cA.avgArea * cB.avgArea;

    // [6..11] relative centroid direction
    Vec3 dir = (dc.length() > 1e-8f) ? dc.normalize() : Vec3(0,1,0);
    feat[6] = dir.x; feat[7] = dir.y; feat[8] = dir.z;
    feat[9]  = cA.triCount / (float)(cB.triCount + 1);
    feat[10] = cA.areaVariance;
    feat[11] = cB.areaVariance;

    // NOTE: Raw (unnormalized) features are written here intentionally.
    // Normalization is applied in a separate kernel (kernelNormalizeFeatures)
    // called AFTER Welford stats have been updated on the raw values.
    // Applying normalization here caused a double-normalization bug:
    //   1) features normalized here
    //   2) BatchNorm in mlForward normalized again → NaN / garbage scores
    // which caused mlInferAndFilter to pass 0 pairs → batch=0 →
    // mlForward returned VLYN_ERR_ML_INFERENCE (-9).
    (void)d_featMean; (void)d_featStd; // unused — normalization is now separate
}

// =============================================================================
// Feature normalization kernel: normalizes [nPairs × dim] feature buffer
// in-place using per-feature running mean and std.
// Called AFTER kernelExtractClusterFeatures (which now writes raw values)
// and AFTER kernelWelfordUpdateStats (which must run on raw values).
// Separating extraction, Welford update, and normalization into three steps
// fixes the double-normalization bug that produced NaN/garbage ML scores.
// =============================================================================
VLYN_GLOBAL void kernelNormalizeFeatures(
    float* __restrict__       d_features, // [nPairs × dim] in-place
    const float* __restrict__ d_featMean,
    const float* __restrict__ d_featStd,
    int nPairs, int dim)
{
    int p = blockIdx.x * blockDim.x + threadIdx.x;
    if (p >= nPairs) return;

    float* feat = d_features + p * dim;
    for (int i = 0; i < dim; i++) {
        float std = d_featStd[i];
        feat[i] = (feat[i] - d_featMean[i]) / (std > 1e-8f ? std : 1.f);
    }
}

// =============================================================================
// Batch Normalization (inference mode — uses running stats)
// =============================================================================
VLYN_GLOBAL void kernelBatchNormInfer(
    float* __restrict__       d_x,     // [batch × dim]  in-place
    const float* __restrict__ d_gamma,
    const float* __restrict__ d_beta,
    const float* __restrict__ d_runMean,
    const float* __restrict__ d_runVar,
    int batch, int dim, float eps)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;  // feature index
    int b = blockIdx.y;                                // batch index
    if (i >= dim || b >= batch) return;

    float xn = (d_x[b*dim + i] - d_runMean[i]) / sqrtf(d_runVar[i] + eps);
    d_x[b*dim + i] = d_gamma[i] * xn + d_beta[i];
}

// =============================================================================
// Batch Normalization (training mode — computes batch mean/var)
// =============================================================================
VLYN_GLOBAL void kernelBatchNormTrain(
    float* __restrict__       d_x,
    float* __restrict__       d_gamma,
    float* __restrict__       d_beta,
    float* __restrict__       d_runMean,
    float* __restrict__       d_runVar,
    float* __restrict__       d_xhat,   // normalized (for backward)
    float* __restrict__       d_invStd, // [dim] 1/sqrt(var+eps) this batch (for backward), may be null
    int batch, int dim, float eps, float momentum)
{
    VLYN_SHARED float smMean[ML_H1_DIM + 4];
    VLYN_SHARED float smVar[ML_H1_DIM + 4];

    int feat = blockIdx.x;
    if (feat >= dim) return;

    // Compute mean over batch
    float sum = 0.f;
    for (int b = threadIdx.x; b < batch; b += blockDim.x)
        sum += d_x[b*dim + feat];
    VLYN_WARP_REDUCE_SUM(sum);
    if (threadIdx.x % VLYN_WARP_SIZE == 0)
        smMean[threadIdx.x / VLYN_WARP_SIZE] = sum;
    __syncthreads();
    if (threadIdx.x == 0) {
        float total = 0.f;
        for (int w = 0; w < blockDim.x/VLYN_WARP_SIZE; w++) total += smMean[w];
        smMean[0] = total / (float)batch;
    }
    __syncthreads();
    float mean = smMean[0];

    // Compute variance
    float var = 0.f;
    for (int b = threadIdx.x; b < batch; b += blockDim.x) {
        float d = d_x[b*dim + feat] - mean;
        var += d*d;
    }
    VLYN_WARP_REDUCE_SUM(var);
    if (threadIdx.x % VLYN_WARP_SIZE == 0)
        smVar[threadIdx.x / VLYN_WARP_SIZE] = var;
    __syncthreads();
    if (threadIdx.x == 0) {
        float total = 0.f;
        for (int w = 0; w < blockDim.x/VLYN_WARP_SIZE; w++) total += smVar[w];
        smVar[0] = total / (float)batch;
        // Update running stats
        d_runMean[feat] = (1.f-momentum)*d_runMean[feat] + momentum*mean;
        d_runVar[feat]  = (1.f-momentum)*d_runVar[feat]  + momentum*smVar[0];
    }
    __syncthreads();
    float invStd = rsqrtf(smVar[0] + eps);
    if (threadIdx.x == 0 && d_invStd) d_invStd[feat] = invStd;

    // Normalize + scale + shift
    for (int b = threadIdx.x; b < batch; b += blockDim.x) {
        float xhat = (d_x[b*dim + feat] - mean) * invStd;
        if (d_xhat) d_xhat[b*dim + feat] = xhat;
        d_x[b*dim + feat] = d_gamma[feat] * xhat + d_beta[feat];
    }
}

// =============================================================================
// Leaky ReLU activation kernel (in-place)
// =============================================================================
VLYN_GLOBAL void kernelLeakyReLU(float* d_x, int n, float alpha) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    float v = d_x[i];
    d_x[i] = (v > 0.f) ? v : alpha * v;
}

// =============================================================================
// Sigmoid activation kernel (in-place)
// =============================================================================
VLYN_GLOBAL void kernelSigmoid(float* d_x, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    d_x[i] = 1.f / (1.f + expf(-d_x[i]));
}

// =============================================================================
// Add bias kernel: d_x[b*dim + i] += d_bias[i]
// =============================================================================
VLYN_GLOBAL void kernelAddBias(float* d_x, const float* d_bias, int batch, int dim) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int b = blockIdx.y;
    if (i >= dim || b >= batch) return;
    d_x[b*dim + i] += d_bias[i];
}

// =============================================================================
// Forward pass:
//   h1 = LeakyReLU(BN(W1 × h0 + b1))
//   h2 = LeakyReLU(BN(W2 × h1 + b2))
//   out = Sigmoid(W3 × h2 + b3)
// Uses cuBLAS SGEMM for matrix multiplications
// =============================================================================
VLynError mlForward(
    MLContext* ctx,
    const float* d_input,   // [batch × IN_DIM]
    float* d_output,        // [batch × OUT_DIM]
    int batch,
    cudaStream_t stream)
{
    if (batch <= 0 || batch > ctx->maxBatch) return VLYN_ERR_ML_INFERENCE;

    cublasSetStream(ctx->cublas, stream);

    const float alpha = 1.f, beta = 0.f;

    // Layer 1: h1 = W1 × h0^T  (cuBLAS operates column-major)
    // W1: [H1 × IN],  h0: [batch × IN] → h1: [batch × H1]
    // In column-major: h1^T = W1 × h0^T
    cublasSgemm(ctx->cublas, CUBLAS_OP_T, CUBLAS_OP_N,
                ML_H1_DIM, batch, ML_IN_DIM,
                &alpha,
                ctx->weights.W1, ML_IN_DIM,   // W1^T (row-major → col-major T)
                d_input,         ML_IN_DIM,
                &beta,
                ctx->d_h1,       ML_H1_DIM);

    // Add bias
    dim3 bBlock(VLYN_BLOCK_SIZE), bGrid((ML_H1_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
    kernelAddBias<<<bGrid, bBlock, 0, stream>>>(ctx->d_h1, ctx->weights.b1, batch, ML_H1_DIM);

    // BN + LeakyReLU
    if (ctx->trainingMode) {
        dim3 bnGrid(ML_H1_DIM), bnBlock(min(batch, VLYN_BLOCK_SIZE));
        kernelBatchNormTrain<<<bnGrid, bnBlock, 0, stream>>>(
            ctx->d_h1, ctx->weights.g1, ctx->weights.be1,
            ctx->weights.rm1, ctx->weights.rv1, ctx->d_xhat1, ctx->d_invStd1,
            batch, ML_H1_DIM, 1e-5f, 0.1f);
        cudaMemcpyAsync(ctx->d_preAct1, ctx->d_h1,
                         (size_t)batch * ML_H1_DIM * sizeof(float),
                         cudaMemcpyDeviceToDevice, stream);
    } else {
        dim3 bnGrid((ML_H1_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
        kernelBatchNormInfer<<<bnGrid, VLYN_BLOCK_SIZE, 0, stream>>>(
            ctx->d_h1, ctx->weights.g1, ctx->weights.be1,
            ctx->weights.rm1, ctx->weights.rv1,
            batch, ML_H1_DIM, 1e-5f);
    }
    int lrBlocks = (batch * ML_H1_DIM + VLYN_BLOCK_SIZE-1) / VLYN_BLOCK_SIZE;
    kernelLeakyReLU<<<lrBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_h1, batch * ML_H1_DIM, ML_LEAKY_ALPHA);

    // Layer 2: h2 = W2 × h1
    cublasSgemm(ctx->cublas, CUBLAS_OP_T, CUBLAS_OP_N,
                ML_H2_DIM, batch, ML_H1_DIM,
                &alpha,
                ctx->weights.W2, ML_H1_DIM,
                ctx->d_h1,       ML_H1_DIM,
                &beta,
                ctx->d_h2,       ML_H2_DIM);

    dim3 bGrid2((ML_H2_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
    kernelAddBias<<<bGrid2, bBlock, 0, stream>>>(ctx->d_h2, ctx->weights.b2, batch, ML_H2_DIM);

    if (ctx->trainingMode) {
        dim3 bnGrid2(ML_H2_DIM), bnBlock2(min(batch, VLYN_BLOCK_SIZE));
        kernelBatchNormTrain<<<bnGrid2, bnBlock2, 0, stream>>>(
            ctx->d_h2, ctx->weights.g2, ctx->weights.be2,
            ctx->weights.rm2, ctx->weights.rv2, ctx->d_xhat2, ctx->d_invStd2,
            batch, ML_H2_DIM, 1e-5f, 0.1f);
        cudaMemcpyAsync(ctx->d_preAct2, ctx->d_h2,
                         (size_t)batch * ML_H2_DIM * sizeof(float),
                         cudaMemcpyDeviceToDevice, stream);
    } else {
        dim3 bnGrid2((ML_H2_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
        kernelBatchNormInfer<<<bnGrid2, VLYN_BLOCK_SIZE, 0, stream>>>(
            ctx->d_h2, ctx->weights.g2, ctx->weights.be2,
            ctx->weights.rm2, ctx->weights.rv2,
            batch, ML_H2_DIM, 1e-5f);
    }
    int lrBlocks2 = (batch * ML_H2_DIM + VLYN_BLOCK_SIZE-1) / VLYN_BLOCK_SIZE;
    kernelLeakyReLU<<<lrBlocks2, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_h2, batch * ML_H2_DIM, ML_LEAKY_ALPHA);

    // Layer 3: out = W3 × h2 + b3
    cublasSgemm(ctx->cublas, CUBLAS_OP_T, CUBLAS_OP_N,
                ML_OUT_DIM, batch, ML_H2_DIM,
                &alpha,
                ctx->weights.W3, ML_H2_DIM,
                ctx->d_h2,       ML_H2_DIM,
                &beta,
                d_output,        ML_OUT_DIM);

    dim3 bGrid3((ML_OUT_DIM + VLYN_BLOCK_SIZE-1)/VLYN_BLOCK_SIZE, batch);
    kernelAddBias<<<bGrid3, bBlock, 0, stream>>>(d_output, ctx->weights.b3, batch, ML_OUT_DIM);

    // Sigmoid
    int sigBlocks = (batch * ML_OUT_DIM + VLYN_BLOCK_SIZE-1) / VLYN_BLOCK_SIZE;
    kernelSigmoid<<<sigBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(d_output, batch * ML_OUT_DIM);

    return VLYN_OK;
}

// =============================================================================
// Filter pairs by ML threshold
// Keep pairs where probability >= threshold
// =============================================================================
VLYN_GLOBAL void kernelFilterByMLScore(
    const uint64_t* __restrict__ d_pairs,
    const float*    __restrict__ d_scores,
    int nPairs,
    uint64_t* __restrict__ d_kept,
    uint32_t* __restrict__ d_keptCount,
    uint32_t maxKept,
    float threshold)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= nPairs) return;

    if (d_scores[i] >= threshold) {
        uint32_t slot = atomicAdd(d_keptCount, 1);
        if (slot < maxKept)
            d_kept[slot] = d_pairs[i];
    }
}

// =============================================================================
// Backward pass building blocks
// =============================================================================

// LeakyReLU backward: dIn = dOut * (preAct > 0 ? 1 : alpha)
// preAct is the value that went INTO the LeakyReLU (i.e. BN output), which we
// snapshotted into d_preAct1/d_preAct2 during the forward pass.
VLYN_GLOBAL void kernelLeakyReLUBackward(
    const float* __restrict__ d_dOut,
    const float* __restrict__ d_preAct,
    float* __restrict__       d_dIn,
    int n, float alpha)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    float g = d_dOut[i];
    d_dIn[i] = (d_preAct[i] > 0.f) ? g : alpha * g;
}

// Reduce a [batch x dim] gradient down to a [dim] bias gradient: db[j] = sum_b dOut[b,j]
VLYN_GLOBAL void kernelBiasGradReduce(
    const float* __restrict__ d_dOut,
    float* __restrict__       d_dBias,
    int batch, int dim)
{
    int feat = blockIdx.x * blockDim.x + threadIdx.x;
    if (feat >= dim) return;
    float s = 0.f;
    for (int b = 0; b < batch; ++b) s += d_dOut[b*dim + feat];
    d_dBias[feat] = s;
}

// Batch normalization backward pass.
// Forward:  xhat = (x - mean) * invStd ;  y = gamma*xhat + beta
// Standard batchnorm backward (Ioffe & Szegedy 2015), one block per feature:
//   dgamma[j] = sum_b dY[b,j] * xhat[b,j]
//   dbeta[j]  = sum_b dY[b,j]
//   dX[b,j]   = (gamma[j] * invStd[j] / batch) *
//               (batch*dY[b,j] - dbeta[j] - xhat[b,j]*dgamma[j])
VLYN_GLOBAL void kernelBatchNormBackward(
    const float* __restrict__ d_dY,      // [batch x dim] gradient w.r.t. BN output
    const float* __restrict__ d_xhat,    // [batch x dim] cached forward xhat
    const float* __restrict__ d_gamma,   // [dim]
    const float* __restrict__ d_invStd,  // [dim] cached forward invStd
    float* __restrict__       d_dX,      // [batch x dim] output: gradient w.r.t. BN input
    float* __restrict__       d_dGamma,  // [dim] output
    float* __restrict__       d_dBeta,   // [dim] output
    int batch, int dim)
{
    VLYN_SHARED float smDGamma[ML_H1_DIM + 4];
    VLYN_SHARED float smDBeta[ML_H1_DIM + 4];

    int feat = blockIdx.x;
    if (feat >= dim) return;

    float sumDGamma = 0.f, sumDBeta = 0.f;
    for (int b = threadIdx.x; b < batch; b += blockDim.x) {
        float dy = d_dY[b*dim + feat];
        float xh = d_xhat[b*dim + feat];
        sumDGamma += dy * xh;
        sumDBeta  += dy;
    }
    VLYN_WARP_REDUCE_SUM(sumDGamma);
    VLYN_WARP_REDUCE_SUM(sumDBeta);
    if (threadIdx.x % VLYN_WARP_SIZE == 0) {
        smDGamma[threadIdx.x / VLYN_WARP_SIZE] = sumDGamma;
        smDBeta[threadIdx.x / VLYN_WARP_SIZE]  = sumDBeta;
    }
    __syncthreads();
    if (threadIdx.x == 0) {
        float totalG = 0.f, totalB = 0.f;
        for (int w = 0; w < blockDim.x/VLYN_WARP_SIZE; w++) {
            totalG += smDGamma[w];
            totalB += smDBeta[w];
        }
        smDGamma[0] = totalG;
        smDBeta[0]  = totalB;
        d_dGamma[feat] = totalG;
        d_dBeta[feat]  = totalB;
    }
    __syncthreads();
    float dGamma = smDGamma[0];
    float dBeta  = smDBeta[0];
    float gamma  = d_gamma[feat];
    float invStd = d_invStd[feat];
    float invBatch = 1.f / (float)batch;

    for (int b = threadIdx.x; b < batch; b += blockDim.x) {
        float dy = d_dY[b*dim + feat];
        float xh = d_xhat[b*dim + feat];
        d_dX[b*dim + feat] = gamma * invStd * invBatch *
            ((float)batch * dy - dBeta - xh * dGamma);
    }
}

// =============================================================================
// Adam optimizer step — single weight matrix
// =============================================================================
VLYN_GLOBAL void kernelAdamStep(
    float* __restrict__ w,
    const float* __restrict__ grad,
    float* __restrict__ m,
    float* __restrict__ v,
    int n,
    float lr, float beta1, float beta2, float eps,
    float bc1, float bc2)  // bias correction factors
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    float g = grad[i];
    float mi = beta1 * m[i] + (1.f - beta1) * g;
    float vi = beta2 * v[i] + (1.f - beta2) * g * g;
    m[i] = mi;
    v[i] = vi;
    float mhat = mi / bc1;
    float vhat = vi / bc2;
    w[i] -= lr * mhat / (sqrtf(vhat) + eps);
}

// =============================================================================
// Binary cross-entropy loss + gradient (backward pass)
// Loss = -[y*log(p) + (1-y)*log(1-p)]
// dL/dp = (p - y) / (p*(1-p))
// Since last layer is sigmoid, dL/dz = p - y (simplified combined gradient)
// =============================================================================
VLYN_GLOBAL void kernelBCELoss(
    const float* __restrict__ d_pred,
    const float* __restrict__ d_label,
    float* __restrict__ d_dout,   // gradient
    float* __restrict__ d_loss,   // per-sample loss
    int n)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    float p = fmaxf(1e-7f, fminf(1.f-1e-7f, d_pred[i]));
    float y = d_label[i];
    d_loss[i] = -(y * logf(p) + (1.f-y) * logf(1.f-p));
    d_dout[i] = (p - y);  // dL/dz for sigmoid output
}

// =============================================================================
// Online training step — given confirmed collision ground truth labels
//
// Full backward pass through the 3-layer MLP:
//   out = Sigmoid(W3.h2 + b3)              <- combined BCE+sigmoid grad = (p-y)
//   h2  = LeakyReLU(BN2(W2.h1 + b2))
//   h1  = LeakyReLU(BN1(W1.h0 + b1))
// Gradients are computed layer-by-layer via cuBLAS SGEMM (for the weight
// gradients and for propagating gradients to the previous layer) chained
// with the custom LeakyReLU/BatchNorm backward kernels above, then applied
// with per-tensor Adam updates.
// =============================================================================
VLynError mlTrainStep(
    MLContext* ctx,
    const float* d_features,  // [batch × IN_DIM]
    const float* d_labels,    // [batch] — 1=collision, 0=no collision
    int batch,
    cudaStream_t stream)
{
    if (batch <= 0 || batch > ctx->maxBatch) return VLYN_ERR_ML_INFERENCE;

    ctx->trainingMode = true;
    cublasSetStream(ctx->cublas, stream);

    // ---- Forward pass (caches xhat/invStd/preAct for BN+LeakyReLU backward,
    //      and leaves ctx->d_h0 unused — we keep our own pointer to the
    //      caller's input buffer since d_features IS h0 here) ----
    VLynError fe = mlForward(ctx, d_features, ctx->d_out, batch, stream);
    if (fe != VLYN_OK) { ctx->trainingMode = false; return fe; }

    const float alpha = 1.f, beta = 0.f;

    // ---- Output layer gradient: combined BCE + sigmoid = (p - y) ----
    float* d_dout;   // [batch x OUT_DIM] == [batch] since OUT_DIM==1
    float* d_loss;
    cudaMallocAsync(&d_dout, (size_t)batch * ML_OUT_DIM * sizeof(float), stream);
    cudaMallocAsync(&d_loss, (size_t)batch * sizeof(float), stream);

    int blocks = (batch + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelBCELoss<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_out, d_labels, d_dout, d_loss, batch);

    // ---- Layer 3 gradients: dW3 = dout^T . h2, db3 = sum(dout) ----
    // W3 is stored [OUT_DIM x H2_DIM] row-major == [H2_DIM x OUT_DIM] col-major.
    // dW3 (col-major [H2_DIM x OUT_DIM]) = h2^T(col-major view) . dout
    //   h2:   [batch x H2_DIM] row-major == [H2_DIM x batch] col-major
    //   dout: [batch x OUT_DIM] row-major == [OUT_DIM x batch] col-major
    // dW3(col-major, H2_DIM x OUT_DIM) = h2(col-major, H2_DIM x batch) . dout^T(col-major, batch x OUT_DIM)
    cublasSgemm(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_T,
                ML_H2_DIM, ML_OUT_DIM, batch,
                &alpha,
                ctx->d_h2, ML_H2_DIM,
                d_dout,    ML_OUT_DIM,
                &beta,
                ctx->weights.gW3, ML_H2_DIM);

    int b3Blocks = (ML_OUT_DIM + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelBiasGradReduce<<<b3Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_dout, ctx->weights.gb3, batch, ML_OUT_DIM);

    // dh2 (post-LeakyReLU2 gradient) = dout . W3
    //   W3 col-major [H2_DIM x OUT_DIM]; dout col-major [OUT_DIM x batch]
    //   dh2 col-major [H2_DIM x batch] = W3(no-T) . dout(no-T)
    cublasSgemm(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_N,
                ML_H2_DIM, batch, ML_OUT_DIM,
                &alpha,
                ctx->weights.W3, ML_H2_DIM,
                d_dout,           ML_OUT_DIM,
                &beta,
                ctx->d_dh2,       ML_H2_DIM);

    // ---- LeakyReLU2 backward: dh2 *= (preAct2 > 0 ? 1 : alpha) ----
    int n2 = batch * ML_H2_DIM;
    int lr2Blocks = (n2 + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelLeakyReLUBackward<<<lr2Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_dh2, ctx->d_preAct2, ctx->d_dh2, n2, ML_LEAKY_ALPHA);

    // ---- BatchNorm2 backward: dh2 -> gradient w.r.t. (W2.h1 + b2), + dgamma2/dbeta2 ----
    dim3 bn2Grid(ML_H2_DIM), bn2Block(min(batch, VLYN_BLOCK_SIZE));
    kernelBatchNormBackward<<<bn2Grid, bn2Block, 0, stream>>>(
        ctx->d_dh2, ctx->d_xhat2, ctx->weights.g2, ctx->d_invStd2,
        ctx->d_dh2, ctx->weights.gg2, ctx->weights.gbe2,
        batch, ML_H2_DIM);

    // ---- Layer 2 gradients: dW2 = dh2^T . h1, db2 = sum(dh2) ----
    cublasSgemm(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_T,
                ML_H1_DIM, ML_H2_DIM, batch,
                &alpha,
                ctx->d_h1, ML_H1_DIM,
                ctx->d_dh2, ML_H2_DIM,
                &beta,
                ctx->weights.gW2, ML_H1_DIM);

    int b2Blocks = (ML_H2_DIM + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelBiasGradReduce<<<b2Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_dh2, ctx->weights.gb2, batch, ML_H2_DIM);

    // dh1 (post-LeakyReLU1 gradient) = dh2 . W2
    cublasSgemm(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_N,
                ML_H1_DIM, batch, ML_H2_DIM,
                &alpha,
                ctx->weights.W2, ML_H1_DIM,
                ctx->d_dh2,       ML_H2_DIM,
                &beta,
                ctx->d_dh1,       ML_H1_DIM);

    // ---- LeakyReLU1 backward ----
    int n1 = batch * ML_H1_DIM;
    int lr1Blocks = (n1 + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelLeakyReLUBackward<<<lr1Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_dh1, ctx->d_preAct1, ctx->d_dh1, n1, ML_LEAKY_ALPHA);

    // ---- BatchNorm1 backward ----
    dim3 bn1Grid(ML_H1_DIM), bn1Block(min(batch, VLYN_BLOCK_SIZE));
    kernelBatchNormBackward<<<bn1Grid, bn1Block, 0, stream>>>(
        ctx->d_dh1, ctx->d_xhat1, ctx->weights.g1, ctx->d_invStd1,
        ctx->d_dh1, ctx->weights.gg1, ctx->weights.gbe1,
        batch, ML_H1_DIM);

    // ---- Layer 1 gradients: dW1 = dh1^T . h0, db1 = sum(dh1) ----
    // (dh0, the gradient w.r.t. the input features, is not needed further —
    //  features are geometric measurements, not learnable — so we skip
    //  computing it and save one SGEMM.)
    cublasSgemm(ctx->cublas, CUBLAS_OP_N, CUBLAS_OP_T,
                ML_IN_DIM, ML_H1_DIM, batch,
                &alpha,
                d_features, ML_IN_DIM,
                ctx->d_dh1, ML_H1_DIM,
                &beta,
                ctx->weights.gW1, ML_IN_DIM);

    int b1Blocks = (ML_H1_DIM + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    kernelBiasGradReduce<<<b1Blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        ctx->d_dh1, ctx->weights.gb1, batch, ML_H1_DIM);

    // ---- Adam updates for every learnable tensor ----
    ctx->weights.stepCount++;
    float t   = (float)ctx->weights.stepCount;
    float bc1 = 1.f - powf(ML_BETA1, t);
    float bc2 = 1.f - powf(ML_BETA2, t);

    auto adamUpdate = [&](float* w, float* g, float* m, float* v, int n) {
        int blk = (n + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
        kernelAdamStep<<<blk, VLYN_BLOCK_SIZE, 0, stream>>>(
            w, g, m, v, n, ML_LR, ML_BETA1, ML_BETA2, ML_EPSILON, bc1, bc2);
    };

    adamUpdate(ctx->weights.W1, ctx->weights.gW1, ctx->weights.mW1, ctx->weights.vW1, ML_H1_DIM * ML_IN_DIM);
    adamUpdate(ctx->weights.b1, ctx->weights.gb1, ctx->weights.mb1, ctx->weights.vb1, ML_H1_DIM);
    adamUpdate(ctx->weights.g1, ctx->weights.gg1, ctx->weights.mg1, ctx->weights.vg1, ML_H1_DIM);
    adamUpdate(ctx->weights.be1, ctx->weights.gbe1, ctx->weights.mbe1, ctx->weights.vbe1, ML_H1_DIM);

    adamUpdate(ctx->weights.W2, ctx->weights.gW2, ctx->weights.mW2, ctx->weights.vW2, ML_H2_DIM * ML_H1_DIM);
    adamUpdate(ctx->weights.b2, ctx->weights.gb2, ctx->weights.mb2, ctx->weights.vb2, ML_H2_DIM);
    adamUpdate(ctx->weights.g2, ctx->weights.gg2, ctx->weights.mg2, ctx->weights.vg2, ML_H2_DIM);
    adamUpdate(ctx->weights.be2, ctx->weights.gbe2, ctx->weights.mbe2, ctx->weights.vbe2, ML_H2_DIM);

    adamUpdate(ctx->weights.W3, ctx->weights.gW3, ctx->weights.mW3, ctx->weights.vW3, ML_OUT_DIM * ML_H2_DIM);
    adamUpdate(ctx->weights.b3, ctx->weights.gb3, ctx->weights.mb3, ctx->weights.vb3, ML_OUT_DIM);

    ctx->trainingMode = false;
    cudaFreeAsync(d_dout, stream);
    cudaFreeAsync(d_loss, stream);
    return VLYN_OK;
}

// =============================================================================
// Cluster feature builder — populates Cluster::features[]
// Called by VLyn_mesh.cu after k-means assignment
// =============================================================================
VLYN_GLOBAL void kernelBuildClusterFeatures(
    Cluster* __restrict__ d_clusters,
    int nClusters)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= nClusters) return;

    Cluster& c = d_clusters[i];
    float* f   = c.features;

    // Geometric features [0..11]
    f[0]  = c.centroid.x;
    f[1]  = c.centroid.y;
    f[2]  = c.centroid.z;
    f[3]  = c.bounds.extent().x;
    f[4]  = c.bounds.extent().y;
    f[5]  = c.bounds.extent().z;
    f[6]  = c.avgNormal.x;
    f[7]  = c.avgNormal.y;
    f[8]  = c.avgNormal.z;
    f[9]  = c.avgArea;
    f[10] = c.areaVariance;
    f[11] = c.normalVariance;

    // Cluster statistics [12..19]
    f[12] = (float)c.triCount;
    f[13] = c.density;
    f[14] = c.bounds.surface();
    f[15] = c.bounds.volume();
    f[16] = (c.bounds.volume() > 1e-10f) ? c.triCount / c.bounds.volume() : 0.f;
    f[17] = sqrtf(c.areaVariance);
    f[18] = sqrtf(c.normalVariance);
    f[19] = c.avgArea * (float)c.triCount;

    // Derived shape descriptors [20..31]
    Vec3 ext = c.bounds.extent();
    float maxExt = fmaxf(fmaxf(ext.x, ext.y), ext.z);
    float minExt = fminf(fminf(ext.x, ext.y), ext.z);
    f[20] = (maxExt > 1e-10f) ? minExt / maxExt : 1.f; // aspect ratio
    f[21] = (c.bounds.surface() > 1e-10f) ? c.bounds.volume() / c.bounds.surface() : 0.f;
    f[22] = c.avgNormal.dot(Vec3(0,1,0));  // upward alignment
    f[23] = c.avgNormal.dot(Vec3(1,0,0));  // forward alignment
    f[24] = sqrtf(c.centroid.x*c.centroid.x + c.centroid.z*c.centroid.z); // xz radius
    f[25] = fabsf(c.centroid.y);            // height
    f[26] = (ext.x * ext.y > 1e-10f) ? ext.z / sqrtf(ext.x * ext.y) : 0.f;
    f[27] = logf(1.f + (float)c.triCount);
    f[28] = logf(1.f + c.avgArea);
    f[29] = logf(1.f + c.bounds.volume());
    f[30] = 0.f;  // reserved for velocity feature (dynamic simulation)
    f[31] = 0.f;  // reserved for material index
}

// =============================================================================
// Inference entry point: given ORIGINAL triangle pairs (from BVH broad
// phase), look up each triangle's cluster and filter by ML score. Input and
// output pair format is uint64_t triangle-pairs ([32:triIdxA|32:triIdxB])
// throughout — no separate cluster-pair buffer or encoding is needed; the
// cluster lookup happens inside kernelExtractClusterFeatures via each
// triangle's clusterId field (set during meshScan's k-means pass).
// =============================================================================
VLynError mlInferAndFilter(
    MLContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const Cluster* d_clustersA,
    const Cluster* d_clustersB,
    const uint64_t* d_trianglePairs,
    int nPairs,
    uint64_t* d_filteredPairs,
    uint32_t* d_filteredCount,
    uint32_t maxFiltered,
    cudaStream_t stream)
{
    if (nPairs == 0) return VLYN_OK;
    // NOTE: caller (CVSQuery) is responsible for zeroing d_filteredCount
    // before this call. We do not zero it here to avoid the double-reset
    // that was occurring when CVSQuery's cudaMemsetAsync ran right before.

    int processed = 0;
    while (processed < nPairs) {
        int batch = min(ML_BATCH_SIZE, nPairs - processed);

        // Extract raw features (no normalization inside this kernel any more)
        int blocks = (batch + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
        kernelExtractClusterFeatures<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_trisA, d_trisB,
            d_clustersA, d_clustersB,
            d_trianglePairs + processed,
            batch,
            ctx->d_h0,
            ctx->d_featMean,   // unused inside kernel now, kept for signature compat
            ctx->d_featStd);   // unused inside kernel now

        // Normalize features using running stats (separate step to avoid
        // double-normalization: extraction writes raw, this applies mean/std,
        // then mlForward applies BatchNorm — each stage runs exactly once)
        kernelNormalizeFeatures<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            ctx->d_h0, ctx->d_featMean, ctx->d_featStd,
            batch, ML_IN_DIM);

        // Forward pass
        mlForward(ctx, ctx->d_h0, ctx->d_out, batch, stream);

        // Filter by threshold
        kernelFilterByMLScore<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_trianglePairs + processed,
            ctx->d_out,
            batch,
            d_filteredPairs,
            d_filteredCount,
            maxFiltered,
            ctx->threshold);

        processed += batch;
    }
    return VLYN_OK;
}

// Defined in VLyn_voronoi.cu — runs GJK/EPA on a pair list, writes dense
// [nPairs x 5] labels in the same order as d_pairs.
extern VLynError voronoiComputeTrainLabels(
    const uint64_t* d_pairs, uint32_t nPairs,
    const Triangle* d_trisA, const Triangle* d_trisB,
    float* d_labels, int gjkIter, int epaIter, cudaStream_t stream);

// =============================================================================
// Online Welford update: per-feature running mean and std from a batch of
// extracted features [batch x dim]. Updates d_mean, d_std, d_count in-place.
// Called once per warm-up training batch so that feature normalization inside
// kernelNormalizeFeatures uses real calibrated statistics instead of the
// placeholder mean=0, std=1 that causes un-normalized inputs and unstable
// training (cluster centroid distances, overlap volumes, and normal dot
// products all live on very different scales).
// IMPORTANT: this kernel must be called on RAW (unnormalized) features —
// i.e. BEFORE kernelNormalizeFeatures — so the statistics reflect true
// geometric distributions, not already-normalized values.
// =============================================================================
VLYN_GLOBAL void kernelWelfordUpdateStats(
    const float* __restrict__ d_features,
    float* __restrict__       d_mean,
    float* __restrict__       d_std,
    float* __restrict__       d_count,
    int batch, int dim)
{
    int feat = blockIdx.x;
    if (feat >= dim) return;

    VLYN_SHARED float smMean[VLYN_BLOCK_SIZE];
    VLYN_SHARED float smM2[VLYN_BLOCK_SIZE];
    VLYN_SHARED float smCnt[VLYN_BLOCK_SIZE];

    float localMean = 0.f, localM2 = 0.f;
    int   localCnt  = 0;

    for (int b = threadIdx.x; b < batch; b += blockDim.x) {
        float x = d_features[b * dim + feat];
        localCnt++;
        float delta = x - localMean;
        localMean  += delta / (float)localCnt;
        localM2    += delta * (x - localMean);
    }

    smMean[threadIdx.x] = localMean;
    smM2[threadIdx.x]   = localM2;
    smCnt[threadIdx.x]  = (float)localCnt;
    __syncthreads();

    // Parallel merge (Chan et al.)
    for (int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (threadIdx.x < s) {
            float nA = smCnt[threadIdx.x], nB = smCnt[threadIdx.x + s];
            float mA = smMean[threadIdx.x], mB = smMean[threadIdx.x + s];
            float m2A = smM2[threadIdx.x],  m2B = smM2[threadIdx.x + s];
            float nAB = nA + nB;
            if (nAB > 0.f) {
                float delta = mB - mA;
                smMean[threadIdx.x] = (nA * mA + nB * mB) / nAB;
                smM2[threadIdx.x]   = m2A + m2B + delta * delta * nA * nB / nAB;
            }
            smCnt[threadIdx.x] = nAB;
        }
        __syncthreads();
    }

    if (threadIdx.x == 0) {
        float prevCount = d_count[feat];
        float prevMean  = d_mean[feat];
        float prevStd   = d_std[feat];
        float prevM2    = prevStd * prevStd * prevCount;

        float batchCount = smCnt[0];
        float batchMean  = smMean[0];
        float batchM2    = smM2[0];
        float newCount   = prevCount + batchCount;
        float delta      = batchMean - prevMean;
        float newMean    = (newCount > 0.f)
                         ? (prevCount * prevMean + batchCount * batchMean) / newCount
                         : 0.f;
        float newM2      = prevM2 + batchM2
                         + delta * delta * prevCount * batchCount / fmaxf(newCount, 1.f);

        d_count[feat] = newCount;
        d_mean[feat]  = newMean;
        d_std[feat]   = (newCount > 1.f) ? sqrtf(newM2 / newCount) : 1.f;
    }
}

// =============================================================================
// Reduce [nPairs x 5] narrow-phase labels (col 0 = collision prob) to
// [nPairs x 1] binary labels for the broad-phase binary classifier.
// =============================================================================
VLYN_GLOBAL void kernelReduceNarrowLabelsToBroad(
    const float* __restrict__ d_narrowLabels,
    float* __restrict__       d_broadLabels,
    int nPairs)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= nPairs) return;
    d_broadLabels[i] = d_narrowLabels[i * 5];
}

// =============================================================================
// Broad-phase warm-up training: given the raw BVH pair list (d_bvhPairs),
// compute exact Voronoi/GJK-EPA ground truth, reduce to binary broad-phase
// labels, and take one mlTrainStep so the broad-phase network learns what
// real collisions look like before it is asked to filter anything.
//
// This is called during the warm-up phase (warmupComplete == false) in
// CVSQuery, before the ML networks are used for any inference.
// =============================================================================
VLynError mlTrainOnFallbackBroad(
    MLContext* ctx,
    const Triangle* d_trisA,
    const Triangle* d_trisB,
    const Cluster* d_clustersA,
    const Cluster* d_clustersB,
    const uint64_t* d_bvhPairs,
    int nPairs,
    int gjkIter, int epaIter,
    cudaStream_t stream)
{
    if (nPairs == 0) return VLYN_OK;

    float* d_narrowLabels = nullptr;
    float* d_broadLabels  = nullptr;
    cudaMallocAsync(&d_narrowLabels, (size_t)min(nPairs, (int)ML_BATCH_SIZE) * 5 * sizeof(float), stream);
    cudaMallocAsync(&d_broadLabels,  (size_t)min(nPairs, (int)ML_BATCH_SIZE)     * sizeof(float), stream);
    if (!d_narrowLabels || !d_broadLabels) {
        cudaFreeAsync(d_narrowLabels, stream);
        cudaFreeAsync(d_broadLabels, stream);
        return VLYN_ERR_OOM;
    }

    int processed = 0;
    VLynError result = VLYN_OK;
    while (processed < nPairs) {
        int batch  = min((int)ML_BATCH_SIZE, nPairs - processed);
        int blocks = (batch + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;

        // Exact ground truth for this chunk
        VLynError le = voronoiComputeTrainLabels(
            d_bvhPairs + processed, (uint32_t)batch,
            d_trisA, d_trisB,
            d_narrowLabels, gjkIter, epaIter, stream);
        if (le != VLYN_OK) { result = le; break; }

        // Reduce [batch x 5] → [batch x 1] binary labels for broad-phase
        kernelReduceNarrowLabelsToBroad<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_narrowLabels, d_broadLabels, batch);

        // Step 1: Extract RAW (unnormalized) cluster features into ctx->d_h0.
        // kernelExtractClusterFeatures no longer normalizes internally —
        // Welford must see raw values to compute correct per-feature statistics.
        kernelExtractClusterFeatures<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_trisA, d_trisB,
            d_clustersA, d_clustersB,
            d_bvhPairs + processed,
            batch,
            ctx->d_h0,
            ctx->d_featMean,   // unused inside kernel (kept for signature compat)
            ctx->d_featStd);   // unused inside kernel (kept for signature compat)

        // Step 2: Update running mean/std from the RAW feature batch.
        // This MUST happen before normalization so the statistics are built
        // from true geometric values, not already-normalized ones.
        // One block per feature dimension.
        kernelWelfordUpdateStats<<<ML_IN_DIM, VLYN_BLOCK_SIZE, 0, stream>>>(
            ctx->d_h0, ctx->d_featMean, ctx->d_featStd, ctx->d_featCount,
            batch, ML_IN_DIM);

        // Step 3: Normalize ctx->d_h0 in-place using the just-updated stats.
        // mlTrainStep → mlForward will then apply BatchNorm on top of these
        // normalized values — each normalization stage runs exactly once.
        kernelNormalizeFeatures<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            ctx->d_h0, ctx->d_featMean, ctx->d_featStd,
            batch, ML_IN_DIM);

        // Step 4: One Adam step — normalized features in ctx->d_h0, labels in d_broadLabels
        VLynError te = mlTrainStep(ctx, ctx->d_h0, d_broadLabels, batch, stream);
        if (te != VLYN_OK) { result = te; break; }

        processed += batch;
    }

    cudaFreeAsync(d_narrowLabels, stream);
    cudaFreeAsync(d_broadLabels,  stream);
    return result;
}

// =============================================================================
// Free ML context resources
// =============================================================================
VLynError mlFreeContext(MLContext* ctx) {
    cudaFree(ctx->weights.W1); cudaFree(ctx->weights.b1);
    cudaFree(ctx->weights.g1); cudaFree(ctx->weights.be1);
    cudaFree(ctx->weights.rm1); cudaFree(ctx->weights.rv1);
    cudaFree(ctx->weights.W2); cudaFree(ctx->weights.b2);
    cudaFree(ctx->weights.g2); cudaFree(ctx->weights.be2);
    cudaFree(ctx->weights.rm2); cudaFree(ctx->weights.rv2);
    cudaFree(ctx->weights.W3); cudaFree(ctx->weights.b3);

    cudaFree(ctx->weights.mW1); cudaFree(ctx->weights.vW1);
    cudaFree(ctx->weights.mb1); cudaFree(ctx->weights.vb1);
    cudaFree(ctx->weights.mW2); cudaFree(ctx->weights.vW2);
    cudaFree(ctx->weights.mb2); cudaFree(ctx->weights.vb2);
    cudaFree(ctx->weights.mW3); cudaFree(ctx->weights.vW3);
    cudaFree(ctx->weights.mb3); cudaFree(ctx->weights.vb3);

    cudaFree(ctx->weights.mg1); cudaFree(ctx->weights.vg1);
    cudaFree(ctx->weights.mbe1); cudaFree(ctx->weights.vbe1);
    cudaFree(ctx->weights.mg2); cudaFree(ctx->weights.vg2);
    cudaFree(ctx->weights.mbe2); cudaFree(ctx->weights.vbe2);

    cudaFree(ctx->weights.gW1); cudaFree(ctx->weights.gb1);
    cudaFree(ctx->weights.gg1); cudaFree(ctx->weights.gbe1);
    cudaFree(ctx->weights.gW2); cudaFree(ctx->weights.gb2);
    cudaFree(ctx->weights.gg2); cudaFree(ctx->weights.gbe2);
    cudaFree(ctx->weights.gW3); cudaFree(ctx->weights.gb3);

    cudaFree(ctx->d_h0); cudaFree(ctx->d_h1); cudaFree(ctx->d_h2);
    cudaFree(ctx->d_out); cudaFree(ctx->d_dh0);
    cudaFree(ctx->d_dh1); cudaFree(ctx->d_dh2);
    cudaFree(ctx->d_xhat1); cudaFree(ctx->d_invStd1); cudaFree(ctx->d_preAct1);
    cudaFree(ctx->d_xhat2); cudaFree(ctx->d_invStd2); cudaFree(ctx->d_preAct2);
    cudaFree(ctx->d_featMean); cudaFree(ctx->d_featStd); cudaFree(ctx->d_featCount);

    cublasDestroy(ctx->cublas);
    return VLYN_OK;
}

// =============================================================================
// End of VLyn_ml.cu
// =============================================================================
