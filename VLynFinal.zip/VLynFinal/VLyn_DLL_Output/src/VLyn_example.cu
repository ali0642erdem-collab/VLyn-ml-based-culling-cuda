// =============================================================================
// VLyn_example.cu — Minimal smoke test / usage example
// Creates two overlapping tetrahedra, runs collision detection, prints results.
// =============================================================================
#include "VLyn.h"
#include <cstdio>
#include <cmath>

int main() {
    printf("VLyn %s — smoke test\n", CVSVersion());

    VLynConfig cfg = VLynDefaultConfigC();
    cfg.enableProfiling = true;
    cfg.enableML        = false;   // skip ML in smoke test (no trained weights)
    cfg.enableVoronoi   = true;
    cfg.numStreams       = 2;

    CVSHandle h = CVSCrt(&cfg);
    if (!h) { fprintf(stderr, "CVSCrt failed\n"); return 1; }

    // -----------------------------------------------------------------------
    // Mesh A — regular tetrahedron centered at origin, radius 1
    // -----------------------------------------------------------------------
    VLynVec3 vertsA[] = {
        { 0.f,   1.f,   0.f,  0.f },
        { 0.943f,-0.333f, 0.f, 0.f },
        {-0.471f,-0.333f, 0.816f, 0.f },
        {-0.471f,-0.333f,-0.816f, 0.f },
    };
    uint32_t idxA[] = {
        0,1,2,  0,2,3,  0,3,1,  1,3,2
    };

    int mA = CVSAddMesh(h, vertsA, idxA, 4);
    if (mA < 0) { fprintf(stderr, "AddMesh A failed: %d\n", mA); return 1; }
    printf("Mesh A registered: id=%d\n", mA);

    // -----------------------------------------------------------------------
    // Mesh B — same tetrahedron translated by (0.5, 0, 0) — overlapping
    // -----------------------------------------------------------------------
    VLynVec3 vertsB[] = {
        { 0.5f,   1.f,   0.f,  0.f },
        { 1.443f,-0.333f, 0.f, 0.f },
        { 0.029f,-0.333f, 0.816f, 0.f },
        { 0.029f,-0.333f,-0.816f, 0.f },
    };
    uint32_t idxB[] = {
        0,1,2,  0,2,3,  0,3,1,  1,3,2
    };

    int mB = CVSAddMesh(h, vertsB, idxB, 4);
    if (mB < 0) { fprintf(stderr, "AddMesh B failed: %d\n", mB); return 1; }
    printf("Mesh B registered: id=%d\n", mB);

    // -----------------------------------------------------------------------
    // Query
    // -----------------------------------------------------------------------
    VLynCollisionResult results[256];
    uint32_t cnt = 0;

    VLynError e = CVSQuery(h, mA, mB, results, &cnt, 256);
    if (e != VLYN_OK) {
        fprintf(stderr, "CVSQuery error: %d\n", (int)e);
    } else {
        printf("CVSQuery returned %u contact(s)\n", cnt);
        for (uint32_t i = 0; i < cnt; ++i) {
            const VLynCollisionResult& r = results[i];
            printf("  [%u] meshA=%u meshB=%u contacts=%u closestDist=%.4f flags=0x%x\n",
                   i, r.meshIdA, r.meshIdB, r.contactCount,
                   r.closestDist, r.flags);
            for (uint32_t c = 0; c < r.contactCount; ++c) {
                const VLynContactPoint& cp = r.contacts[c];
                printf("    contact[%u] pos=(%.3f,%.3f,%.3f) normal=(%.3f,%.3f,%.3f)"
                       " depth=%.4f conf=%.2f\n",
                       c,
                       cp.position.x, cp.position.y, cp.position.z,
                       cp.normal.x,   cp.normal.y,   cp.normal.z,
                       cp.penetrationDepth, cp.confidence);
            }
        }
    }

    // Stats
    VLynStats stats;
    CVSGetStats(h, &stats);
    printf("Stats: candidatePairs=%llu mlRejected=%llu narrowPhase=%llu contacts=%llu totalMs=%.2f\n",
           (unsigned long long)stats.candidatePairs,
           (unsigned long long)stats.mlRejected,
           (unsigned long long)stats.narrowPhasePairs,
           (unsigned long long)stats.contactsFound,
           stats.totalMs);

    CVSDestroy(h);
    printf("Done.\n");
    return 0;
}
