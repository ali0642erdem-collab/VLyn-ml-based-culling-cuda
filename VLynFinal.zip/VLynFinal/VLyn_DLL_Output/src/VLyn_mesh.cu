// =============================================================================
// VLyn_mesh.cu  —  Mesh Scanner, Validator & GPU K-Means Clusterer
//
// Responsibilities:
//   1. Mesh validation (degenerate triangle removal, winding fix)
//   2. Normal & centroid computation
//   3. GPU-parallel k-means clustering (for ML feature extraction)
//   4. Streaming tile processor (handles meshes larger than GPU VRAM)
//   5. Mesh statistics & profiling
// =============================================================================
#include "VLyn_types.cuh"
#include <cuda_runtime.h>
#include <cub/cub.cuh>
#include <cstdio>
#include <cstring>
#include <cmath>

// =============================================================================
// Internal constants
// =============================================================================
#define KMEANS_MAX_ITER          64
#define KMEANS_CONVERGENCE_EPS   1e-5f
#define TILE_OVERLAP_FACTOR      1.05f  // expand tile AABB slightly
#define WINDING_AREA_EPS         1e-8f

// =============================================================================
// Kernel: Compute triangle derived data (normal, centroid, area)
// One thread per triangle — fully parallelized
// =============================================================================
VLYN_GLOBAL void kernelComputeTriDerived(
    Triangle* __restrict__ d_tris,
    uint32_t meshId,
    int n)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    Triangle& t = d_tris[i];
    t.meshId = meshId;
    t.triId  = (uint32_t)i;
    t.computeDerived();
}

// =============================================================================
// Kernel: Validate and repair triangles
//   - Remove degenerate (zero-area) triangles by flagging
//   - Ensure consistent winding order (flip if needed)
// =============================================================================
VLYN_GLOBAL void kernelValidateTris(
    Triangle* __restrict__ d_tris,
    uint8_t* __restrict__  d_valid,   // 1 = valid, 0 = degenerate
    int n,
    float areaThreshold)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    Triangle& t = d_tris[i];
    d_valid[i] = (t.area > areaThreshold) ? 1 : 0;

    // Ensure outward normal (simple heuristic: assume CCW winding from outside)
    // If area is near-zero, mark degenerate
    if (t.area < WINDING_AREA_EPS) {
        d_valid[i] = 0;
    }
}

// =============================================================================
// Kernel: Compact valid triangles (stream-compaction)
// Uses prefix sum result to write to output array
// =============================================================================
VLYN_GLOBAL void kernelCompactTris(
    const Triangle* __restrict__ d_src,
    const uint8_t* __restrict__  d_valid,
    const int* __restrict__      d_prefix,  // exclusive prefix sum of d_valid
    Triangle* __restrict__       d_dst,
    int n)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    if (d_valid[i]) {
        d_dst[d_prefix[i]] = d_src[i];
        d_dst[d_prefix[i]].triId = (uint32_t)d_prefix[i];
    }
}

// =============================================================================
// Kernel: K-means initialization — k-means++ seeding
// Select first centroid at random, then each subsequent centroid is
// chosen with probability proportional to squared distance to nearest centroid
// =============================================================================
VLYN_GLOBAL void kernelKmeansDistance(
    const Triangle* __restrict__ d_tris,
    const Vec3* __restrict__     d_centroids,
    float* __restrict__          d_dist2,     // output: squared dist to nearest
    int n, int k)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    Vec3 tc = d_tris[i].centroid;
    float minD2 = FLT_MAX;

    for (int j = 0; j < k; j++) {
        Vec3 d = tc - d_centroids[j];
        float d2 = d.lengthSq();
        if (d2 < minD2) minD2 = d2;
    }
    d_dist2[i] = minD2;
}

// =============================================================================
// Kernel: K-means assignment — assign each triangle to nearest centroid
// =============================================================================
VLYN_GLOBAL void kernelKmeansAssign(
    const Triangle* __restrict__ d_tris,
    const Vec3* __restrict__     d_centroids,
    uint32_t* __restrict__       d_assign,
    float* __restrict__          d_minDist2,
    int n, int k)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    Vec3 tc = d_tris[i].centroid;
    float minD2 = FLT_MAX;
    uint32_t best = 0;

    // Unrolled for typical small k
    for (int j = 0; j < k; j++) {
        Vec3 d = tc - d_centroids[j];
        float d2 = d.lengthSq();
        if (d2 < minD2) { minD2 = d2; best = (uint32_t)j; }
    }
    d_assign[i]   = best;
    d_minDist2[i] = minD2;
}

// =============================================================================
// Kernel: K-means update — accumulate new centroid positions
// Uses shared memory for partial sums, then atomic global update
// =============================================================================
VLYN_GLOBAL void kernelKmeansUpdate(
    const Triangle* __restrict__ d_tris,
    const uint32_t* __restrict__ d_assign,
    float* __restrict__          d_newCX,   // [k] — centroid X sum
    float* __restrict__          d_newCY,
    float* __restrict__          d_newCZ,
    uint32_t* __restrict__       d_count,   // [k] — count per cluster
    int n, int k)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    uint32_t c = d_assign[i];
    Vec3 tc = d_tris[i].centroid;

    atomicAdd(&d_newCX[c], tc.x);
    atomicAdd(&d_newCY[c], tc.y);
    atomicAdd(&d_newCZ[c], tc.z);
    atomicAdd(&d_count[c], 1u);
}

// =============================================================================
// Kernel: Finalize centroids — divide sum by count
// =============================================================================
VLYN_GLOBAL void kernelKmeansFinalize(
    Vec3* __restrict__           d_centroids,
    const float* __restrict__    d_newCX,
    const float* __restrict__    d_newCY,
    const float* __restrict__    d_newCZ,
    const uint32_t* __restrict__ d_count,
    float* __restrict__          d_drift,   // output: sum of centroid movement
    int k)
{
    int j = blockIdx.x * blockDim.x + threadIdx.x;
    if (j >= k) return;

    uint32_t cnt = d_count[j];
    if (cnt == 0) return;

    Vec3 oldC = d_centroids[j];
    Vec3 newC = { d_newCX[j]/(float)cnt,
                  d_newCY[j]/(float)cnt,
                  d_newCZ[j]/(float)cnt };
    d_centroids[j] = newC;

    Vec3 delta = newC - oldC;
    atomicAdd(d_drift, delta.lengthSq());
}

// =============================================================================
// Kernel: Build cluster descriptors from triangle assignments
// For each cluster, compute: AABB, avg normal, avg area, variance, density
// =============================================================================
VLYN_GLOBAL void kernelBuildClusters_Bounds(
    const Triangle* __restrict__ d_tris,
    const uint32_t* __restrict__ d_assign,
    Cluster* __restrict__        d_clusters,
    int n)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    const Triangle& t = d_tris[i];
    uint32_t c = d_assign[i];
    Cluster& cl = d_clusters[c];

    // Expand cluster AABB
    atomicMinFloat(&cl.bounds.mn.x, fminf(fminf(t.v0.x,t.v1.x),t.v2.x));
    atomicMinFloat(&cl.bounds.mn.y, fminf(fminf(t.v0.y,t.v1.y),t.v2.y));
    atomicMinFloat(&cl.bounds.mn.z, fminf(fminf(t.v0.z,t.v1.z),t.v2.z));
    atomicMaxFloat(&cl.bounds.mx.x, fmaxf(fmaxf(t.v0.x,t.v1.x),t.v2.x));
    atomicMaxFloat(&cl.bounds.mx.y, fmaxf(fmaxf(t.v0.y,t.v1.y),t.v2.y));
    atomicMaxFloat(&cl.bounds.mx.z, fmaxf(fmaxf(t.v0.z,t.v1.z),t.v2.z));

    // Accumulate normal and area
    atomicAdd((float*)&cl.avgNormal.x, t.normal.x);
    atomicAdd((float*)&cl.avgNormal.y, t.normal.y);
    atomicAdd((float*)&cl.avgNormal.z, t.normal.z);
    atomicAdd(&cl.avgArea, t.area);
    atomicAdd(&cl.triCount, 1u);
}

VLYN_GLOBAL void kernelBuildClusters_Finalize(
    Cluster* __restrict__ d_clusters,
    const Vec3* __restrict__ d_centroids,
    int k, int meshId)
{
    int j = blockIdx.x * blockDim.x + threadIdx.x;
    if (j >= k) return;

    Cluster& cl = d_clusters[j];
    cl.centroid    = d_centroids[j];
    cl.meshId      = (uint32_t)meshId;
    cl.clusterIdx  = (uint32_t)j;

    if (cl.triCount > 0) {
        cl.avgArea   /= (float)cl.triCount;
        cl.avgNormal  = cl.avgNormal.normalize();
    }

    float vol = cl.bounds.volume();
    cl.density = (vol > 1e-10f) ? (float)cl.triCount / vol : 0.f;
}

// =============================================================================
// Kernel: Compute per-cluster variance (second pass after finalize)
// =============================================================================
VLYN_GLOBAL void kernelComputeVariance(
    const Triangle* __restrict__ d_tris,
    const uint32_t* __restrict__ d_assign,
    Cluster* __restrict__        d_clusters,
    int n)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    const Triangle& t = d_tris[i];
    uint32_t c = d_assign[i];
    Cluster& cl = d_clusters[c];

    float da = t.area - cl.avgArea;
    atomicAdd(&cl.areaVariance, da * da);

    Vec3 dn = t.normal - cl.avgNormal;
    float dnl = dn.lengthSq();
    atomicAdd(&cl.normalVariance, dnl);
}

VLYN_GLOBAL void kernelFinalizeVariance(
    Cluster* __restrict__ d_clusters, int k)
{
    int j = blockIdx.x * blockDim.x + threadIdx.x;
    if (j >= k) return;
    if (d_clusters[j].triCount > 1) {
        d_clusters[j].areaVariance   /= (float)(d_clusters[j].triCount - 1);
        d_clusters[j].normalVariance /= (float)(d_clusters[j].triCount - 1);
    }
}

// =============================================================================
// Kernel: Set cluster assignment on each triangle
// =============================================================================
VLYN_GLOBAL void kernelWriteClusterIds(
    Triangle* __restrict__       d_tris,
    const uint32_t* __restrict__ d_assign,
    int n)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    d_tris[i].clusterId = d_assign[i];
}

// =============================================================================
// GPU K-Means main function
// Runs up to KMEANS_MAX_ITER iterations until convergence
// =============================================================================
VLynError meshKmeans(
    Triangle* d_tris, int n,
    Cluster* d_clusters, int k,
    int meshId,
    cudaStream_t stream)
{
    // Allocate device arrays
    Vec3*     d_centroids = nullptr;
    float*    d_newCX     = nullptr;
    float*    d_newCY     = nullptr;
    float*    d_newCZ     = nullptr;
    uint32_t* d_count     = nullptr;
    uint32_t* d_assign    = nullptr;
    float*    d_minDist2  = nullptr;
    float*    d_dist2Init = nullptr;
    float*    d_drift     = nullptr;

    VLYN_CUDA_CHECK(cudaMallocAsync(&d_centroids, k * sizeof(Vec3),     stream));
    VLYN_CUDA_CHECK(cudaMallocAsync(&d_newCX,     k * sizeof(float),    stream));
    VLYN_CUDA_CHECK(cudaMallocAsync(&d_newCY,     k * sizeof(float),    stream));
    VLYN_CUDA_CHECK(cudaMallocAsync(&d_newCZ,     k * sizeof(float),    stream));
    VLYN_CUDA_CHECK(cudaMallocAsync(&d_count,     k * sizeof(uint32_t), stream));
    VLYN_CUDA_CHECK(cudaMallocAsync(&d_assign,    n * sizeof(uint32_t), stream));
    VLYN_CUDA_CHECK(cudaMallocAsync(&d_minDist2,  n * sizeof(float),    stream));
    VLYN_CUDA_CHECK(cudaMallocAsync(&d_dist2Init, n * sizeof(float),    stream));
    VLYN_CUDA_CHECK(cudaMallocAsync(&d_drift,     sizeof(float),        stream));

    // --- K-means++ Seeding ---
    // Seed 0: pick first triangle centroid as initial centroid
    VLYN_CUDA_CHECK(cudaMemcpyAsync(d_centroids, &d_tris[0].centroid, sizeof(Vec3),
                        cudaMemcpyDeviceToDevice, stream));

    int tBlocks = (n + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    int kBlocks = (k + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;

    for (int seed = 1; seed < k; seed++) {
        // Compute squared distances to nearest existing centroid
        kernelKmeansDistance<<<tBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_tris, d_centroids, d_dist2Init, n, seed);

        // Find triangle with max weighted probability using CUB DeviceReduce ArgMax
        cub::KeyValuePair<int,float>* d_argmax = nullptr;
        VLYN_CUDA_CHECK(cudaMallocAsync(&d_argmax, sizeof(cub::KeyValuePair<int,float>), stream));
        void* d_temp = nullptr; size_t tempBytes = 0;
        
        cub::DeviceReduce::ArgMax(nullptr, tempBytes, d_dist2Init, d_argmax, n, stream);
        VLYN_CUDA_CHECK(cudaMallocAsync(&d_temp, tempBytes, stream));
        cub::DeviceReduce::ArgMax(d_temp, tempBytes, d_dist2Init, d_argmax, n, stream);

        // Tam Implementasyon: Host tarafına geçici olarak d_argmax değerini çekip doğrula
        cub::KeyValuePair<int, float> h_argmax;
        VLYN_CUDA_CHECK(cudaMemcpyAsync(&h_argmax, d_argmax, sizeof(cub::KeyValuePair<int, float>),
                            cudaMemcpyDeviceToHost, stream));
        VLYN_CUDA_CHECK(cudaStreamSynchronize(stream));

        int triIdx = h_argmax.key;
        if (triIdx < 0 || triIdx >= n) {
            triIdx = (seed * (n / k)) % n; // Güvenli fallback
        }

        // Copy selected triangle's centroid as next cluster center
        VLYN_CUDA_CHECK(cudaMemcpyAsync(d_centroids + seed, &d_tris[triIdx].centroid,
                            sizeof(Vec3), cudaMemcpyDeviceToDevice, stream));

        VLYN_CUDA_CHECK(cudaFreeAsync(d_argmax, stream));
        VLYN_CUDA_CHECK(cudaFreeAsync(d_temp,   stream));
    }

    // --- Main K-means loop ---
    float h_drift = FLT_MAX;
    for (int iter = 0; iter < KMEANS_MAX_ITER && h_drift > KMEANS_CONVERGENCE_EPS; iter++) {
        // Assignment step
        kernelKmeansAssign<<<tBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_tris, d_centroids, d_assign, d_minDist2, n, k);

        // Update step — reset accumulators
        VLYN_CUDA_CHECK(cudaMemsetAsync(d_newCX, 0, k * sizeof(float), stream));
        VLYN_CUDA_CHECK(cudaMemsetAsync(d_newCY, 0, k * sizeof(float), stream));
        VLYN_CUDA_CHECK(cudaMemsetAsync(d_newCZ, 0, k * sizeof(float), stream));
        VLYN_CUDA_CHECK(cudaMemsetAsync(d_count, 0, k * sizeof(uint32_t), stream));

        kernelKmeansUpdate<<<tBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_tris, d_assign, d_newCX, d_newCY, d_newCZ, d_count, n, k);

        // Finalize centroids
        VLYN_CUDA_CHECK(cudaMemsetAsync(d_drift, 0, sizeof(float), stream));
        kernelKmeansFinalize<<<kBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_centroids, d_newCX, d_newCY, d_newCZ, d_count, d_drift, k);

        // Check convergence (asenkron transfer yapısına uygun güncellenmiş blok)
        if ((iter & 7) == 0) {
            VLYN_CUDA_CHECK(cudaMemcpyAsync(&h_drift, d_drift, sizeof(float), cudaMemcpyDeviceToHost, stream));
            VLYN_CUDA_CHECK(cudaStreamSynchronize(stream));
        }
    }

    // --- Build cluster descriptors ---
    Cluster initCluster;
    initCluster.bounds = AABB();
    initCluster.triCount = 0;
    initCluster.avgArea  = 0.f;
    initCluster.areaVariance = 0.f;
    initCluster.normalVariance = 0.f;
    initCluster.avgNormal = Vec3(0,0,0);
    for (int j = 0; j < k; j++) {
        VLYN_CUDA_CHECK(cudaMemcpyAsync(d_clusters + j, &initCluster, sizeof(Cluster),
                            cudaMemcpyHostToDevice, stream));
    }

    kernelBuildClusters_Bounds<<<tBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_tris, d_assign, d_clusters, n);

    kernelBuildClusters_Finalize<<<kBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_clusters, d_centroids, k, meshId);

    // Variance pass
    kernelComputeVariance<<<tBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_tris, d_assign, d_clusters, n);
    kernelFinalizeVariance<<<kBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_clusters, k);

    // Write cluster IDs back to triangles
    kernelWriteClusterIds<<<tBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        d_tris, d_assign, n);

    // Cleanup
    VLYN_CUDA_CHECK(cudaFreeAsync(d_centroids, stream));
    VLYN_CUDA_CHECK(cudaFreeAsync(d_newCX,     stream));
    VLYN_CUDA_CHECK(cudaFreeAsync(d_newCY,     stream));
    VLYN_CUDA_CHECK(cudaFreeAsync(d_newCZ,     stream));
    VLYN_CUDA_CHECK(cudaFreeAsync(d_count,     stream));
    VLYN_CUDA_CHECK(cudaFreeAsync(d_assign,    stream));
    VLYN_CUDA_CHECK(cudaFreeAsync(d_minDist2,  stream));
    VLYN_CUDA_CHECK(cudaFreeAsync(d_dist2Init, stream));
    VLYN_CUDA_CHECK(cudaFreeAsync(d_drift,     stream));

    return VLYN_OK;
}

// =============================================================================
// Streaming Tile Processor
// For meshes larger than available VRAM, process in tiles of VLYN_TILE_SIZE
// triangles. Each tile is independently scanned and BVH-built.
// =============================================================================
struct TileProcessor {
    size_t     tileSize;
    Triangle*  d_tileBuf;     // GPU buffer for one tile
    uint8_t*   d_validBuf;    // validity flags
    int*       d_prefixBuf;   // prefix sum
    Triangle*  d_compactBuf;  // compacted triangles

    cudaStream_t streamA;     // double-buffered streams
    cudaStream_t streamB;
};

VLynError tileProcessorInit(TileProcessor* tp, size_t tileSize) {
    tp->tileSize = tileSize;

    cudaMalloc(&tp->d_tileBuf,    tileSize * sizeof(Triangle));
    cudaMalloc(&tp->d_validBuf,   tileSize * sizeof(uint8_t));
    cudaMalloc(&tp->d_prefixBuf,  tileSize * sizeof(int));
    cudaMalloc(&tp->d_compactBuf, tileSize * sizeof(Triangle));

    cudaStreamCreate(&tp->streamA);
    cudaStreamCreate(&tp->streamB);

    if (!tp->d_tileBuf || !tp->d_validBuf || !tp->d_prefixBuf || !tp->d_compactBuf)
        return VLYN_ERR_OOM;
    return VLYN_OK;
}

void tileProcessorFree(TileProcessor* tp) {
    cudaFree(tp->d_tileBuf);
    cudaFree(tp->d_validBuf);
    cudaFree(tp->d_prefixBuf);
    cudaFree(tp->d_compactBuf);
    cudaStreamDestroy(tp->streamA);
    cudaStreamDestroy(tp->streamB);
}

// Process a single tile: validate, compact, compute derived
VLynError tileProcessOne(
    TileProcessor* tp,
    Triangle* h_tris,
    int count,
    int tileStart,
    uint32_t meshId,
    Triangle* d_dst,       // output: compacted GPU triangles
    int* h_compactCount,   // output: actual count after degenerate removal
    cudaStream_t stream)
{
    if (count <= 0) { *h_compactCount = 0; return VLYN_OK; }

    // Upload tile to GPU
    cudaMemcpyAsync(tp->d_tileBuf, h_tris + tileStart,
                    count * sizeof(Triangle), cudaMemcpyHostToDevice, stream);

    int blocks = (count + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;

    // Compute derived data
    kernelComputeTriDerived<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        tp->d_tileBuf, meshId, count);

    // Validate
    kernelValidateTris<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        tp->d_tileBuf, tp->d_validBuf, count, WINDING_AREA_EPS);

    // Prefix sum for compaction (CUB)
    // DÜZELTME: d_validBuf bir uint8_t* dizisidir; (int*) olarak yeniden
    // yorumlamak cub'a 4 kat daha az/yanlış hizalanmış eleman okutuyordu.
    // cub::DeviceScan::ExclusiveSum girdi ve çıktı için farklı tipler kabul
    // eder, dolayısıyla uint8_t girdisini doğrudan int* çıktısına toplayabiliriz.
    void* d_temp = nullptr; size_t tempBytes = 0;
    cub::DeviceScan::ExclusiveSum(nullptr, tempBytes,
        tp->d_validBuf, tp->d_prefixBuf, count, stream);
    cudaMallocAsync(&d_temp, tempBytes, stream);
    cub::DeviceScan::ExclusiveSum(d_temp, tempBytes,
        tp->d_validBuf, tp->d_prefixBuf, count, stream);
    cudaFreeAsync(d_temp, stream);

    // Compact
    kernelCompactTris<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        tp->d_tileBuf, tp->d_validBuf, tp->d_prefixBuf,
        d_dst, count);

    // Count valid triangles (last prefix + last valid flag)
    // Read back total
    int lastPrefix = 0;
    uint8_t lastValid = 0;
    cudaMemcpyAsync(&lastPrefix, tp->d_prefixBuf + count - 1,
                    sizeof(int), cudaMemcpyDeviceToHost, stream);
    cudaMemcpyAsync(&lastValid, tp->d_validBuf + count - 1,
                    sizeof(uint8_t), cudaMemcpyDeviceToHost, stream);
    cudaStreamSynchronize(stream);
    *h_compactCount = lastPrefix + (int)lastValid;

    return VLYN_OK;
}

// =============================================================================
// Kernel: Reindex triangle IDs after compaction (global offset)
// =============================================================================
VLYN_GLOBAL void kernelReindexTris(Triangle* d_tris, int offset, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    d_tris[i].triId = (uint32_t)(offset + i);
}

// =============================================================================
// Kernel: Compute mesh bounding box (streaming version)
// Expands d_result atomically
// =============================================================================
VLYN_GLOBAL void kernelMeshBoundsExpand(
    const Triangle* __restrict__ d_tris, int n,
    AABB* __restrict__ d_bounds)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    atomicExpandAABB(d_bounds, d_tris[i].v0);
    atomicExpandAABB(d_bounds, d_tris[i].v1);
    atomicExpandAABB(d_bounds, d_tris[i].v2);
}

// =============================================================================
// Kernel: Surface area integration — sums all triangle areas
// =============================================================================
VLYN_GLOBAL void kernelSumAreas(
    const Triangle* __restrict__ d_tris, int n,
    float* __restrict__ d_total)
{
    VLYN_SHARED float sArea[VLYN_BLOCK_SIZE];
    int tid = threadIdx.x;
    int gid = blockIdx.x * blockDim.x + tid;

    float area = (gid < n) ? d_tris[gid].area : 0.f;
    sArea[tid] = area;
    __syncthreads();

    for (int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (tid < s) sArea[tid] += sArea[tid + s];
        __syncthreads();
    }
    if (tid == 0) atomicAdd(d_total, sArea[0]);
}

// =============================================================================
// Kernel: Detect non-manifold edges (for mesh quality check)
// An edge shared by ≠ 2 triangles is non-manifold
// Simple hash-based approach
// =============================================================================
VLYN_GLOBAL void kernelDetectNonManifold(
    const Triangle* __restrict__ d_tris, int n,
    uint32_t* __restrict__ d_edgeCount,  // hash map: edgeHash → count
    uint32_t mapSize)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;

    const Triangle& t = d_tris[i];

    // Hash each edge (v0-v1, v1-v2, v2-v0)
    auto hashEdge = [&](uint32_t a, uint32_t b) -> uint32_t {
        uint32_t lo = min(a, b), hi = max(a, b);
        uint32_t h = lo * 2654435761u ^ hi * 2246822519u;
        return h % mapSize;
    };

    // Use vertex positions hashed as uint32 via bit_cast
    uint32_t h0 = *reinterpret_cast<const uint32_t*>(&t.v0.x);
    uint32_t h1 = *reinterpret_cast<const uint32_t*>(&t.v1.x);
    uint32_t h2 = *reinterpret_cast<const uint32_t*>(&t.v2.x);

    atomicAdd(&d_edgeCount[hashEdge(h0, h1)], 1);
    atomicAdd(&d_edgeCount[hashEdge(h1, h2)], 1);
    atomicAdd(&d_edgeCount[hashEdge(h2, h0)], 1);
}

// =============================================================================
// Kernel: Reduce the edge-hash bucket counts from kernelDetectNonManifold
// into a single "non-manifold edge count". A well-formed closed manifold
// mesh has every edge shared by EXACTLY 2 triangles, so any bucket with a
// nonzero count != 2 indicates either a boundary edge (count 1) or a
// non-manifold edge (count >= 3). This is a hash-based heuristic — two
// distinct edges can collide into the same bucket — so it is a conservative
// upper bound on non-manifold edges, not an exact geometric proof; sufficient
// for the "isManifold" quick-check flag surfaced in MeshStats.
// =============================================================================
VLYN_GLOBAL void kernelReduceNonManifold(
    const uint32_t* __restrict__ d_edgeCount,
    uint32_t mapSize,
    uint32_t* __restrict__ d_badEdgeCount)
{
    VLYN_SHARED uint32_t sBad[VLYN_BLOCK_SIZE];
    int tid = threadIdx.x;
    int gid = blockIdx.x * blockDim.x + tid;

    uint32_t bad = 0;
    if (gid < (int)mapSize) {
        uint32_t c = d_edgeCount[gid];
        if (c != 0 && c != 2) bad = 1;
    }
    sBad[tid] = bad;
    __syncthreads();

    for (int s = blockDim.x >> 1; s > 0; s >>= 1) {
        if (tid < s) sBad[tid] += sBad[tid + s];
        __syncthreads();
    }
    if (tid == 0 && sBad[0] > 0) atomicAdd(d_badEdgeCount, sBad[0]);
}

// =============================================================================
// Mesh statistics structure
// =============================================================================
struct MeshStats {
    uint32_t totalTris;
    uint32_t validTris;
    uint32_t degenerateTris;
    uint32_t clusterCount;
    float    totalSurfaceArea;
    float    avgTriArea;
    float    minTriArea;
    float    maxTriArea;
    AABB     worldBounds;
    float    volumeEstimate;
    bool     isManifold;
    float    buildTimeMs;
};

// =============================================================================
// meshScan — full mesh scan pipeline entry point
// Called by VLyn_interface after mesh upload
// =============================================================================
VLynError meshScan(
    MeshDesc*    mesh,
    Triangle*    h_tris,           // host triangles (may be null if already on GPU)
    uint32_t     triCount,
    uint32_t     meshId,
    const CVSConfig& cfg,
    MeshStats*   stats,
    cudaStream_t stream)
{
    if (triCount == 0) return VLYN_ERR_INVALID_MESH;

    mesh->meshId   = meshId;
    mesh->isDirty  = true;

    int k = min((int)cfg.clusterK, (int)triCount);
    k = max(k, 1);

    // Allocate GPU triangle array if not already present
    if (!mesh->d_triangles) {
        cudaMallocAsync(&mesh->d_triangles, triCount * sizeof(Triangle), stream);
        if (!mesh->d_triangles) return VLYN_ERR_OOM;
    }

    // Upload triangles (if host pointer given)
    if (h_tris) {
        cudaMemcpyAsync(mesh->d_triangles, h_tris,
                        triCount * sizeof(Triangle),
                        cudaMemcpyHostToDevice, stream);
    }

    int blocks = (triCount + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;

    // Compute derived properties
    kernelComputeTriDerived<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        mesh->d_triangles, meshId, (int)triCount);

    // Validate and compact (in-place — replaces degenerate tris)
    uint8_t* d_valid = nullptr;
    cudaMallocAsync(&d_valid, triCount * sizeof(uint8_t), stream);
    kernelValidateTris<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        mesh->d_triangles, d_valid, (int)triCount, WINDING_AREA_EPS);

    int* d_prefix = nullptr;
    // d_compacted must use cudaMalloc (NOT cudaMallocAsync) because it becomes
    // mesh->d_triangles and will be accessed from ctx->streams[0] in CVSQuery —
    // a different CUDA stream from the mesh init stream used here. cudaMallocAsync
    // allocations are stream-ordered and cause cudaErrorIllegalAddress when read
    // from a different stream without an explicit dependency/sync between streams.
    Triangle* d_compacted = nullptr;
    cudaMallocAsync(&d_prefix, triCount * sizeof(int), stream);
    cudaMalloc(&d_compacted, triCount * sizeof(Triangle));
    if (!d_compacted) {
        cudaFreeAsync(d_valid, stream);
        cudaFreeAsync(d_prefix, stream);
        return VLYN_ERR_OOM;
    }

    void* d_scanTemp = nullptr; size_t scanTempBytes = 0;
    cub::DeviceScan::ExclusiveSum(nullptr, scanTempBytes,
        d_valid, d_prefix, (int)triCount, stream);
    cudaMallocAsync(&d_scanTemp, scanTempBytes, stream);
    cub::DeviceScan::ExclusiveSum(d_scanTemp, scanTempBytes,
        d_valid, d_prefix, (int)triCount, stream);
    cudaFreeAsync(d_scanTemp, stream);

    kernelCompactTris<<<blocks, VLYN_BLOCK_SIZE, 0, stream>>>(
        mesh->d_triangles, d_valid, d_prefix, d_compacted, (int)triCount);

    int lastPrefix = 0;
    uint8_t lastValid = 0;
    cudaMemcpyAsync(&lastPrefix, d_prefix + triCount - 1, sizeof(int),
                    cudaMemcpyDeviceToHost, stream);
    cudaMemcpyAsync(&lastValid, d_valid + triCount - 1, sizeof(uint8_t),
                    cudaMemcpyDeviceToHost, stream);
    cudaStreamSynchronize(stream);
    uint32_t validCount = (uint32_t)(lastPrefix + (int)lastValid);

    // Swap the compacted buffer in as the mesh's live triangle array.
    // Free the original using cudaFree (not cudaFreeAsync) since d_triangles
    // may itself have been allocated with cudaMalloc earlier.
    cudaStreamSynchronize(stream);  // ensure all kernels on stream have finished reading it
    cudaFree(mesh->d_triangles);
    mesh->d_triangles = d_compacted;
    mesh->triCount = validCount;
    uint32_t effectiveTriCount = validCount;

    cudaFreeAsync(d_prefix, stream);

    // Recompute launch geometry against the (possibly smaller) compacted count
    int effBlocks = ((int)effectiveTriCount + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE;
    if (effBlocks < 1) effBlocks = 1;

    // Compute world bounds
    AABB initBounds;
    AABB* d_bounds = nullptr;
    cudaMallocAsync(&d_bounds, sizeof(AABB), stream);
    cudaMemcpyAsync(d_bounds, &initBounds, sizeof(AABB), cudaMemcpyHostToDevice, stream);
    if (effectiveTriCount > 0) {
        kernelMeshBoundsExpand<<<effBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            mesh->d_triangles, (int)effectiveTriCount, d_bounds);
    }
    cudaMemcpyAsync(&mesh->worldBounds, d_bounds, sizeof(AABB),
                    cudaMemcpyDeviceToHost, stream);

    // Surface area
    float* d_area = nullptr;
    cudaMallocAsync(&d_area, sizeof(float), stream);
    cudaMemsetAsync(d_area, 0, sizeof(float), stream);
    if (effectiveTriCount > 0) {
        kernelSumAreas<<<effBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            mesh->d_triangles, (int)effectiveTriCount, d_area);
    }

    float totalArea = 0.f;
    cudaMemcpyAsync(&totalArea, d_area, sizeof(float), cudaMemcpyDeviceToHost, stream);

    // DÜZELTME: gerçek manifold kontrolü. kernelDetectNonManifold zaten
    // mevcuttu ama hiçbir yerden çağrılmıyordu — bu yüzden isManifold her
    // zaman "true" olarak sabitlenmişti. Hash-tabanlı bir yaklaşım olduğu
    // için (çakışan hash'ler yanlış pozitife yol açabilir) kesin bir
    // geometrik ispat değil, muhafazakâr bir üst sınırdır — ama gerçek GPU
    // verisine dayanır, sabit bir placeholder değildir.
    uint32_t manifoldMapSize = max(64u, effectiveTriCount * 3u);
    uint32_t* d_edgeCount = nullptr;
    uint32_t* d_badEdgeCount = nullptr;
    cudaMallocAsync(&d_edgeCount, manifoldMapSize * sizeof(uint32_t), stream);
    cudaMallocAsync(&d_badEdgeCount, sizeof(uint32_t), stream);
    cudaMemsetAsync(d_edgeCount, 0, manifoldMapSize * sizeof(uint32_t), stream);
    cudaMemsetAsync(d_badEdgeCount, 0, sizeof(uint32_t), stream);
    if (effectiveTriCount > 0) {
        kernelDetectNonManifold<<<effBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            mesh->d_triangles, (int)effectiveTriCount, d_edgeCount, manifoldMapSize);
        int mapBlocks = (int)((manifoldMapSize + VLYN_BLOCK_SIZE - 1) / VLYN_BLOCK_SIZE);
        kernelReduceNonManifold<<<mapBlocks, VLYN_BLOCK_SIZE, 0, stream>>>(
            d_edgeCount, manifoldMapSize, d_badEdgeCount);
    }
    uint32_t h_badEdgeCount = 0;
    cudaMemcpyAsync(&h_badEdgeCount, d_badEdgeCount, sizeof(uint32_t),
                    cudaMemcpyDeviceToHost, stream);

    // K-means clustering
    // Re-clamp k: compaction may have dropped triangles below the original
    // estimate, and k-means requires k <= number of points.
    if ((uint32_t)k > effectiveTriCount) k = max((int)effectiveTriCount, 1);
    if (!mesh->d_clusters) {
        // cudaMalloc (not cudaMallocAsync): d_clusters is read by CVSQuery on
        // streams[0] which is a different stream from the mesh init stream.
        // Stream-ordered allocations are not safely accessible cross-stream.
        cudaMalloc(&mesh->d_clusters, k * sizeof(Cluster));
    }
    mesh->clusterCount = (uint32_t)k;

    cudaStreamSynchronize(stream);  // sync before k-means (needs valid centroids)
    VLynError e = VLYN_OK;
    if (effectiveTriCount > 0) {
        e = meshKmeans(mesh->d_triangles, (int)effectiveTriCount,
                        mesh->d_clusters, k, (int)meshId, stream);
    }
    if (e != VLYN_OK) goto cleanup;

    // Fill stats
    if (stats) {
        cudaStreamSynchronize(stream);
        stats->totalTris       = triCount;
        stats->validTris       = validCount;
        stats->degenerateTris  = triCount - validCount;
        stats->clusterCount    = (uint32_t)k;
        stats->totalSurfaceArea = totalArea;
        stats->avgTriArea      = (validCount > 0) ? totalArea / validCount : 0.f;
        stats->worldBounds     = mesh->worldBounds;
        stats->isManifold      = (h_badEdgeCount == 0);
    }

cleanup:
    cudaFreeAsync(d_valid,  stream);
    cudaFreeAsync(d_bounds, stream);
    cudaFreeAsync(d_area,   stream);
    cudaFreeAsync(d_edgeCount, stream);
    cudaFreeAsync(d_badEdgeCount, stream);
    return e;
}

// =============================================================================
// meshFree — free all GPU resources for a mesh
// =============================================================================
void meshFree(MeshDesc* mesh) {
    if (mesh->d_triangles)  { cudaFree(mesh->d_triangles);  mesh->d_triangles  = nullptr; }
    if (mesh->d_bvh)        { cudaFree(mesh->d_bvh);        mesh->d_bvh        = nullptr; }
    if (mesh->d_mortonCodes){ cudaFree(mesh->d_mortonCodes); mesh->d_mortonCodes = nullptr; }
    if (mesh->d_clusters)   { cudaFree(mesh->d_clusters);   mesh->d_clusters   = nullptr; }
    mesh->triCount    = 0;
    mesh->clusterCount= 0;
}

// =============================================================================
// Kernel: Nearest-neighbor search — for each query point, find closest tri
// Uses a simple linear scan over clusters for O(k) per point
// =============================================================================
VLYN_GLOBAL void kernelNearestNeighborClusters(
    const Vec3* __restrict__     d_queries, int nQ,
    const Cluster* __restrict__  d_clusters, int k,
    uint32_t* __restrict__       d_result)
{
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= nQ) return;

    Vec3 q = d_queries[i];
    float minD2 = FLT_MAX;
    uint32_t best = 0;

    for (int j = 0; j < k; j++) {
        Vec3 d = q - d_clusters[j].centroid;
        float d2 = d.lengthSq();
        if (d2 < minD2) { minD2 = d2; best = (uint32_t)j; }
    }
    d_result[i] = best;
}

// =============================================================================
// Cluster pair enumeration — generate all pairs (A_cluster, B_cluster)
// that have overlapping AABBs. Output: packed uint32 [idxA<<16 | idxB]
// =============================================================================
VLYN_GLOBAL void kernelEnumerateClusterPairs(
    const Cluster* __restrict__ d_clustersA, int kA,
    const Cluster* __restrict__ d_clustersB, int kB,
    uint32_t* __restrict__      d_pairs,
    uint32_t* __restrict__      d_count,
    uint32_t maxPairs,
    float expandFactor)
{
    int ia = blockIdx.x * blockDim.x + threadIdx.x;
    int ib = blockIdx.y * blockDim.y + threadIdx.y;
    if (ia >= kA || ib >= kB) return;

    AABB a = d_clustersA[ia].bounds.expanded(expandFactor);
    AABB b = d_clustersB[ib].bounds.expanded(expandFactor);

    if (a.overlaps(b)) {
        uint32_t slot = atomicAdd(d_count, 1);
        if (slot < maxPairs) {
            d_pairs[slot] = ((uint32_t)ia << 16) | ((uint32_t)ib & 0xffff);
        }
    }
}

// =============================================================================
// End of VLyn_mesh.cu
// =============================================================================
